<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>

<?php
include "connection.php";
?>

<?php
include "header.php";
?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex">
                        <h6>To`lovlar Bo`limi</h6>
                    </div>
                </div>
                <div class="card-body p-3">
                    <form name="form1" action="" method="post">
                        <div class="sales_product_name">
                            <table class="table">
                                <tr>
                                    <th> ID</th>
                                    <th>Mijoz ID</th>
                                    <th>Mijoz Nomi</th>
                                    <th>Buyurtma Kodi</th>
                                    <th>Agentga To`lov Qilingan Vaqti</th>
                                    <th>Jami</th>
                                    <th>Olindi</th>
                                    <th>Tasdiqlash</th>
                                </tr>
                                <?php
                                $res = mysqli_query($link, "select * from payment_base WHERE agent_kredit IS NOT NULL AND agent_kredit != ''");
                                while ($row = mysqli_fetch_array($res)) {
                                ?>
                                    <tr>
                                        <td><?php echo $row["id"] ?></td>
                                        <td><?php echo $row["client_id"] ?></td>
                                        <td><?php echo $row["client_name"] ?></td>
                                        <td><?php echo "MB" ?><?php echo $row["bill_no"] ?></td>
                                        <td><?php echo $row["date"] ?></td>
                                        <td><input type="text" name="kredit" class="form-control" value="<?php echo $row["agent_kredit"] ?>" readonly></td>
                                        <td></td>
                                        <td class="edit"><a href="./accept_money.php?id=<?php echo $row["id"]; ?> "> <span>Tasdiqlash</span> <i class="fa-solid fa-check"></i></a></td>
                                    </tr>
                                <?php
                                }
                                ?>
                            </table>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->
</div>
<!-- Content wrapper -->



<?php
if (isset($_POST["submit1"])) {
    mysqli_query($link, "update  payment_base set kredit='$_POST[kredit]' where id=$id)") or die(mysqli_error($link));
}
?>


<?php
include "footer.php"
?>