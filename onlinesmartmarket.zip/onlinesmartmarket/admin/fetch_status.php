<?php
include "connection.php";

if (isset($_POST['request'])) {
    $request = $_POST['request'];

    $res = "SELECT * FROM billing_header WHERE status = '$request'";
    $result = mysqli_query($link, $res);
    $count = mysqli_num_rows($result);
}

?>

<table class="table">
    <?php
    if ($count) {
    ?>
        <thead>
            <tr>
                <th>Sr No</th>
                <th>Username</th>
                <th>Type</th>
                <th>Date</th>
                <th>Porduct Id</th>
                <th>Status</th>
            </tr>

        <?php
    } else {
        echo "Sorry no record";
    }
        ?>
        </thead>

        <tbody>
            <?php
            while ($row = mysqli_fetch_assoc($result)) {


            ?>
                <tr>
                    <td><?php echo $row["id"] ?></td>
                    <td><?php echo $row["client_name"] ?></td>
                    <td><?php echo $row["bill_type"] ?></td>
                    <td><?php echo $row["date"] ?></td>
                    <td><?php echo $row["bill_no"] ?></td>
                    <td><?php
                        if ($row['status'] == 1) {
                            echo '<span class="worning"> <small>Jarayonda</small><i class="fa-solid fa-circle-exclamation"></i></span>';
                        }
                        if ($row['status'] == 2) {
                            echo '<span class="check"> <small>Tasdiqlandi</small><i class="fa-solid fa-check"></i></i></span>';
                        }
                        if ($row['status'] == 3) {
                            echo '<span class="cancel"> <small>Tasdiqlanmadi</small><i class="fa-solid fa-ban"></i></i></span>';
                        }
                        ?></td>

                </tr>

            <?php
            }
            ?>
        </tbody>
</table>