<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>


<?php
include "connection.php"
?>
<?php
include "header.php";
?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="alerts">
            <div class="alert alert-danger alert-dismissible fade show" role="alert" id="error" style="display:none;">
                Bu Hajm Birlik mavjud! Iltmos boshqa Hajm Birlik qo`shing
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>

            <div class="alert alert-success alert-dismissible fade show" role="alert" id="success" style="display:none;">
                Hajm Birlik muvaffaqiyatli qo`shildi
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <b>Xodimlar Hisoboti</b>

                    <form class="form-inline" action="" name="form1" method="post">
                        <div class="form-group">
                            <label for="email">Boshlang`ich Sanani Tanlang</label>
                            <input type="text" name="dt" id="dt" autocomplete="off" class="form-control" required style="width:200px;border-style:solid; border-width:1px; border-color:#666666" placeholder="click here to open calender">
                        </div>
                        <div class="form-group">
                            <label for="email">Oxrigi Sanani Tanlang</label>
                            <input type="text" name="dt2" id="dt2" autocomplete="off" placeholder="click here to open calender" class="form-control" style="width:200px;border-style:solid; border-width:1px; border-color:#666666">
                        </div>
                        <button type="submit" name="submit3" class="btn btn-success">Filter</button>
                        <button type="button" name="submit2" class="btn btn-warning" onclick="window.location.href=window.location.href">Clear Search</button>
                    </form>
                </div>
                <div class="card-body">

                    <?php
                    if (isset($_POST["submit3"])) {
                    ?>
                        <table class="table">
                            <tr>
                                <th scope="col">Xodim</th>
                                <th scope="col">Hisobot</th>
                                <th scope="col">Vaqti</th>
                            </tr>
                            <?php
                            $res = mysqli_query($link, "select * from worker_report where (date>='$_POST[dt]' && date<='$_POST[dt2]') order by id desc");
                            while ($row = mysqli_fetch_array($res)) {
                            ?>
                                <tr>
                                    <th><?php echo $row["username"] ?></th>
                                    <td><?php echo $row["text"] ?></td>
                                    <td><?php echo $row["date"] ?></td>
                                </tr>
                            <?php
                            }
                            ?>

                        </table>
                    <?php
                    } else {
                    ?>

                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Xodim</th>
                                    <th scope="col">Hisobot</th>
                                    <th scope="col">Vaqti</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $res = mysqli_query($link, "select * from worker_report");
                                while ($row = mysqli_fetch_array($res)) {
                                ?>
                                    <tr>
                                        <th><?php echo $row["username"] ?></th>
                                        <td><?php echo $row["text"] ?></td>
                                        <td><?php echo $row["date"] ?></td>
                                    </tr>
                                <?php
                                }
                                ?>

                            </tbody>
                        </table>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->
</div>
<!-- Content wrapper -->





<script type="text/javascript">
    const date = new Date();

    let day = date.getDate();
    let month = date.getMonth() + 1;
    let year = date.getFullYear();

    // This arrangement can be altered based on how we want the date's format to appear.
    let currentDate = `${day}-${month}-${year}`;
    console.log(currentDate); // "17-6-2022"
</script>

<?php
if (isset($_POST["submit1"])) {

    mysqli_query($link, "insert into worker_report values(NULL, '$_SESSION[user]', '$_POST[text]', '$_POST[date]')");

?>
    <script type="text/javascript">
        document.getElementById('error').style.display = "none";
        document.getElementById('success').style.display = "block";
        setTimeout(function() {
            window.location.href = window.location.href;
        }, 3000);
    </script>
<?php
}
?>

<?php
include "footer.php"
?>