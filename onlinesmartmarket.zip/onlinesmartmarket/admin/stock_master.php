<?php
session_start();
    if(!isset($_SESSION["admin"]))
    {
        ?>
            <script type="text/javascript">
                window.location="index.php";
            </script>
        <?php
    }
?>


<?php
include "header.php";
include "connection.php"
?>

<div id="main-content">
    <div id="header">
        <div class="header-left float-left">
            <i id="toggle-left-menu" class="ion-android-menu"></i>
        </div>
        <div class="header-right float-right">
            <i class="ion-ios-people"></i>
        </div>
    </div>

    <div id="page-container">
        
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                <i class="fa-solid fa-store"></i>
                    <b>Sklad</b>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Sr No</th>
                                <th scope="col">Ta`minotchi</th>
                                <th scope="col">Mahsulot Nomi</th>
                                <th scope="col">Mahsulot Qiymati</th>
                                <th scope="col">Mahsulot Hajm Birligi</th>
                                <th scope="col">Mahsulot Narxi </th>
                                <th scope="col">Tahrirlash</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $count=0;
                            $res = mysqli_query($link, "select * from stock_master");
                            while ($row = mysqli_fetch_array($res)) {
                                $count=$count+1;
                            ?>
                                <tr>
                                    <th scope="row"><?php echo $count; ?></th>
                                    <td><?php echo $row["product_company"] ?></td>
                                    <td><?php echo $row["product_name"] ?></td>
                                    <td><?php echo $row["product_qty"] ?></td>
                                    <td><?php echo $row["product_unit"] ?></td>
                                    <td><?php echo $row["product_selling_price"] ?>  <b>so`m</b></td>
                                    <td><a href="./edit_stock_master.php?id=<?php echo $row["id"];?> ">Tahrirlash</a></td>
                                </tr>
                            <?php
                            }
                            ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php
include "footer.php";
?>