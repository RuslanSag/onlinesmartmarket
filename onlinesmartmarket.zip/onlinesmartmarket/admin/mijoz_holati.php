<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>


<?php

include "connection.php";

if (isset($_GET['id']) && isset($_GET['status'])) {
    $id = $_GET['id'];
    $status = $_GET['status'];
    mysqli_query($link, "update billing_header set status='$status' where id='$id'");
    header("location:view_bills.php");
}


// $client_id = $_GET["client_id"];
// $res = mysqli_query($link, "select * from payment_base where client_id='$client_id' ");


?>

<style>
    @media print {

        body *,
        .logo,
        .left-menu {
            visibility: hidden;
        }

        .print-container,
        .print-container * {
            visibility: visible;
        }
    }

    .blink {
        animation: blinker 1s linear infinite;
        background: red;
        color: white;
        width: 100%;
        font-weight: bold;
    }

    @keyframes blinker {
        50% {
            opacity: 0;
        }
    }
</style>
<?php
include "header.php";
?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
    <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex">
                        <i class="fa-regular fa-newspaper"></i>
                        <h6>Mijoz Holati</h6>
                    </div>
                    <form class="form-inline" action="" name="form1" method="post">
                        <div class="mb-3">
                            <label class="form-label">Mijoz </label>
                            <div class="d-flex align-items-center">
                                <input class="form-control" name="client_name" id="client_name" onchange="select_cilent(this.value)">

                                <!-- <a class="pluss_btn" href="./client_filter.php">
                                        <i class="fa-solid fa-plus"></i>
                                    </a> -->
                                <button type="button" class="btn btn-primary" style="margin-left: 15px;" data-toggle="modal" data-target="#exampleModal">
                                    OK
                                </button>
                            </div>


                        </div>
                    </form>

                </div>
                <div class="card-body print-container">
                    
                    <div class="mb-3">
                        <label class="form-label">Info Mijoz:</label>
                        <div id="client_div">

                        </div>

                    </div>
                </div>

                <div class="card-footer">
                    <button type="button" class="btn btn-info" onclick="window.print()">Print</button>
                </div>



            </div>
        </div>
    </div>
    <!-- / Content -->
</div>
<!-- Content wrapper -->





<script type="text/javascript">
    function status_update(value, id) {
        let url = "view_bills.php";
        window.location.href = url + "?id=" + id + "&status=" + value;
    }

    function select_cilent(client_name) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("client_div").innerHTML = xmlhttp.responseText;
                // alert("ssss");
            }
        };
        xmlhttp.open("GET", "forajax_payment/load_payment_base.php?client_name=" + client_name, true);
        xmlhttp.send();
    }
</script>

<?php




function get_total($bill_id, $link)
{
    $total = 0;
    $res2 = mysqli_query($link, "select * from billing_details where bill_id=$bill_id");
    while ($row2 = mysqli_fetch_array($res2)) {
        $total = $total + ($row2["price"] * $row2["qty"]);
    }

    return $total;
}
?>

<?php
include "footer.php"
?>