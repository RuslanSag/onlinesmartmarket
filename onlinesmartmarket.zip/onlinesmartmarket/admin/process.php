<?php
include "connection.php";
$output = "";

if(isset($_POST["submit"])){
    $res = mysqli_query($link, "select * from client_base");
    $output .='
    <table class="table">
        <tr>
            <th scope="col">Client Name</th>
            <th scope="col">Client Region</th>
            <th scope="col">Client Address</th>
            <th scope="col">Client Number</th>
            <th scope="col">Client Category</th>
        </tr>
    ';
    while ($row = mysqli_fetch_array($res)) {

        $output .='
        <tr>
        <td>' . $row["client_name"]; '</td>
        <td>' . $row["client_region"]; '</td>
        <td>' . $row["client_address"]; '</td>
        <td>' . $row["client_number"]; '</td>
        <td>' . $row["client_category"]; '</td>
        
    </tr>
        ';
        
        $output .= '</table>';

        header('Content-Type: application/xls');
        header('Contetn-Disposition:attachment;filename=reports.xls');
        echo $output;

    }   
}
?>