<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>


<?php
include "header.php";
include "connection.php";

$bill_no = $_GET["bill_no"];
$client_name = "";
$date = "";
$id = "";
// $bill_no = "";
// $status = "";
$client_address = "";
$username = "";
$res = mysqli_query($link, "select * from billing_header where bill_no=$bill_no");
while ($row = mysqli_fetch_array($res)) {
    $client_name = $row["client_name"];
    $date = $row["date"];
    $id = $row["id"];
    // $bill_no = $row["bill_no"];
    // $status = $row["status"];
    $client_address = $row["client_address"];
    $username = $row["username"];
}




?>


<style>
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,100;9..40,200;9..40,300;9..40,400;9..40,500;9..40,600;9..40,700;9..40,800;9..40,900;9..40,1000&family=Roboto+Mono:wght@100;200;300;400;500;600;700&display=swap');



    .main {
        padding: 19px 24px;
        background-color: #ffff;
        max-width: 270px;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        position: relative;
    }

    .main_date span {
        color: #000;
        text-align: center;
        font-family: Roboto Mono;
        font-size: 9px;
        font-style: normal;
        font-weight: 400;
        line-height: normal;
        letter-spacing: -0.45px;
    }

    .main_id {
        border: dashed 1px #000;
        border-radius: 5px;
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative;
        margin-top: 15px;
        padding: 15px 5px;
    }

    .main_id small {
        position: absolute;
        top: -7px;
        background-color: #ffff;
        color: #000;
        text-align: center;
        font-family: Roboto Mono;
        font-size: 9px;
        font-style: normal;
        font-weight: 500;
        line-height: normal;
        letter-spacing: 1.125px;
    }

    .main_id p {
        margin: 0;
        color: #000;
        text-align: center;
        font-family: Roboto Mono;
        font-size: 12.6px;
        font-style: normal;
        font-weight: 700;
        line-height: 10.8px;
        /* 85.714% */
        letter-spacing: 0.9px;
    }

    .main_type {
        display: flex;
        width: 100%;
        justify-content: space-between;
        border-bottom: dashed 1px #979797;
        padding: 11px;
    }

    .main_type p,
    .main_address .name p {
        margin: 0;
        color: #000;
        text-align: right;
        font-family: Roboto Mono;
        font-size: 9px;
        font-style: normal;
        font-weight: 400;
        line-height: normal;
        letter-spacing: 0.45px;
    }

    .main_type span,
    .main_address .name span {
        color: #6D7278;
        font-family: Roboto Mono;
        font-size: 9px;
        font-style: normal;
        font-weight: 400;
        line-height: normal;
        letter-spacing: 0.45px;
    }

    .main_address {
        border-bottom: dashed 1px #979797;
        padding: 11px;
        width: 100%;
    }

    .name {
        display: flex;
        width: 100%;
        justify-content: space-between;
        margin-top: 5px;
    }

    .main_bottom {
        position: absolute;
        bottom: -20px;
    }

    .main_bottom img {
        width: 270px;
    }
</style>
<div id="main-content">
    <div id="header">
        <div class="header-left float-left">
            <i id="toggle-left-menu" class="ion-android-menu"></i>
        </div>
        <div class="header-right float-right" style="display: flex">
            <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#exampleModal">
                <dotlottie-player src="https://lottie.host/cefd9446-3221-49d6-afd4-db20865793ae/8RUz2SVNIa.json" background="transparent" speed="1" loop autoplay></dotlottie-player>
            </button>
            <a href="./logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i></a>
        </div>
    </div>

    <div id="page-container">
        <div class="alerts">
            <div class="alert alert-danger alert-dismissible fade show" role="alert" id="error" style="display:none;">
                Mahsulot qo`shilmadi! Iltmos boshqadan urinib qo`shing
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>

            <div class="alert alert-success alert-dismissible fade show" role="alert" id="success" style="display:none;">
                Mahsulot Skaldga muvaffaqiyatli qo`shildi
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>

            <div class="card">
                <div class="card-header">Detailed Bills</div>
                 <div class="card-body">
                <form action="" method="post">
                    <table>
                        <tr>
                            <td>Bill No:</td>
                            <td><input type="text" name="bill_id" id="" class="form-control" value="MB<?php echo $bill_no; ?>" readonly> </td>
                        </tr>
                        <tr>
                            <td>Full Name:</td>
                            <td><input type="text" name="client_name" id="" class="form-control" value="<?php echo $client_name; ?>" readonly> </td>
                        </tr>
                        <tr>
                            <td>Bill Date:</td>
                            <td><input type="text" name="date" id="" class="form-control" value="<?php echo $date; ?>" readonly> </td>
                        </tr>
                    </table>
                    <br>
                    <table class="table">
                        <tr>
                            <th>Product Name</th>
                            <th>Product Unit</th>
                            <th>Packing Size</th>
                            <th>Price</th>
                            <th>Qty</th>
                            <th></th>
                            <th>Total</th>
                            <!-- <th>Return</th> -->
                        </tr>

                        <?php
                        $total = 0;
                        $res = mysqli_query($link, "select * from billing_details where bill_id=$id");
                        while ($row = mysqli_fetch_array($res)) {
                        ?>
                            <tr>
                                <td><input type="text" name="product_qty[<?php echo $row["product_name"] ?>]" id="" class="form-control" value="<?php echo $row["product_name"] ?>" readonly> </td>
                                <td><?php echo $row["product_unit"] ?></td>
                                <td><?php echo $row["packing_size"] ?></td>
                                <td><?php echo $row["price"] ?>so`m</td>
                                <td><input type="text" name="product_qty[<?php echo $row["product_name"] ?>]" id="" class="form-control" value="<?php echo $row["qty"] ?>" readonly> </td>
                                <td><input type="text" name="status" id="" class="form-control" value="3" readonly style="display: none;"></td>
                                <td><?php echo ($row["price"] * $row["qty"]) ?></td>
                                <!-- <td><a href="return.php?id=<?php echo $row["id"]; ?>">Return</a></td> -->
                            </tr>

                        <?php

                            $total = $total + ($row["price"] * $row["qty"]);
                        }
                        ?>
                    </table>
            </div>
            <div class="card-footer">
                Grand Total: <?php echo $total; ?> <b>so`m</b>
            </div>
            </form>
        </div>

        <div class="main">
            <div class="main_img">
                <img src="./img/black.png" alt="">
            </div>
            <div class="main_date">
                <span><?php echo $date; ?> • 9:27:53 AM</span>
            </div>
            <div class="main_id">
                <small>Buyurtma ID</small>
                <p>MB<?php echo $bill_no; ?></p>
            </div>
            <div class="main_type">
                <span>To`lov Turi</span>
                <p>Naqt</p>
            </div>

            <div class="main_address">
                <div class="name">
                    <span>Mijoz Nomi</span>
                    <p><?php echo $client_name; ?></p>
                </div>
                <div class="name">
                    <span>Mijoz Kategoriyasi</span>
                    <p>A</p>
                </div>
                <div class="name">
                    <span>Manzil</span>
                    <p><?php echo $client_address; ?></p>
                </div>
            </div>

            <div class="main_address" style="padding-bottom: 25px;">
                <div class="name">
                    <span>Xaridlar</span>
                </div>
                <?php
                $total = 0;
                $res = mysqli_query($link, "select * from billing_details where bill_id=$id");
                while ($row = mysqli_fetch_array($res)) {
                ?>
                    <div class="name">
                        <span><?php echo $row["product_name"] ?></span>
                        <p><?php echo $row["qty"] ?><?php echo $row["product_unit"] ?> x <?php echo $row["price"] ?>uzs = <?php echo ($row["price"] * $row["qty"]) ?>uzs</p>
                    </div>


                <?php

                    $total = $total + ($row["price"] * $row["qty"]);
                }
                ?>
                <div class="name" style="margin-top: 20px;">
                    <span style="font-weight: 900; color: #000;">Jami</span>
                    <p style="font-weight: 900;"><?php echo $total; ?> UZS</p>
                </div>
            </div>

            <div class="main_address" style="border-bottom: #ffff;">
                <div class="name">
                    <span>Agent</span>
                    <p><?php echo $username; ?></p>
                </div>
            </div>
            <div class="main_bottom">
                <img src="./img/bottom.png" alt="">
            </div>
        </div>
    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="d-flex flex-column">
                    <h5 class="modal-title text-danger" id="exampleModalLabel">ESLATMA !!!</h5>
                    <span><b>Buyurtmani Tasdiqlash/Bekor qilish uchun Tasdiqlash yoki Bekor Qilish tugmalarini iltimos bir marta bosing.</b> </span>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-footer">
                MasterBrother MJCH
            </div>
        </div>
    </div>
</div>

<?php


$res = mysqli_query($link, "select * from stock_master");
while ($row = mysqli_fetch_array($res)) {
    $product_name = $row["product_name"];
}

if (isset($_POST["acept"])) {
    $count = 0;
    $res = mysqli_query($link, "select * from billing_header where bill_no='$_POST[bill_no]'");
    $count = mysqli_num_rows($res);
    if ($count > 0) {
?>
        <script type="text/javascript">
            document.getElementById('success').style.display = "none";
            document.getElementById('error').style.display = "block";
            setTimeout(function() {
                window.location.href = "view_bills.php";
            }, 3000);
        </script>
    <?php
    } else {
        $productQuantities = $_POST['product_qty'];
        foreach ($productQuantities as $product_name => $product_qty) {
            mysqli_query($link, "update stock_master set packing_size=packing_size-'$product_qty', product_qty=product_qty-'$product_qty' where product_name='$product_name'");
            mysqli_query($link, "update billing_header set status='2' where bill_no='$bill_no'");

            // mysqli_query($link, "insert into deliver values(NULL,'$bill_no', '$date', '$client_name','0')");
        }
    ?>
        <script type="text/javascript">
            document.getElementById('error').style.display = "none";
            document.getElementById('success').style.display = "block";
            setTimeout(function() {
                window.location.href = "view_bills.php";
            }, 3000);
        </script>
    <?php

    }
}






if (isset($_POST["cancel"])) {

    // mysqli_query($link, "update stock_master set product_qty=product_qty+'$_POST[qty]', packing_size=packing_size+'$_POST[qty]' where product_name='$product_name'");
    mysqli_query($link, "update billing_header set status='3' where bill_no='$bill_no'");
    mysqli_query($link, "delete from billing_details where bill_id=$id") or die(mysqli_error($link));
    ?>
    <script type="text/javascript">
        document.getElementById('error').style.display = "none";
        document.getElementById('success').style.display = "block";
        setTimeout(function() {
            window.location.href = "view_bills.php";
        }, 3000);
    </script>
<?php
}




?>

<?php
include "footer.php"
?>