<?php
include "connection.php";
?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Hello, world!</title>
</head>

<body>
    <div id="filters">
        <select name="fetchval" id="fetchval">
            <option value="" disabled="" selected="">Select Filter</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3 </option>
        </select>
    </div>

    <div class="container">
        <table class="table">
            <thead>
                <tr>
                    <th>Sr No</th>
                    <th>Username</th>
                    <th>Type</th>
                    <th>Date</th>
                    <th>Porduct Id</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $res = mysqli_query($link, "select * from billing_header");
                while ($row = mysqli_fetch_array($res)) {
                ?>
                    <tr>
                        <td><?php echo $row["id"] ?></td>
                        <td><?php echo $row["full_name"] ?></td>
                        <td><?php echo $row["bill_type"] ?></td>
                        <td><?php echo $row["date"] ?></td>
                        <td><?php echo $row["bill_no"] ?></td>
                        <td><?php echo $row["status"] ?></td>
                        
                    </tr>

                <?php

                }
                ?>
            </tbody>
        </table>
    </div>

    <script
  src="https://code.jquery.com/jquery-3.7.1.js"
  integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4="
  crossorigin="anonymous"></script>

    <script type="text/javascript">
        $(document).ready(function(){
            $("#fetchval").on('change', function(){
                var value = $(this).val();
                // alert(value);
                $.ajax({
                    url : "fetch_status.php",
                    type: "POST",
                    data: 'request='+value,
                    beforeSend:function(){
                        $(".container").html("<span>Working...</span>");
                    },
                    success:function(data){
                        $(".container").html(data);
                    }
                })
            });
        });
    </script>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>


</body>

</html>