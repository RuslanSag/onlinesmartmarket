<?php
include "../../../user/user/connection.php";
$product_name=$_GET["product_name"];
$res=mysqli_query($link, "select * from stock_master where product_name='$product_name' ");
?>

<?php

while($row=mysqli_fetch_array($res))
{
    ?>
    
        <div>Ta`minotchi :<input type="text" name="company_name" id="company_name"  class="form-control" value="<?php echo  $row["product_company"]; ?>" readonly></div>
        <div>Mahsulot Nomi :<input type="text" name="product_name" id="product_name"class="form-control" value="<?php echo  $row["product_name"]; ?>"  readonly></div>
        <div>Mahsulot Hajm Birligi :<input type="text" name="unit" class="form-control" id="unit" value="<?php echo  $row["product_unit"]; ?>"  readonly></div>
        <div>Skladdagi Mahsulot Qoldig`i :<input type="text"  name="packing_size" class="form-control" id="packing_size" value="<?php echo  $row["product_qty"]; ?>"  readonly></div>
        <div>Narxi :<input type="text"name="price" id="price" class="form-control" value="<?php echo  $row["product_selling_price"]; ?>"  readonly></div>
        <div>Kearakli Miqdorni Kiriting :<input type="text" name="qty" id="qty" class="form-control" value="" onkeyup="generate_total(this.value)" class="form-control" autocomplete="off"></div>
        <div>Jami :<input type="text"  name="total" id="total"  class="form-control" value=""  readonly></div>
    <?php
} 
?>

<script type="text/javascript">
    
    function generate_total(qty) {
            document.getElementById("total").value = eval(document.getElementById("price").value) * eval(document.getElementById("qty").value);
        }

</script>

