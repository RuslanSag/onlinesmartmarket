<?php
include "../../user/user/connection.php";
$client_name = $_GET["client_name"];
$res = mysqli_query($link, "select * from payment_base where client_name='$client_name' ");


?>
<table class="table">
    <tr>
        <th>Mijoz ID</th>
        <th>Mijoz Nomi</th>
        <th>Buyurtma Kodi</th>
        <th>Operatsiya Vaqti</th>
        <th>Debit</th>
        <th>Kredit</th>
    </tr>





    <?php
    while ($row = mysqli_fetch_array($res)) {
    ?>
        <tr>
            <td scope="row"><?php echo $row["client_id"] ?></td>
            <td><?php echo $row["client_name"] ?></td>
            <td><a href="view_bill_details2.php?bill_no=<?php echo $row["bill_no"]; ?>"><?php echo $row["bill_no"] ?> </a></td>
            <td><?php echo $row["date"] ?></td>
            <td><?php echo $row["main_pay"] ?></td>
            <td><?php echo $row["kredit"] ?></td>

        </tr>

        <tr>
            <?php
            // // SQL query to sum the main_pay and kredit columns for each client_id and select only one record for each client_id
            $sql = "SELECT DISTINCT client_name, SUM(main_pay) AS total_main_pay, SUM(kredit) AS total_kredit FROM payment_base WHERE client_name='$client_name'  GROUP BY client_name";
            $result = $link->query($sql);
            
            if ($result->num_rows > 0) {
                // Output data of each row
                while ($row = $result->fetch_assoc()) {
                    $test = $row["total_main_pay"];
                    $test2 = $row["total_kredit"];
                    $test3 = $row["total_kredit"] - $row["total_main_pay"];
                    // echo "Client ID: " . $row["client_name"] . " - Total Main Pay: " . $row["total_main_pay"] . " - Total Kredit: " . $row["total_kredit"] . "<br>";
                }
            } else {
                echo "0 results";
            }
            
           

            ?>
        </tr>
        <?php
    }
    ?>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td>Jami: <?php echo $test ?></td>
        <td><?php echo $test2 ?></td>
    </tr>

    <tr>
        <td></td>
        <td></td>
        <td>SALDO: <?php echo $test3 ?></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
</table>