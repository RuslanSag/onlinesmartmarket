<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>


<?php
include "connection.php";

$id = $_GET["id"];
$unit = "";

$res = mysqli_query($link, "select * from units where id=$id");
while ($row = mysqli_fetch_array($res)) {
    $unit = $row["unit"];
}
?>

<?php
include "header.php";
?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="alerts">
            <div class="alert alert-danger alert-dismissible fade show" role="alert" id="error" style="display:none;">
                Bu Hajm Birlik mavjud! Iltmos boshqa Hajm Birlik qo`shing
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>

            <div class="alert alert-success alert-dismissible fade show" role="alert" id="success" style="display:none;">
                Hajm Birlik muvaffaqiyatli yangilandi
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
        <div class="col-lg-5">
            <div class="card">
                <div class="card-header">Hajm Birlikni Tahrirlash</div>
                <div class="card-body p-3">
                    <form name="form1" action="" method="post">
                        <div class="mb-3">
                            <label class="form-label">Hajm Birlikni</label>
                            <input type="text" class="form-control" name="unitname" value="<?php echo $unit ?>">
                        </div>
                        <button type="submit" name="submit1" class="btn btn-primary">Tahrirlash</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->
</div>
<!-- Content wrapper -->



<?php
if (isset($_POST["submit1"])) {
    mysqli_query($link, "update units set unit='$_POST[unitname]' where id=$id") or die(mysqli_error($link));
?>
    <script type="text/javascript">
        document.getElementById('success').style.display = "block";
        setTimeout(function() {
            window.location = "add_new_unit.php";
        }, 3000);
    </script>
<?php
}

?>

<?php
include "footer.php"
?>