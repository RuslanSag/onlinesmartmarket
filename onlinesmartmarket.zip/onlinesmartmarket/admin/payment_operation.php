<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>


<?php
include "header.php";
include "connection.php";

$id = $_GET["id"];
$client_id = "";
$client_name = "";
$client_region = "";
$client_address = "";
$client_number = "";
$client_category = "";
$date = "";
$bill_no = "";

$res = mysqli_query($link, "select * from billing_header where id=$id");
while ($row = mysqli_fetch_array($res)) {
    $client_id = $row["client_id"];
    $client_name = $row["client_name"];
    $client_region = $row["client_region"];
    $client_address = $row["client_address"];
    $client_number = $row["client_number"];
    $client_category = $row["client_category"];
    $date = $row["date"];
    $bill_no = $row["bill_no"];
}


?>

<style>
    .payment_input {
        border: none !important;
    }

    .payment_form {
        border: 1px solid #999;
        padding: 15px;
        background: #FFFF;
    }

    .payment_form input {
        border: 1px solid #999 !important;
    }

    .payment button {
        background-color: #464e62;
        color: #FFFF;
    }
</style>



<div id="main-content">
    <div id="header">
        <div class="header-left float-left">
            <i id="toggle-left-menu" class="ion-android-menu"></i>
        </div>
        <div class="header-right float-right">
            <a href="./logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i></a>
        </div>
    </div>

    <div id="page-container">
        <div class="card">
            <div class="card-header">Detailed Bills</div>
            <div class="card-body">
                <table>
                    <tr>
                        <td>Bill No:</td>
                        <td><?php echo $bill_no; ?></td>
                    </tr>
                    <tr>
                        <td>Full Name:</td>
                        <td><?php echo $client_name; ?></td>
                    </tr>
                    <tr>
                        <td>Hudud:</td>
                        <td><?php echo $client_region; ?></td>
                    </tr>
                    <tr>
                        <td>Manzil:</td>
                        <td><?php echo $client_address; ?></td>
                    </tr>
                    <tr>
                        <td>Tel:</td>
                        <td><?php echo $client_number; ?></td>
                    </tr>
                    <tr>
                        <td>Kategory:</td>
                        <td><?php echo $client_category; ?></td>
                    </tr>

                    <tr>
                        <td>Bill Date:</td>
                        <td><?php echo $date; ?></td>
                    </tr>
                </table>
                <br>
                <table class="table">
                    <tr>
                        <th>Mahsulot</th>
                        <th>Narxi</th>
                        <th>Hajmi</th>
                        <th>Jami</th>
                    </tr>

                    <?php
                    $total = 0;
                    $res = mysqli_query($link, "select * from billing_details where bill_id=$id");
                    while ($row = mysqli_fetch_array($res)) {
                    ?>
                        <tr>
                            <td><?php echo $row["product_name"] ?></td>
                            <td><?php echo $row["price"] ?></td>
                            <td><?php echo $row["qty"] ?><?php echo $row["product_unit"] ?></td>
                            <td><?php echo ($row["price"] * $row["qty"]);
                                echo "so`m"  ?></td>
                        </tr>

                    <?php
                        $total = $total + ($row["price"] * $row["qty"]);
                    }
                    ?>
                </table>
            </div>
            <div class="card-footer">
                Grand Total: <?php echo $total; ?> <b>so`m</b>
            </div>
        </div>
        <div class="alert alert-danger" role="alert" id="error" style="display:none;">
            Bu Mijoz Buyurtma To`lov Hisoboti, Hisobchiga jo`natilgan. Iltmos Hisobchiga murojat qiling !!!</div>

        <div class="alert alert-success" role="alert" id="success" style="display:none;">
            To`lov hisoboti, Hisobchiga muvaffaqiyatli jo`natildi!!!</div>

        <div class="d-flex payment justify-content-between w-100">
            <form action="" class="d-flex payment_form align-items-center justify-content-between w-100" method="POST">
                <div class="d-flex flex-column">
                    Bill No:<input type="text" class="payment_input" value='<?php echo $bill_no; ?>' name="bill_no" readonly />
                    Mijoz ID:<input type="text" class="payment_input" value='<?php echo $client_id; ?>' name="client_id" readonly />
                    Mijoz:<input type="text" class="payment_input" value='<?php echo $client_name; ?>' name="client_name" readonly />
                    Hudud:<input type="text" class="payment_input" value='<?php echo $client_region; ?>' name="client_region" readonly />
                    Manzil:<input type="text" class="payment_input" value='<?php echo $client_address; ?>' name="client_address" readonly />
                    Tel:<input type="text" class="payment_input" value='<?php echo $client_number; ?>' name="client_number" readonly />
                    Kategory:<input type="text" class="payment_input" value='<?php echo $client_category; ?>' name="client_category" readonly />
                </div>
                <div class="d-flex flex-column">
                    Jami:<input type="text" class="payment_input" value=' <?php echo $total; ?> ' name="main_pay" id="num1" readonly />
                </div>
                <div class="d-flex flex-column">
                    To`landi:<input type="text" class="payment_input" name="kredit" id="num2" />
                </div>
                <div class="d-flex flex-column">
                    Qoldiq <input type="text" class="payment_input" name="debit" id="subt" readonly />
                </div>
                <div class="d-flex flex-column">
                    Sana <input type="text" class="payment_input" value="<?php $currentDate = date('Y-m-d');
                                                                            echo $currentDate; ?>" name="date" id="subt" readonly />
                </div>

                <button class="btn" name="test" style="">Hisobchiga Jo`natish</button>
            </form>
        </div>
    </div>
</div>



<script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>

<script type="text/javascript">
    $(function() {
        $("#num1, #num2").on("keydown keyup", sum);

        function sum() {
            $("#sum").val(Number($("#num1").val()) + Number($("#num2").val()));
            $("#subt").val(Number($("#num1").val()) - Number($("#num2").val()));
        }
    });
</script>

<?php
if (isset($_POST["test"])) {
    $count = 0;
    $res = mysqli_query($link, "select * from payment_base where bill_no='$_POST[bill_no]'");
    $count = mysqli_num_rows($res);

    if ($count > 0) {
?>
        <script type="text/javascript">
            document.getElementById('success').style.display = "none";
            document.getElementById('error').style.display = "block";
            setTimeout(function() {
                window.location.href = window.location.href;
            }, 3000);
        </script>
    <?php
    } else {

        mysqli_query($link, "insert into payment_base values(NULL, '$_POST[bill_no]','$_POST[client_id]','$_POST[client_name]','$_POST[client_region]','$_POST[client_address]','$_POST[client_number]', '$_POST[client_category]', '$_POST[main_pay]','','$_POST[kredit]','$_POST[debit]','$_POST[date]')");

    ?>
        <script type="text/javascript">
            document.getElementById('success').style.display = "block";
            setTimeout(function() {
                window.location.href = window.location.href;
            }, 3000);
        </script>
<?php
    }
}
?>

<?php
include "footer.php";
?>