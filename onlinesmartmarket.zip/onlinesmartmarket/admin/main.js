$(function(){
    // bind change event to procuring quantity
    $('input[name="procuring[]"]').change(function(){
      var $parentTR = $(this).closest('.info');
      // read value for current quantity.
      var current = $parentTR.find('input[name="current[]"]').val();
  
      // read value for procuring quantity.
      var procuring = $(this).val();
  
      // do substraction and set value in 5th column for updated quantity.
      var updated = parseFloat(current) - parseFloat(procuring);
   $parentTR.find('input[name="updated[]"]').val(updated );
    });
  });