<?php
include "../../user/user/connection.php";
$client_name=$_GET["client_name"];
$res=mysqli_query($link, "select * from client_base where client_name='$client_name' ");
?>

<?php

while($row=mysqli_fetch_array($res))
{
    ?>
    
        <div>Mijoz ID :<input type="text" name="client_id" class="form-control" value="<?php echo  $row["client_id"]; ?>" readonly></div>
        <div>Mijoz Regioni :<input type="text" name="client_region" class="form-control" value="<?php echo  $row["client_region"]; ?>" readonly></div>
        <div>Mijoz Address :<input type="text" name="client_address" class="form-control" value="<?php echo  $row["client_address"]; ?>"  readonly></div>
        <div>Mijoz Nomeri :<input type="text" name="client_number" class="form-control" value="<?php echo  $row["client_number"]; ?>"  readonly></div>
        <div>Mijoz Kategoriyasi :<input type="text" name="client_category" class="form-control" value="<?php echo  $row["client_category"]; ?>"  readonly></div>
    <?php
} 
?>

