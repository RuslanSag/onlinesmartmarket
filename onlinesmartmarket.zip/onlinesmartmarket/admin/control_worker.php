<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>

<?php

include "connection.php";

$username = "";
$user_id = "";

$res = mysqli_query($link, "select * from payment_base");
while ($row = mysqli_fetch_array($res)) {
    $username = $row["username"];
    $user_id = $row["user_id"];
}

?>

<?php
include "header.php";
?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex">
                        <h6>Agentlar Bo`yicha Hisobot Bo`limi</h6>
                    </div>
                </div>
                <div class="card-body p-3">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Xodim</th>
                                <th scope="col">Jami</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php
                            // Query to retrieve unique combinations of username and user_id and sum the kredit column
                            $sql = "SELECT username, user_id, SUM(kredit) AS total_kredit FROM payment_base GROUP BY username, user_id";

                            $result = $link->query($sql);

                            if ($result->num_rows > 0) {
                                // Output data of each row
                                while ($row = $result->fetch_assoc()) {
                                    $username = $row["username"];
                                    $test = $row["total_kredit"];
                            ?>
                                    <tr>
                                        <td> <?php echo $username ?></td>
                                        <td><?php echo $test ?> so`m</td>
                                    </tr>
                            <?php
                                    // echo "Username: " . $row["username"] . " - User ID: " . $row["user_id"] . " - Total Kredit: " . $row["total_kredit"] . "<br>";
                                }
                            } else {
                                echo "0 results";
                            }
                            ?>


                        </tbody>
                    </table>

                    <?php echo '<br>' ?>


                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->
</div>
<!-- Content wrapper -->




<script type="text/javascript">
    //    function formatPrice() {
    //       // Get the input value
    //       let input = document.getElementById('priceInput');
    //       let value = input.value.replace(/\D/g, ''); // Remove non-numeric characters

    //       // Format the value with spaces
    //       let formattedValue = '';
    //       for (let i = 0; i < value.length; i++) {
    //         if (i > 0 && (value.length - i) % 3 === 0) {
    //           formattedValue += ' '; // Insert a space every three digits
    //         }
    //         formattedValue += value.charAt(i);
    //       }

    //       // Update the input value with the formatted price
    //       input.value = formattedValue;
    //     }
</script>

<?php
include "footer.php"
?>