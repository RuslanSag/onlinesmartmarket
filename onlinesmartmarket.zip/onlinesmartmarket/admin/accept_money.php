<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>


<?php
include "connection.php";
include "header.php";

$id = $_GET["id"];
$bill_no = "";
$client_id = "";
$client_name = "";
$client_region = "";
$client_address = "";
$client_number = "";
$client_category = "";
// $main_pay = "";
$agent_kredit = "";
$kredit = "";
$date = "";
$username = "";

$res = mysqli_query($link, "select * from payment_base where id=$id");
while ($row = mysqli_fetch_array($res)) {
    $bill_no = $row["bill_no"];
    $client_id = $row["client_id"];
    $client_name = $row["client_name"];
    $client_region = $row["client_region"];
    $client_address = $row["client_address"];
    $client_number = $row["client_number"];
    $client_category = $row["client_category"];
    // $main_pay=$row["main_pay"];
    $agent_kredit = $row["agent_kredit"];
    $kredit = $row["kredit"];
    $date = $row["date"];
    $username = $row["username"];
}
?>

<div id="main-content">
    <div id="header">
        <div class="header-left float-left">
            <i id="toggle-left-menu" class="ion-android-menu"></i>
        </div>
        <div class="header-right float-right">
            <a href="./logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i></a>
        </div>
    </div>

    <div id="page-container">

        <div class="col-lg-5">
            <div class="card">
                <div class="card-header justify-content-between d-flex">
                    <span>To`lovni Tasdiqlash</span>
                    <small>
                        <?php echo $username ?> dan
                    </small>
                </div>
                <div class="alerts">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert" id="error" style="display:none;">
                        Bu Ta`minotchi mavjud! Iltmos boshqa Ta`minotchi qo`shing
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>

                    <div class="alert alert-success alert-dismissible fade show" role="alert" id="success" style="display:none;">
                        To`lov Kassaga muvaffaqiyatli Qabul Qilindi
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                </div>
                <div class="card-body p-3">
                    <form name="form1" action="" method="post">
                        <div class="mb-3">
                            <label class="form-label">Buyurtma Raqami</label>
                            <input type="text" class="form-control" name="" value="MB<?php echo $bill_no; ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Mijoz ID</label>
                            <input type="text" class="form-control" name="" value="<?php echo $client_id; ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Mijoz</label>
                            <input type="text" class="form-control" name="" value="<?php echo $client_name; ?>" readonly>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Agentga To`lov</label>
                            <input type="text" class="form-control" name="" value="<?php echo $agent_kredit; ?>" readonly>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Qabul Qilingan To`lov</label>
                            <input type="text" class="form-control" name="kredit" value="<?php echo $agent_kredit; ?>" required>
                        </div>

                        

                        <div class="mb-3">
                            <label class="form-label">Sanasi</label>
                            <input type="text" class="form-control" name="" value="<?php echo $date; ?>" readonly>
                        </div>
                </div>

                <button type="submit" name="submit1" class="btn btn-primary edit"><span>Tasdiqlash</span> <i class="fa-solid fa-check"></i></button>
                </form>

                
            </div>
        </div>
    </div>
</div>
</div>

<?php
if (isset($_POST["submit1"])) {
    mysqli_query($link, "update payment_base set agent_kredit='', kredit='$_POST[kredit]' where id=$id") or die(mysqli_error($link));
?>
    <script type="text/javascript">
        document.getElementById('success').style.display = "block";
        setTimeout(function() {
            window.location = "payment_accept.php";
        }, 3000);
    </script>
<?php
}

?>

<?php
include "footer.php"
?>