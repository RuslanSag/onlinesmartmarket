<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>


<?php
include "connection.php"
?>

<?php
include "header.php";
?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y " id="">
        <div class="alerts">
            <div class="alert alert-danger alert-dismissible fade show" role="alert" id="error" style="display:none;">
                Mahsulot qo`shilmadi! Iltmos boshqadan urinib qo`shing
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        
            <div class="alert alert-success alert-dismissible fade show" role="alert" id="success" style="display:none;">
                Mahsulot Skaldga muvaffaqiyatli qo`shildi
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
        <div class="col-lg-5">
            <div class="card">
                <div class="card-header">Add Product to Stock</div>
                <div class="card-body p-3">
                    <form name="form1" action="" method="post">
                        <div class="mb-3">
                            <label class="form-label">Select a Supplier:</label>
                            <select class="form-control" name="company_name" id="company_name">
                                <?php
                                $res = mysqli_query($link, "select * from company_name");
                                while ($row = mysqli_fetch_array($res)) {
                                    echo "<option>";
                                    echo $row["company_name"];
                                    echo "</option>";
                                }
                                ?>
                            </select>
                        </div>
        
                        <div class="mb-3">
                            <label class="form-label">Enter Product Name:</label>
                            <input type="text" class="form-control" name="product_name" id="product_name" placeholder="Mahsulot Nomini Kiriting...">
                        </div>
        
                        <div class="mb-3">
                            <label class="form-label">Product Size:</label>
                            <input type="text" class="form-control" name="packing_size" id="packing_size">
                        </div>
        
                        <div class="mb-3" style="display: none;">
                            <label class="form-label">Enter Product Size:</label>
                            <input type="text" class="form-control" name="qty" id="qty">
                        </div>
        
        
        
                        <div class="mb-3">
                            <label class="form-label">Product Price:</label>
                            <input type="text" class="form-control" name="product_price" value="0" readonly>
                        </div>
        
                        <div class="mb-3">
                            <label class="form-label">Size Unit:</label>
                            <select class="form-control" name="unit" id="unit">
                                <?php
                                $res = mysqli_query($link, "select * from units");
                                while ($row = mysqli_fetch_array($res)) {
                                    echo "<option>";
                                    echo $row["unit"];
                                    echo "</option>";
                                }
                                ?>
                            </select>
                        </div>
        
                        <div class="alert alert-danger" role="alert" id="error" style="display:none;">
                        This Product is available! Please add another Product
                        </div>
        
                        <div class="alert alert-success" role="alert" id="success" style="display:none;">
                        Product added successfully
                        </div>
                        <button type="button" onclick="add_session();" class="btn btn-primary">Add</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <form action="" name="form1" action="" method="post">
                <div class="card">
                    <div class="card-header">
                        <b>Product Information</b>
                    </div>
                    <div class="card-body">
                        <div id="bill_products"></div>
                    </div>
                    <div class="card-footer">
                        <input type="submit" value="Add" class="btn btn-primary" name="submit1">
                    </div>
        
                </div>
            </form>
        </div>
    </div>
    <!-- / Content -->
   

<script>
    function add_session() {
        var company_name = document.getElementById("company_name").value;
        var product_name = document.getElementById("product_name").value;
        var unit = document.getElementById("unit").value;
        var packing_size = document.getElementById("packing_size").value;
        var qty = document.getElementById("qty").value;

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {

            if (xmlhttp.responseText == "") {
                load_billing_products();
                document.getElementById('error').style.display = "none";
                document.getElementById('success').style.display = "block";
                setTimeout(function() {
                    window.location.href = window.location.href;
                }, 3000);
            } else {
                load_billing_products();
            }

        };
        xmlhttp.open("GET", "masterajax/save_in_session.php?company_name=" + company_name + "&product_name=" + product_name + "&unit=" + unit + "&packing_size=" + packing_size, true);
        xmlhttp.send();

    }

    function load_billing_products() {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("bill_products").innerHTML = xmlhttp.responseText;
                load_total_bill();
            }
        };
        xmlhttp.open("GET", "masterajax/load_billing_products.php", true);
        xmlhttp.send();
    }

    load_billing_products();
</script>

<?php


if (isset($_POST["submit1"])) {
    $max = sizeof($_SESSION['cart']);

    for ($i = 0; $i < $max; $i++) {
        $company_name_session = "";
        $product_name_session = "";
        $unit_session = "";
        $packing_size_session = "";
        $price_session = "";


        if (isset($_SESSION['cart'][$i])) {

            foreach ($_SESSION['cart'][$i] as $key => $val) {
                if ($key == "company_name") {
                    $company_name_session = $val;
                } else if ($key == "product_name") {
                    $product_name_session = $val;
                } else if ($key == "unit") {
                    $unit_session = $val;
                } else if ($key == "packing_size") {
                    $packing_size_session = $val;
                }
            }
            if ($company_name_session != "") {
                $count = 0;
                $res = mysqli_query($link, "select * from stock_master where product_name='$product_name_session'");
                $count = mysqli_num_rows($res);
                if ($count > 0) {
                    mysqli_query($link, "update stock_master set packing_size=packing_size+$packing_size_session, product_qty=product_qty+$packing_size_session where product_company='$company_name_session' && product_name='$product_name_session' && product_unit='$unit_session'");

?>
                    <script type="text/javascript">
                        document.getElementById('success').style.display = "none";
                        document.getElementById('error').style.display = "block";
                        setTimeout(function() {
                            window.location.href = window.location.href;
                        }, 50);
                    </script>
                <?php
                } else {
                    mysqli_query($link, "insert into stock_master values(NULL,'$company_name_session','$product_name_session', '$unit_session', '$packing_size_session', '$price_session', '0', '', '', '', '1')");

                ?>
                    <script type="text/javascript">
                        document.getElementById('error').style.display = "none";
                        document.getElementById('success').style.display = "block";
                        setTimeout(function() {
                            window.location.href = window.location.href;
                        }, 50);
                    </script>
    <?php
                }

                // mysqli_query($link, "INSERT INTO `new_stock`(`id`, `bill_id`, `product_company`, `product_name`, `product_unit`, `packing_size`, `product_qty`, `product_selling_price`) VALUES ('NULL','$company_name_session','[value-3]','[value-4]','[value-5]','[value-6]','[value-7]','[value-8]'))");
            }
        }
    }
    unset($_SESSION['cart']);

    ?>
    <script type="text/javascript">
        alert("bill a`lo");
        window.location.href = window.location.href;
    </script>
<?php
}
?>



<?php
include "footer.php"
?>