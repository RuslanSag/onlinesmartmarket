<?php
include "connection.php";

$user_id = 0;
$res = mysqli_query($link, "select * from user_registration order by id desc limit 1");
while ($row = mysqli_fetch_array($res)) {
    $user_id = $row["user_id"];
}
?>
<?php
include "header.php";
?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="alerts">
            <div class="alert alert-danger alert-dismissible fade show" role="alert" id="error" style="display:none;">
                Bu Foylanuvchi mavjud! Iltmos boshqa Foylanuvchi qo`shing
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>

            <div class="alert alert-success alert-dismissible fade show" role="alert" id="success" style="display:none;">
                Foylanuvchi muvaffaqiyatli qo`shildi
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
        <div class="col-lg-5">
            <div class="card">
                <div class="card-header">Yangi Ishchi Qo`shish</div>
                <div class="card-body p-3">
                    <form name="form1" action="" method="post">
                        <div class="mb-3">
                            <label class="form-label">Surname</label>
                            <input type="text" class="form-control" name="firstname" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control" name="lastname" required>
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Username</label>
                            <input type="text" class="form-control" name="username" required autocomplete="off">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" class="form-control" name="password" required autocomplete="off">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">User ID</label>
                            <div class="input-group align-items-center">
                                <span class="input-group-text" style="border-radius: 0px !important;">MB</span><input type="text" class="form-control" name="user_id" readonly value="<?php echo  generate_user_id($user_id) ?>">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Position of the employee</label>

                            <select name="role" class="form-control">
                                <option>admin</option>
                                <option>user</option>
                                <option>skladchi</option>
                            </select>
                        </div>
                        <button type="submit" name="submit1" class="btn btn-primary">Qo`shish</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <b>Personal Info</b>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#Id</th>
                                <th scope="col">Surname</th>
                                <th scope="col">Ism</th>
                                <th scope="col">Username</th>
                                <th scope="col">Password</th>
                                <th scope="col">User Id</th>
                                <th scope="col">Xodimning Lavozimi</th>
                                <th scope="col">Xolati</th>
                                <th scope="col">Tahrirlash</th>
                                <th scope="col">O`chirish</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $res = mysqli_query($link, "select * from user_registration");
                            while ($row = mysqli_fetch_array($res)) {
                            ?>
                                <tr>
                                    <th scope="row"><?php echo $row["id"] ?></th>
                                    <td><?php echo $row["firstname"] ?></td>
                                    <td><?php echo $row["lastname"] ?></td>
                                    <td><?php echo $row["username"] ?></td>
                                    <td><?php echo $row["password"] ?></td>
                                    <td><?php echo $row["user_id"] ?></td>
                                    <td><?php echo $row["role"] ?></td>
                                    <td><?php echo $row["status"] ?></td>
                                    <td class="edit"><a href="./edit_user.php?id=<?php echo $row["id"]; ?> "> <span>Tahrirlash</span> <i class="fa-solid fa-pencil"></i></a></td>
                                    <td class="delete"><a href="./delete_user.php?id=<?php echo $row["id"]; ?> "><span>O`chirish</span> <i class="fa-solid fa-trash"></i></a></td>
                                </tr>
                            <?php
                            }
                            ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->
</div>
<!-- Content wrapper -->


<?php
function generate_user_id($id)
{

    if ($id == "") {
        $id1 = 0;
    } else {
        $id1 = $id;
    }
    $id1 = $id1 + 1;

    $len = strlen($id1);

    if ($len == "1") {
        $id1 =  "0" .  $id1;
    }
    if ($len == "2") {
        $id1 =  "00" .  $id1;
    }

    if ($len == "3") {
        $id1 =  "000" .  $id1;
        // $currentDate = date('Ymd'); echo $currentDate;

    }
    if ($len == "4") {
        $id1 = "0000" .  $id1;
        // $currentDate = date('Ymd'); echo $currentDate;
    }
    if ($len == "5") {
        $id1 =  "5" .  $id1;
    }
    if ($len == "6") {
        $id1 =  "6" .  $id1;
        // $currentDate = date('Ymd'); echo $currentDate;
    }
    if ($len == "7") {
        $id1 = "7" .  $id1;
    }
    return $id1;
}
?>

<?php
if (isset($_POST["submit1"])) {
    $count = 0;
    $res = mysqli_query($link, "select * from user_registration where username='$_POST[username]'");
    $count = mysqli_num_rows($res);

    if ($count > 0) {
?>
        <script type="text/javascript">
            document.getElementById('success').style.display = "none";
            document.getElementById('error').style.display = "block";
        </script>
    <?php
    } else {
        mysqli_query($link, "insert into user_registration values(NULL, '$_POST[firstname]','$_POST[lastname]','$_POST[username]', '$_POST[user_id]' ,'$_POST[password]','$_POST[role]','active')");

    ?>
        <script type="text/javascript">
            document.getElementById('error').style.display = "none";
            document.getElementById('success').style.display = "block";
            setTimeout(function() {
                window.location.href = window.location.href;
            }, 3000);
        </script>
<?php
    }
}
?>

<?php
include "footer.php"
?>