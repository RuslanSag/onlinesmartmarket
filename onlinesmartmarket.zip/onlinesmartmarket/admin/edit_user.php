<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>


<?php
include "connection.php";

$id = $_GET["id"];
$firstname = "";
$lastname = "";
$username = "";
$password = "";
$status = "";
$role = "";
$user_id = "";
$res = mysqli_query($link, "select * from user_registration where id=$id");
while ($row = mysqli_fetch_array($res)) {
    $firstname = $row["firstname"];
    $lastname = $row["lastname"];
    $username = $row["username"];
    $password = $row["password"];
    $status = $row["status"];
    $role = $row["role"];
    $user_id = $row["user_id"];
}
?>
<?php
include "header.php";
?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="alerts">
            <div class="alert alert-danger alert-dismissible fade show" role="alert" id="error" style="display:none;">
                Bu Foylanuvchi mavjud! Iltmos boshqa Foylanuvchi qo`shing
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>

            <div class="alert alert-success alert-dismissible fade show" role="alert" id="success" style="display:none;">
                Foylanuvchi muvaffaqiyatli Yangilandi
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
        <div class="col-lg-5">
            <div class="card">
                <div class="card-header">Xodim Ma`lumotlarini Yangilash</div>
                <div class="card-body p-3">
                    <form name="form1" action="" method="post">
                        <div class="mb-3">
                            <label class="form-label">Familiya</label>
                            <input type="text" class="form-control" name="firstname" value="<?php echo $firstname ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Ism</label>
                            <input type="text" class="form-control" name="lastname" value="<?php echo $lastname ?>">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Username</label>
                            <input type="text" class="form-control" name="username" value="<?php echo $username ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">User ID</label>
                            <input type="text" class="form-control" name="username" value="<?php echo $user_id ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" class="form-control" name="password" id="myInput" value="<?php echo $password ?>">
                            <div class="d-flex mt-2">
                                <input type="checkbox" onclick="myFunction()">
                                <b style="margin-left: 10px;">Password Ko`rish</b>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Xodimning Lavozimi</label>

                            <select name="role" class="form-control">
                                <option <?php if ($role == "user") {
                                            echo "selected";
                                        } ?>>user</option>
                                <option <?php if ($role == "admin") {
                                            echo "selected";
                                        } ?>> admin</option>
                                <option <?php if ($role == "skladchi") {
                                            echo "selected";
                                        } ?>> skladchi</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Xolati</label>

                            <select name="status" class="form-control">
                                <option <?php if ($status == "active") {
                                            echo "selected";
                                        } ?>>active</option>
                                <option <?php if ($status == "inactive") {
                                            echo "selected";
                                        } ?>>inactive</option>
                            </select>
                        </div>
                        <div class="alert alert-danger" role="alert" id="error" style="display:none;">
                            Bu User mavjud! Iltmos boshqa User qo`shing
                        </div>

                        <div class="alert alert-success" role="alert" id="success" style="display:none;">
                            User muvaffaqiyatli Yangilandi!!!
                        </div>
                        <button type="submit" name="submit1" class="btn btn-primary">Tahrirlash</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->
</div>
<!-- Content wrapper -->



<?php
if (isset($_POST["submit1"])) {
    mysqli_query($link, "update user_registration set firstname='$_POST[firstname]', lastname='$_POST[lastname]', password='$_POST[password]', role='$_POST[role]', status='$_POST[status]' where id=$id") or die(mysqli_error($link));
?>
    <script type="text/javascript">
        document.getElementById('success').style.display = "block";
        setTimeout(function() {
            window.location = "add_new_user.php";
        }, 3000);
    </script>
<?php
}

?>
<script>
    function myFunction() {
        var x = document.getElementById("myInput");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
</script>
<?php
include "footer.php"
?>