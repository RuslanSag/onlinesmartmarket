<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>

<?php

include "connection.php";

?>

<?php
include "header.php";
?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex">
                        <h6>To`lovlar Bo`limi</h6>
                    </div>
                </div>
                <div class="card-body p-3">
                    <form name="form1" action="" method="post">
                        <div class="sales_product_name">
                            <div class="mb-3">
                                <label class="form-label">Mijoz </label>
                                <div class="d-flex align-items-center">
                                    <input class="form-control" name="client_name" id="client_name" onchange="select_cilent(this.value)">

                                    <!-- <a class="pluss_btn" href="./client_filter.php">
                                        <i class="fa-solid fa-plus"></i>
                                    </a> -->
                                    <button type="button" class="btn btn-primary" style="margin-left: 15px;" data-toggle="modal" data-target="#exampleModal">
                                        OK
                                    </button>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Info Mijoz:</label>
                                    <div id="client_div">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Date</label>
                                    <input type="date" class="form-control" name="bill_date" value="<?php $currentDate = date('Y-m-d');
                                                                                                    echo $currentDate; ?>" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">To`lov Summasi</label>
                                    <input type="text" class="form-control" id="priceInput" oninput="formatPrice()" name="agent_kredit" value="" required>
                                </div>


                                <button type="submit" name="submit1" class="btn btn-primary">To`lov Kiritish</button>
                            </div>






                        </div>

                    </form>
                    <div class="alerts">
                        <div class="alert alert-danger alert-dismissible fade show" role="alert" id="error" style="display:none;">
                            Iltmos boshqadan urinib qo`shing!!!
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>

                        <div class="alert alert-success alert-dismissible fade show" role="alert" id="success" style="display:none;">
                            To`lov Agent Tomonidan qabul qilindi!!!
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>

                    </div>




                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->
</div>
<!-- Content wrapper -->

<?php
if (isset($_POST["submit1"])) {
    mysqli_query($link, "insert into payment_base values(NULL, '', '$_POST[client_id]','$_POST[client_name]','','','','','','$_POST[agent_kredit]','','$_SESSION[admin]', '$_SESSION[user_id]', '$_POST[bill_date]')") or die(mysqli_error($link));


?>
    <script type="text/javascript">
        document.getElementById('error').style.display = "none";
        document.getElementById('success').style.display = "block";
        setTimeout(function() {
            window.location.href = "qarz.php";
        }, 3000);
    </script>
<?php

}
?>
<script type="text/javascript">
    function select_cilent(client_name) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("client_div").innerHTML = xmlhttp.responseText;
                // alert("ssss");
            }
        };
        xmlhttp.open("GET", "forajax_user/load_client_info_using_name.php?client_name=" + client_name, true);
        xmlhttp.send();
    }
</script>


<script type="text/javascript">
    //    function formatPrice() {
    //       // Get the input value
    //       let input = document.getElementById('priceInput');
    //       let value = input.value.replace(/\D/g, ''); // Remove non-numeric characters

    //       // Format the value with spaces
    //       let formattedValue = '';
    //       for (let i = 0; i < value.length; i++) {
    //         if (i > 0 && (value.length - i) % 3 === 0) {
    //           formattedValue += ' '; // Insert a space every three digits
    //         }
    //         formattedValue += value.charAt(i);
    //       }

    //       // Update the input value with the formatted price
    //       input.value = formattedValue;
    //     }
</script>

<?php
include "footer.php"
?>