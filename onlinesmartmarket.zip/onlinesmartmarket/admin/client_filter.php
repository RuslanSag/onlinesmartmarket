<?php
include "connection.php";
$client_id = 0;
$res = mysqli_query($link, "select * from client_base order by id desc limit 1");
while ($row = mysqli_fetch_array($res)) {
    $client_id = $row["client_id"];
}
?>
<script src="https://unpkg.com/@dotlottie/player-component@latest/dist/dotlottie-player.mjs" type="module"></script>
<?php
include "header.php";
?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="col-lg-12">
            <div class="card p-3">
                <form name="form1" action="" method="post">
                    <div class="row">
                        <div class="col-lg-6 col-ms-12">
                            <div class="mb-3">
                                <label class="form-label">Mijoz ID</label>
                                <div class="input-group align-items-center">
                                    <input type="text" class="form-control" name="client_id" readonly value="<?php echo  generate_client_id($client_id) ?>">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Mijozning I.F.O</label>
                                <input type="text" class="form-control" name="client_name" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Menejer</label>
                                <input type="text" class="form-control" name="client_menejer" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Hududni Tanlang</label>
                                <select name="client_region" id="client_region" class="form-control">
                                    <option value="Toshkent">Toshkent</option>
                                    <option value="Buxoro">Buxoro</option>
                                    <option value="Navoi">Navoi</option>
                                    <option value="Samarqand">Samarqand</option>
                                    <option value="Qarshi">Qashqadaryo</option>
                                    <option value="Surxandaryo">Surxandaryo</option>
                                    <option value="Fargona">Farg`ona</option>
                                    <option value="Andjon">Andjon</option>
                                    <option value="Xorazm">Namangan</option>
                                    <option value="Jizzax">Jizzax</option>
                                    <option value="Qoraqalpog`iston Respublikasi">Qoraqalpog`iston Respublikasi</option>
                                </select>
                            </div>


                            <div class="mb-3">
                                <label class="form-label">Mijozning Manzili</label>
                                <input type="text" class="form-control" name="client_address" required>
                            </div>
                        </div>
                        <div class="col-lg-6 col-ms-12">
                            <div class="mb-3">
                                <label class="form-label">Mijozning Firmasi</label>
                                <input type="text" class="form-control" name="client_company" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Mijozning Firma STIR</label>
                                <input type="text" class="form-control" name="client_stir" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Контакт лицо</label>
                                <input type="text" class="form-control" name="client_litso" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Mijozning Telefon Raqami</label>
                                <input type="text" class="form-control" name="client_number" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Mijozning Kategoriyasi</label>
                                <select name="client_category" class="form-control">
                                    <option>Kategoriyani Tanlang</option>
                                    <option value="A">A</option>
                                    <option value="B">B</option>
                                    <option value="C">C</option>
                                    <option value="D">D</option>
                                </select>
                            </div>
                        </div>
                    </div>




                    <div class="alert alert-danger" role="alert" id="error" style="display:none;">
                        Bu Mijoz mavjud! Iltmos boshqa Mijoz qo`shing
                    </div>

                    <div class="alert alert-success" role="alert" id="success" style="display:none;">
                        Mijoz muvaffaqiyatli qo`shildi
                    </div>
                    <button type="submit" name="submit1" class="btn btn-primary">Qo`shish</button>
                </form>
            </div>
        </div>
        <div class="d-flex align-items-center">
            <div id="filter">
                <select name="client_region" id="client_region" class="form-control">
                    <option value="toshkent">Toshkent</option>
                    <option value="buxoro">Buxoro</option>
                    <option value="navoi">Navoi</option>
                    <option value="samarqand">Samarqand</option>
                    <option value="qarshi">Qashqadaryo</option>
                    <option value="surxandaryo">Surxandaryo</option>
                    <option value="fargona">Farg`ona</option>
                    <option value="andjon">Andjon</option>
                    <option value="xorazm">Namangan</option>
                    <option value="jizzax">Jizzax</option>
                    <option value="qoraqalpoq">Qoraqalpoq Respublikasi</option>
                </select>
            </div>

            <div class="download" style="margin-left: 40px;">
                <a href="export.php">Excel File ni yuklab olish</a>
            </div>
        </div>
        <table class="table mt-4 bg-white">
            <thead>
                <tr>
                    <th scope="col">Mijoz ID</th>
                    <th scope="col">Mijoz Nomi</th>
                    <!-- <th scope="col">Menejer</th> -->
                    <th scope="col">Hudud</th>
                    <th scope="col">Manzil</th>
                    <th scope="col">Mijoz Firmasi</th>
                    <!-- <th scope="col">Mijoz Firmasi STIR</th> -->
                    <!-- <th scope="col">Контакт лицо</th> -->
                    <th scope="col">Telefon Raqami</th>
                    <th scope="col">Mijoz Kategoriyasi</th>
                    <th scope="col">Tahrirlash</th>
                    <th scope="col">O`chirish</th>
                </tr>
            </thead>
            <tbody>

                <?php

                $res = $link->query("SELECT * from client_base ORDER BY client_name ASC");
                if ($res->num_rows > 0) {
                    while ($row = mysqli_fetch_array($res)) {
                ?>
                        <tr>
                            <td><?php echo $row["client_id"] ?></td>
                            <td><?php echo $row["client_name"] ?></td>
                            <!-- <td><?php echo $row["client_menejer"] ?></td> -->
                            <td><?php echo $row["client_region"] ?></td>
                            <td><?php echo $row["client_address"] ?></td>
                            <td><?php echo $row["client_company"] ?></td>
                            <!-- <td><?php echo $row["client_stir"] ?></td> -->
                            <!-- <td><?php echo $row["client_litso"] ?></td> -->
                            <td><?php echo $row["client_number"] ?></td>
                            <td><?php echo $row["client_category"] ?></td>
                            <td class="edit"><a href="./edit_client.php?id=<?php echo $row["id"]; ?> "><i class="fa-solid fa-pencil"></i></a></td>
                            <td class="delete"><a href="./delete_client.php?id=<?php echo $row["id"]; ?>"> <i class="fa-solid fa-trash"></i></a></td>
                        </tr>
                <?php
                    }
                }
                ?>


            </tbody>
        </table>
            
    </div>
    <!-- / Content -->
</div>
<!-- Content wrapper -->
<?php
include "footer.php";
?>

<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="d-flex flex-column">
                    <h5 class="modal-title text-danger" id="exampleModalLabel">ESLATMA !!!</h5>
                    <span>Mijoz Kategoriyasini tanlayotganda e`tibor bering. Ushbu bo`lim buyirtma qismiga ta`sir qiladi</span>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <ul>
                    <li>Kategoriya A - Sotuvchi</li>
                    <li>Kategoriya B - Quruvchi</li>
                    <li>Kategoriya C - Erkin Mijoz</li>
                    <li>Kategoriya D - No`malum</li>
                </ul>
            </div>
            <div class="modal-footer">
                MasterBrother MJCH
            </div>
        </div>
    </div>
</div>
</div>

<!-- partial -->
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/js/bootstrap.min.js'></script>
<script src="https://kit.fontawesome.com/1f9ff78b58.js" crossorigin="anonymous"></script>
<script src="./script.js"></script>

<script type="text/javascript">
    $(document).ready(function() {
        $("#client_region").on('change', function() {
            var value = $(this).val();
            // alert(value);
            $.ajax({
                url: "fetch.php",
                type: "POST",
                data: 'request=' + value,
                beforeSend: function() {
                    $(".container").html("<span>Working...</span>");
                },
                success: function(data) {
                    $(".container").html(data);
                }
            })
        });
    })
</script>


<?php
function generate_client_id($id)
{

    if ($id == "") {
        $id1 = 0;
    } else {
        $id1 = $id;
    }
    $id1 = $id1 + 1;

    $len = strlen($id1);

    if ($len == "1") {
        $id1 =  "00" .  $id1;
    }
    if ($len == "2") {
        $id1 =  "000" .  $id1;
    }

    if ($len == "3") {
        $id1 =  "0000" .  $id1;
        // $currentDate = date('Ymd'); echo $currentDate;

    }
    if ($len == "4") {
        $id1 = "00000" .  $id1;
        // $currentDate = date('Ymd'); echo $currentDate;
    }
    if ($len == "5") {
        $id1 =  "000000" .  $id1;
    }
    if ($len == "6") {
        $id1 =  "0000000" .  $id1;
        // $currentDate = date('Ymd'); echo $currentDate;
    }
    if ($len == "7") {
        $id1 = "00000000" .  $id1;
    }
    return $id1;
}
?>

<?php
if (isset($_POST["submit1"])) {
    $count = 0;
    $res = mysqli_query($link, "select * from client_base where client_name='$_POST[client_name]'");
    $count = mysqli_num_rows($res);

    if ($count > 0) {
?>
        <script type="text/javascript">
            document.getElementById('success').style.display = "none";
            document.getElementById('error').style.display = "block";
            setTimeout(function() {
                window.location.href = window.location.href;
            }, 50);
        </script>
    <?php
    } else {
        mysqli_query($link, "insert into client_base values(NULL,'$_POST[client_id]', '$_POST[client_name]', '$_POST[client_menejer]', '$_POST[client_region]', '$_POST[client_address]', '$_POST[client_company]', '$_POST[client_stir]', '$_POST[client_litso]','$_POST[client_number]', '$_POST[client_category]', '1')");

    ?>
        <script type="text/javascript">
            document.getElementById('error').style.display = "none";
            document.getElementById('success').style.display = "block";
            setTimeout(function() {
                window.location.href = window.location.href;
            }, 50);
        </script>
<?php
    }
}
?>

<script type="text/javascript">

</script>

</body>

</html>