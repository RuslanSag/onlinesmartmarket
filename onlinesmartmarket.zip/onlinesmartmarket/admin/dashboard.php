<?php
include "connection.php"
?>
<style>
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,100;9..40,200;9..40,300;9..40,400;9..40,500;9..40,600;9..40,700;9..40,800;9..40,900;9..40,1000&display=swap');

    .card_box {
        width: 100%;
        padding: 15px;
        border-radius: 15px;
        background-color: #FFFFFF;
        display: flex;
        align-items: center;
    }

    .card_box h5 {
        color: var(--light-version-text, #06152B);
        font-family: DM Sans;
        font-size: 24.064px;
        font-style: normal;
        font-weight: 700;
        line-height: normal;
    }

    .box_img {
        width: 63.381px;
        height: 63.381px;
        border-radius: 50%;
        background: #e169ff54;
        margin-right: 16px;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .card_box img {
        width: 35px;
        height: 35px;

    }

    .card_box p {
        margin: 0;
    }

    #myDiv {
        width: 100%;
        display: none;
    }
</style>

<link rel="stylesheet" href="./main.css">

<?php
include "header.php";
?>

<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3">Dashboard</h4>

        <div class="row">
            <div class="col-lg-3">
                <div class="card_box">
                    <div class="box_img">
                        <img src="./img/icon/bag-dynamic-color.png" alt="">
                    </div>
                    <div class="d-flex flex-column ">
                        <h5>
                            <?php
                            $count = 0;
                            $res = mysqli_query($link, "select * from add_product");
                            $count = mysqli_num_rows($res);
                            echo $count;
                            ?>
                        </h5>
                        <p>Number of products</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="card_box">
                    <div class="box_img" style="background: #03a89e70;">
                        <img src="./img/icon/target-dynamic-color.png" alt="">
                    </div>
                    <div class="d-flex flex-column">
                        <h5>
                            <?php
                            $count = 0;
                            $res = mysqli_query($link, "select * from billing_header");
                            $count = mysqli_num_rows($res);
                            echo $count;
                            ?>
                        </h5>
                        <p>Number of Sales</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="card_box">
                    <div class="box_img" style="background: #c9f21d70;">
                        <img src="./img/icon/dollar-dollar-color.png" alt="">
                    </div>
                    <div class="d-flex flex-column">
                        <h5 class="number">
                            <?php
                            // Query to retrieve two columns from table
                            $sql = "SELECT price, qty FROM billing_details";
                            $result = $link->query($sql);
    
                            // Initialize sum variable
                            $sum = 0;
    
                            // Check if query returned any rows
                            if ($result->num_rows > 0) {
                                // Loop through each row
                                while ($row = $result->fetch_assoc()) {
                                    // Add values from column1 and column2 to sum
                                    $sum += $row["price"] * $row["qty"];
                                }
    
                                // Output the sum
                                echo "" . $sum . "so`m";
                            }
    
                            $result = mysqli_query($link, "SELECT SUM(price) AS totalsum FROM billing_details");
                            $row = mysqli_fetch_assoc($result);
                            $sum = $row['totalsum'];
                            ?>
                        </h5>
                        <p>Total Sales <b class="text-danger">(in $)</b></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="card_box">
                    <div class="box_img" style="background: #ff33057a;">
                        <img src="./img/icon/thumb-down-dynamic-color.png" alt="">
                    </div>
                    <div class="d-flex flex-column">
                        <h5>
                            <?php
                            $count = 0;
                            $res = mysqli_query($link, "select * from return_products");
                            $count = mysqli_num_rows($res);
                            echo $count;
                            ?>
                        </h5>
                        <p>Canceled</p>
                    </div>
                </div>
            </div>
        </div>
    
        <div class="mt-4"></div>
        <div class="row">
            <div class="col-lg-3">
                <div class="card_box">
                    <div class="box_img" style="background: #c9f21d70;">
                        <img src="./img/icon/dollar-dollar-color.png" alt="">
                    </div>
                    <div class="d-flex flex-column">
                        <h5 class="number">
                            <?php
                            // Query to retrieve two columns from table
                            $sql = "SELECT kredit FROM cash";
                            $result = $link->query($sql);
    
                            // Initialize sum variable
                            $sum1 = 0;
    
                            // Check if query returned any rows
                            if ($result->num_rows > 0) {
                                // Loop through each row
                                while ($row = $result->fetch_assoc()) {
                                    // Add values from column1 and column2 to sum
                                    $sum1 += $row["kredit"];
                                }
    
                                // Output the sum
                                echo "" . $sum1 . "so`m";
                            }
    
                            $result = mysqli_query($link, "SELECT SUM(kredit) AS totalsum FROM payment_base");
                            $row = mysqli_fetch_assoc($result);
                            $sum1 = $row['totalsum'];
                            echo ("$sum1 so`m");
                            ?>
    
                        </h5>
                        <p>Checkout <b class="text-danger">(in $)</b></p>
                    </div>
                </div>
            </div>
    
            <div class="col-lg-3">
                <div class="card_box">
                    <div class="box_img" style="background: #c9f21d70;">
                        <img src="./img/icon/dollar-dollar-color.png" alt="">
                    </div>
                    <div class="d-flex flex-column">
                        <h5 class="number">
                            <?php
                            // Query to retrieve two columns from table
                            $sql = "SELECT price, qty FROM billing_details";
                            $result = $link->query($sql);
    
                            // Initialize sum variable
                            $sum = 0;
    
                            // Check if query returned any rows
                            if ($result->num_rows > 0) {
                                // Loop through each row
                                while ($row = $result->fetch_assoc()) {
                                    // Add values from column1 and column2 to sum
                                    $sum += $row["price"] * $row["qty"];
                                }
    
                                // Output the sum
                                echo "" . $sum - $sum1 . "so`m";
                            }
    
                            $result = mysqli_query($link, "SELECT SUM(price) AS totalsum FROM billing_details");
                            $row = mysqli_fetch_assoc($result);
                            $sum = $row['totalsum'] - $sum1;
                            // echo ("$sum so`m");
                            ?>
                        </h5>
                        <p>Indebtedness <b class="text-danger">(in $)</b></p>
                    </div>
                </div>
            </div>
    
            <div class="col-lg-3">
                <button class="card_box border-0" onclick="toggleDiv()">
                    <div class="box_img" style="background: #ed1c1cbd;">
                        <img src="./img/icon/logo.png" alt="">
                    </div>
                    <div class="d-flex flex-column">
                        <h5 class="text-danger">
                            List of debtors
                        </h5>
                    </div>
                </button>
            </div>
    
    
        </div>
    
        <div class="mt-4"></div>
    
        <div class="row" id="myDiv">
            <div class="col-lg-12">
                <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active btn-warning" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">5 mln dan ko`p qarzdorlar ro`yxati</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link btn-danger" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">10 mln dan ko`p qarzdorlar ro`yxati</button>
                    </li>
    
                </ul>
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                        <div class="card ">
                            <div class="mb-3">
                                <table class="table">
                                    <tr>
                                        <th>Mijoz ID</th>
                                        <th>Sotuvchi ...dan </th>
                                        <th>Mijoz Nomi</th>
                                        <th>Mijoz Raqami</th>
                                        <th>qarzdorlik</th>
                                    </tr>
                                    <?php
                                    $sql = "SELECT client_id, client_name, client_number, username, SUM(main_pay) AS total_main_pay, SUM(kredit) AS total_kredit, SUM(main_pay) - SUM(kredit) AS balance FROM payment_base GROUP BY client_id, client_name HAVING SUM(main_pay) - SUM(kredit) >= 5000000";
                                    $result = $link->query($sql);
    
                                    if ($result->num_rows > 0) {
                                        // Output data of each row
                                        while ($row = $result->fetch_assoc()) {
                                            // Display the data as needed
                                    ?>
    
                                            <tr class="blink">
                                                <td><?php echo $row["client_id"] ?></td>
                                                <td><?php echo $row["username"] ?></td>
                                                <td><?php echo $row["client_name"] ?></td>
                                                <td><?php echo $row["client_number"] ?></td>
                                                <td>
                                                    <?php echo $row['balance'] . " so`m" ?>
    
                                                </td>
                                            </tr>
                                    <?php
                                            // echo "client_id: " . $row["client_id"] . ", client_name: " . $row["client_name"] . $row["client_number"] . ", qarzdorlik: " . "885000" . "<br>";
                                        }
                                    } else {
                                        echo "Tabriklaymiz sizda 5 mln dan ko`p qarzdorlar yo`q 🥳 !!!";
                                    }
                                    ?>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                        <div class="card ">
                            <div class="mb-3">
                                <table class="table">
                                    <tr>
                                        <th>Mijoz ID</th>
                                        <th>Sotuvchi ...dan </th>
                                        <th>Mijoz Nomi</th>
                                        <th>Mijoz Raqami</th>
                                        <th>qarzdorlik</th>
                                    </tr>
                                    <?php
                                    $sql = "SELECT client_id, client_name, client_number, username, SUM(main_pay) AS total_main_pay, SUM(kredit) AS total_kredit, SUM(main_pay) - SUM(kredit) AS balance FROM payment_base GROUP BY client_id, client_name HAVING SUM(main_pay) - SUM(kredit) >= 10000000";
                                    $result = $link->query($sql);
    
                                    if ($result->num_rows > 0) {
                                        // Output data of each row
                                        while ($row = $result->fetch_assoc()) {
                                            // Display the data as needed
                                    ?>
    
                                            <tr class="blink">
                                                <td><?php echo $row["client_id"] ?></td>
                                                <td><?php echo $row["username"] ?></td>
                                                <td><?php echo $row["client_name"] ?></td>
                                                <td><?php echo $row["client_number"] ?></td>
                                                <td>
                                                    <?php echo $row['balance'] . " so`m" ?>
    
                                                </td>
                                            </tr>
                                    <?php
                                            // echo "client_id: " . $row["client_id"] . ", client_name: " . $row["client_name"] . $row["client_number"] . ", qarzdorlik: " . "885000" . "<br>";
                                        }
                                    } else {
                                        echo "Tabriklaymiz sizda 5 mln dan ko`p qarzdorlar yo`q 🥳 !!!";
                                    }
                                    ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    
        </div>
    </div>
    <!-- / Content -->


    <div class="content-backdrop fade"></div>
</div>



<script>
    function toggleDiv() {
        var myDiv = document.getElementById("myDiv");
        if (myDiv.style.display === "none") {
            myDiv.style.display = "block";
        } else {
            myDiv.style.display = "none";
        }
    }
</script>

<script type="text/javascript">
    function formatNumber(n) {
        if (n < 0) {
            throw 'must be non-negative: ' + n;
        }
        if (n === 0) {
            return '0';
        }

        var output = [];

        for (; n >= 1000; n = Math.floor(n / 1000)) {
            output.unshift(String(n % 1000).padStart(3, '0'));
        }
        output.unshift(n);

        return output.join(' ');
    }

    var numbers = document.getElementsByClassName('number');

    for (var index = 0; index < numbers.length; index++) {
        var elem = numbers.item(index);
        elem.textContent = formatNumber(parseInt(elem.textContent));
    }
</script>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="d-flex flex-column">
                    <h5 class="modal-title text-danger" id="exampleModalLabel">ESLATMA !!!</h5>
                    <span><b>Mijoz Kategoriyasini tanlayotganda e`tibor bering. Ushbu bo`lim buyirtma qismiga ta`sir qiladi</b> </span>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <ul>
                    <li>Kategoriya A - Sotuvchi</li>
                    <li>Kategoriya B - Quruvchi</li>
                    <li>Kategoriya C - Erkin Mijoz</li>
                    <li>Kategoriya D - No`malum</li>
                </ul>
            </div>
            <div class="modal-footer">
                MasterBrother MJCH
            </div>
        </div>
    </div>
</div>


<?php
include "footer.php"
?>