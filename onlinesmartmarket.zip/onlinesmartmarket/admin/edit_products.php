<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>


<?php
include "connection.php";

$id = $_GET["id"];
$product_name = "";

$res = mysqli_query($link, "select * from add_product where id=$id");
while ($row = mysqli_fetch_array($res)) {
    $product_name = $row["product_name"];
}
?>
<?php
include "header.php";
?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="alerts">
            <div class="alert alert-danger alert-dismissible fade show" role="alert" id="error" style="display:none;">
                Bu Mahsulot mavjud! Iltmos boshqa Mahsulot qo`shing
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>

            <div class="alert alert-success alert-dismissible fade show" role="alert" id="success" style="display:none;">
                Mahsulot nomi muvaffaqiyatli yangilandi
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
        <div class="col-lg-5">
            <div class="card">
                <div class="card-header">Mahsulotni Tahrirlash</div>
                <div class="card-body p-3">
                    <form name="form1" action="" method="post">
                        <div class="mb-3">
                            <label class="form-label">Mahsulot Nomi:</label>
                            <input type="text" class="form-control" name="product_name" value="<?php echo $product_name; ?>">
                        </div>
                        <button type="submit" name="submit1" class="btn btn-primary">Yangilash</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->
</div>
<!-- Content wrapper -->


<?php
if (isset($_POST["submit1"])) {
    mysqli_query($link, "update add_product set  product_name='$_POST[product_name]' where id=$id") or die(mysqli_error($link));
?>
    <script type="text/javascript">
        document.getElementById('error').style.display = "none";
        document.getElementById('success').style.display = "block";
        setTimeout(function() {
            window.location = "add_new_product.php";
        }, 3000);
    </script>
<?php
}
?>

<?php
include "footer.php"
?>