<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>


<?php

include "header.php";
include "connection.php";

$bill_no = 0;
$res = mysqli_query($link, "select * from billing_header order by id desc limit 1");
while ($row = mysqli_fetch_array($res)) {
    $bill_no = $row["id"];
}


?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<style>
    .pluss_btn {
        width: 36px;
        height: 36px;
        border: 1px solid #999;
        display: flex;
        justify-content: center;
        align-items: center;
        margin-left: 15px;
        border-radius: 5px;
    }

    .pluss_btn:hover {
        cursor: pointer;
    }
</style>
<div id="main-content">
    <div id="header">
        <div class="header-left float-left">
            <i id="toggle-left-menu" class="ion-android-menu"></i>
        </div>
        <div class="header-right float-right">
            <a href="./logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i></a>
        </div>
    </div>

    <div id="page-container">
        <div class="col-lg-12">
            <div class="card border-5">
                <div class="card-header">Sales a Product</div>
                <div class="card-body p-3">
                    <form name="form1" action="" method="post">
                        <div class="sales_product_name">
                            <div class="mb-3">
                                <label class="form-label">Full Name</label>
                                <div class="d-flex align-items-center">
                                    <input class="form-control" name="client_name" id="client_name" onchange="select_cilent(this.value)">

                                    <!-- <a class="pluss_btn" href="./client_filter.php">
                                        <i class="fa-solid fa-plus"></i>
                                    </a> -->
                                    <button type="button" class="btn btn-primary" style="margin-left: 15px;" data-toggle="modal" data-target="#exampleModal">
                                        <i class="fa-solid fa-plus"></i>
                                    </button>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Info Mijoz:</label>
                                    <div id="client_div">

                                    </div>
                                </div>
                            </div>





                            <div class="mb-3">
                                <label class="form-label">Date</label>
                                <input type="date" class="form-control" name="bill_date" value="<?php $currentDate = date('Y-m-d');
                                                                                                echo $currentDate; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Bill No</label>
                                <div class="input-group align-items-center">
                                    <span class="input-group-text" style="border-radius: 0px !important;">MB</span><input type="text" class="form-control" name="bill_no" readonly value="<?php echo  generate_bill_no($bill_no) ?>">
                                </div>
                            </div>
                        </div>



                        <div class="alert alert-danger" role="alert" id="error" style="display:none;">
                            Bu Unit mavjud! Iltmos boshqa User qo`shing
                        </div>

                        <div class="alert alert-success" role="alert" id="success" style="display:none;">
                            Unit muvaffaqiyatli qo`shildi
                        </div>

                        <div class="text-center mt-3 mb-3">
                            <h4>Sales a Product</h4>
                        </div>


                        <div class="sales_product ">
                            <input class="form-control" name="product_name" id="product_name" onchange="select_product(this.value)">
                            <div id="client_div2">
                            </div>





                            <div class="alert alert-success" role="alert" id="success" style="display:none;">
                                Ma`lumot muvaffaqiyatli qo`shildi
                            </div>
                        </div>

                        <!-- <div class="card">
                            <div class="card-header">
                                <b>Taken Products</b>
                            </div>
                            <div class="card-body">
                                <div id="bill_products"></div>
                                <h4>
                                    <div id="totalbill">0 <b>so`m</b> </div>
                                </h4>
                            </div>
                        </div> -->

                        <input type="submit" value="submit" class="btn btn-primary" name="submit1">

                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-12">

        </div>

    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Yangi Mijoz Qo`shish</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: red;">&times;</span>
                </button>
            </div>
            <div class="modal-body p-1">
                <div class="card">
                    <form name="form1" action="" method="post">
                        <div class="row">
                            <div class="col-6">
                                <div class="mb-3">
                                    <label class="form-label">Mijozning I.F.O</label>
                                    <input type="text" class="form-control" name="client_name" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Menejer</label>
                                    <input type="text" class="form-control" name="client_menejer" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Hududni Tanlang</label>
                                    <select name="client_region" id="" class="form-control">
                                        <option value="toshkent">Toshkent</option>
                                        <option value="buxoro">Buxoro</option>
                                        <option value="navoi">Navoi</option>
                                        <option value="samarqand">Samarqand</option>
                                        <option value="qarshi">Qashqadaryo</option>
                                        <option value="surxandaryo">Surxandaryo</option>
                                        <option value="fargona">Farg`ona</option>
                                        <option value="andjon">Andjon</option>
                                        <option value="xorazm">Namangan</option>
                                        <option value="jizzax">Jizzax</option>
                                        <option value="qoraqalpoq">Qoraqalpoq Respublikasi</option>
                                    </select>
                                </div>


                                <div class="mb-3">
                                    <label class="form-label">Mijozning Manzili</label>
                                    <input type="text" class="form-control" name="client_address" required>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="mb-3">
                                    <label class="form-label">Mijozning Firmasi</label>
                                    <input type="text" class="form-control" name="client_company" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Mijozning Firma STIR</label>
                                    <input type="text" class="form-control" name="client_stir" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Контакт лицо</label>
                                    <input type="text" class="form-control" name="client_litso" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Mijozning Telefon Raqami</label>
                                    <input type="text" class="form-control" name="client_number" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Mijozning Kategoriyasi</label>
                                    <select name="client_category" class="form-control">
                                        <option>Kategoriyani Tanlang</option>
                                        <option value="A">A</option>
                                        <option value="B">B</option>
                                        <option value="C">C</option>
                                    </select>
                                </div>
                            </div>
                        </div>




                        <div class="alert alert-danger" role="alert" id="error" style="display:none;">
                            Bu Unit mavjud! Iltmos boshqa User qo`shing
                        </div>

                        <div class="alert alert-success" role="alert" id="success" style="display:none;">
                            Unit muvaffaqiyatli qo`shildi
                        </div>
                        <button type="submit" name="submit2" class="btn btn-primary">Qo`shish</button>
                    </form>
                </div>
            </div>
            <!-- <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div> -->
        </div>
    </div>
</div>



<script type="text/javascript">
    function select_cilent(client_name) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("client_div").innerHTML = xmlhttp.responseText;
                // alert("ssss");
            }
        };
        xmlhttp.open("GET", "forajax_user/load_client_info_using_name.php?client_name=" + client_name, true);
        xmlhttp.send();
    }

    function select_product(product_name) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("client_div2").innerHTML = xmlhttp.responseText;
            }
        };
        xmlhttp.open("GET", "forajax_product/load_product_info_name.php?product_name=" + product_name, true);
        xmlhttp.send();
    }

    function generate_total(qty) {
        document.getElementById("total").value = eval(document.getElementById("price").value) * eval(document.getElementById("qty").value);
    }





    const date = new Date();

    let day = date.getDate();
    let month = date.getMonth() + 1;
    let year = date.getFullYear();

    // This arrangement can be altered based on how we want the date's format to appear.
    let currentDate = `${day}-${month}-${year}`;
    console.log(currentDate); // "17-6-2022"
</script>

<?php
function generate_bill_no($id)
{
    $currentDate = date('dmy');
    if ($id == "") {
        $id1 = 0;
    } else {
        $id1 = $id;
    }
    $id1 = $id1 + 1;

    $len = strlen($id1);

    if ($len == "1") {
        $id1 =  "$currentDate" .  $id1;
        // $currentDate = date('Ymd'); echo $currentDate;
    }
    if ($len == "2") {
        $id1 =  "$currentDate" .  $id1;
    }

    if ($len == "3") {
        $id1 =  "$currentDate" .  $id1;
        // $currentDate = date('Ymd'); echo $currentDate;

    }
    if ($len == "4") {
        $id1 = "$currentDate" .  $id1;
        // $currentDate = date('Ymd'); echo $currentDate;
    }
    if ($len == "5") {
        $id1 =  "$currentDate" .  $id1;
    }
    if ($len == "6") {
        $id1 =  "$currentDate" .  $id1;
        // $currentDate = date('Ymd'); echo $currentDate;
    }
    if ($len == "7") {
        $id1 = "$currentDate" .  $id1;
    }
    return $id1;
}

if (isset($_POST["submit1"])) {
    
    mysqli_query($link, "insert into old_test values(NULL,'$_POST[bill_no]', '$_POST[client_name]', '$_POST[client_region]', '$_POST[client_address]', '$_POST[client_number]', '$_POST[client_category]', '$_POST[product_name]', '$_POST[company_name]', '$_SESSION[unit]', '$_POST[packing_size]', '$_POST[price]', '$_POST[qty]', '$_POST[total]')") or die(mysqli_error($link));

    

?>
    <script type="text/javascript">
        alert("bill a`lo");
        window.location.href = window.location.href;
    </script>
<?php
}
?>

<?php
if (isset($_POST["submit2"])) {
    $count = 0;
    $res = mysqli_query($link, "select * from client_base where client_name='$_POST[client_name]'");
    $count = mysqli_num_rows($res);

    if ($count > 0) {
?>
        <script type="text/javascript">
            document.getElementById('success').style.display = "none";
            document.getElementById('error').style.display = "block";
            setTimeout(function() {
                window.location.href = window.location.href;
            }, 50);
        </script>
    <?php
    } else {
        mysqli_query($link, "insert into client_base values(NULL, '$_POST[client_name]', '$_POST[client_menejer]', '$_POST[client_region]', '$_POST[client_address]', '$_POST[client_company]', '$_POST[client_stir]', '$_POST[client_litso]','$_POST[client_number]', '$_POST[client_category]', '1')");

    ?>
        <script type="text/javascript">
            document.getElementById('error').style.display = "none";
            document.getElementById('success').style.display = "block";
            setTimeout(function() {
                window.location.href = window.location.href;
            }, 50);
        </script>
<?php
    }
}
?>

<?php
include "footer.php"
?>