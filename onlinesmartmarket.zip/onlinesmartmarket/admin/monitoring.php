<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>


<?php

include "connection.php";

if (isset($_GET['id']) && isset($_GET['status'])) {
    $id = $_GET['id'];
    $status = $_GET['status'];
    mysqli_query($link, "update billing_header set status='$status' where id='$id'");
    header("location:view_bills.php");
}



?>
<?php
include "header.php";
?>
<style>
    .pagination {
        display: flex;
        list-style: none;
        margin: 20px 0;
        padding: 0;
    }

    .pagination li {
        margin-right: 10px;
        cursor: pointer;
        color: var(--bs-pagination-hover-color);
        background-color: var(--bs-pagination-hover-bg);
        border-color: var(--bs-pagination-hover-border-color);
        padding: 10px 15px;
        border-radius: 5px;
    }

    .pagination li.active {
        font-weight: bold;
        border-color: #696cff;
        background-color: #696cff;
        color: #fff;
        box-shadow: 0 0.125rem 0.25rem rgba(105, 108, 255, 0.4);
    }
</style>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex">
                        <i class="fa-regular fa-newspaper"></i>
                        <h6>Buyurtmalar</h6>
                    </div>
                    <form class="form-inline" action="" name="form1" method="post">
                        <div class="form-group">
                            <label for="email">Boshlang`ich Sanani Tanlang</label>
                            <input type="text" name="dt" id="dt" autocomplete="off" class="form-control" required style="width:200px;border-style:solid; border-width:1px; border-color:#666666" placeholder="click here to open calender">
                        </div>
                        <div class="form-group">
                            <label for="email">Oxrigi Sanani Tanlang</label>
                            <input type="text" name="dt2" id="dt2" autocomplete="off" placeholder="click here to open calender" class="form-control" style="width:200px;border-style:solid; border-width:1px; border-color:#666666">
                        </div>
                        <button type="submit" name="submit1" class="btn btn-success">Filter</button>
                        <button type="button" name="submit2" class="btn btn-warning" onclick="window.location.href=window.location.href">Clear Search</button>
                    </form>

                </div>
                <div class="card-body p-3">

                    <?php
                    if (isset($_POST["submit1"])) {
                    ?>
                        <table class="table" id="myTable">
                            <tr>
                                <th>Mijoz ID</th>
                                <th>Mijoz Nomi</th>
                                <th>Buyurtma Kodi</th>
                                <th>Buyurtma Sanasini</th>
                                <th>Buyurtma Yetkazilgan Sana</th>
                                <th>Buyurtma Narxi</th>
                                <th>Kredit</th>
                                <th>Debit</th>
                            </tr>
                            <?php
                            $res = mysqli_query($link, "select * from payment_base where (date>='$_POST[dt]' && date<='$_POST[dt2]') order by id desc");
                            while ($row = mysqli_fetch_array($res)) {
                            ?>
                                <tr>
                                    <td scope="row"><?php echo $row["bill_no"] ?></td>
                                    <td><?php echo $row["client_id"] ?></td>
                                    <td><?php echo $row["client_name"] ?></td>
                                    <td><?php echo $row["bill_no"] ?></td>
                                    <td><?php echo $row["date"] ?></td>
                                    <td><?php echo $row["date"] ?></td>
                                    <td><?php echo $row["main_pay"] ?></td>
                                    <td><?php echo $row["kredit"] ?></td>
                                    <td><?php echo $row["debit"] ?></td>
                                </tr>
                            <?php
                            }
                            ?>

                        </table>
                        <nav aria-label="Page navigation">
                            <ul class="pagination" id="pagination"></ul>
                        </nav>
                    <?php
                    } else {
                    ?>
                        <table class="table" id="myTable">
                            <tr>
                                <th>Mijoz ID</th>
                                <th>Mijoz Nomi</th>
                                <th>Buyurtma Kodi</th>
                                <th>Operatsiya Vaqti</th>
                                <th>Debit</th>
                                <th>Kredit</th>
                            </tr>
                            <?php
                            $res = mysqli_query($link, "select * from payment_base");
                            while ($row = mysqli_fetch_array($res)) {
                            ?>
                                <tr>
                                    <td><?php echo $row["client_id"] ?></td>
                                    <td><?php echo $row["client_name"] ?></td>
                                    <td><?php echo $row["bill_no"] ?></td>
                                    <td><?php echo $row["date"] ?></td>
                                    <td><?php echo $row["main_pay"] ?></td>
                                    <td><?php echo $row["kredit"] ?></td>
                                </tr>
                            <?php
                            }
                            ?>

                        </table>
                        <nav aria-label="Page navigation">
                            <ul class="pagination" id="pagination"></ul>
                        </nav>
                    <?php
                    }
                    ?>


                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->
</div>
<!-- Content wrapper -->




<script>
    document.addEventListener("DOMContentLoaded", function() {
        const table = document.getElementById('myTable');
        const rows = table.tBodies[0].rows;
        const totalRows = rows.length;
        const rowsPerPage = 10;
        const totalPages = Math.ceil(totalRows / rowsPerPage);
        let currentPage = 1;

        function showPage(page) {
            const start = (page - 1) * rowsPerPage;
            const end = start + rowsPerPage;

            for (let i = 0; i < totalRows; i++) {
                rows[i].style.display = i >= start && i < end ? '' : 'none';
            }
        }

        function generatePagination() {
            const pagination = document.getElementById('pagination');
            pagination.innerHTML = '';

            for (let i = 1; i <= totalPages; i++) {
                const li = document.createElement('li');
                li.textContent = i;
                li.addEventListener('click', function() {
                    currentPage = i;
                    showPage(currentPage);
                    updatePaginationUI();
                });
                pagination.appendChild(li);
            }
        }

        function updatePaginationUI() {
            const paginationItems = document.getElementById('pagination').getElementsByTagName('li');
            for (let i = 0; i < totalPages; i++) {
                if (i + 1 === currentPage) {
                    paginationItems[i].classList.add('active');
                } else {
                    paginationItems[i].classList.remove('active');
                }
            }
        }

        showPage(currentPage);
        generatePagination();
        updatePaginationUI();
    });
</script>
<script type="text/javascript">
    function status_update(value, id) {
        let url = "view_bills.php";
        window.location.href = url + "?id=" + id + "&status=" + value;
    }
</script>

<?php




function get_total($bill_id, $link)
{
    $total = 0;
    $res2 = mysqli_query($link, "select * from billing_details where bill_id=$bill_id");
    while ($row2 = mysqli_fetch_array($res2)) {
        $total = $total + ($row2["price"] * $row2["qty"]);
    }

    return $total;
}
?>

<?php
include "footer.php"
?>