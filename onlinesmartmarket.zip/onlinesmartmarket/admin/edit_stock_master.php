<?php
session_start();
    if(!isset($_SESSION["admin"]))
    {
        ?>
            <script type="text/javascript">
                window.location="index.php";
            </script>
        <?php
    }
?>


<?php
include "header.php";
include "connection.php";

$id = $_GET["id"];
$product_company = "";
$product_name = "";
$product_unit = "";
$product_qty = "";
$product_selling_price = "";

$res=mysqli_query($link, "select * from stock_master where id=$id");
while($row=mysqli_fetch_array($res))
{
    $product_company = $row["product_company"];
    $product_name = $row["product_name"];
    $product_unit = $row["product_unit"];
    $product_qty = $row["product_qty"];
    $product_selling_price = $row["product_selling_price"];
    
}
?>

<div id="main-content">
    <div id="header">
        <div class="header-left float-left">
            <i id="toggle-left-menu" class="ion-android-menu"></i>
        </div>
        <div class="header-right float-right">
        <a href="./logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i></a>
        </div>
    </div>

    <div id="page-container">
        <div class="col-lg-5">
            <div class="card border-5">
                <div class="card-header">Edit Stocks Price</div>
                <div class="card-body p-3">
                    <form name="form1" action="" method="post">
                        <div class="mb-3">
                            <label class="form-label">Product Company:</label>
                            <input type="text" class="form-control" name="product_company" value="<?php echo $product_company; ?>" readonly>
                            
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Product Name:</label>
                            <input type="text" class="form-control" name="product_name" value="<?php echo $product_name; ?>" readonly>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Product Unit:</label>
                            <input type="text" class="form-control" name="product_unit" value="<?php echo $product_unit; ?>" readonly>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Product Qty:</label>
                            <input type="text" class="form-control" name="product_qty" value="<?php echo $product_qty; ?>" readonly>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Product Selling Price:</label>
                            <input type="text" class="form-control" name="product_selling_price" value="<?php echo $product_selling_price; ?>">
                        </div>

                        <div class="alert alert-danger" role="alert" id="error" style="display:none;">
                            Bu Mahsulot mavjud! Iltmos boshqa User qo`shing
                        </div>

                        <div class="alert alert-success" role="alert" id="success" style="display:none;">
                        Mahsulot muvaffaqiyatli Yangilandi
                        </div>
                        <button type="submit" name="submit1" class="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
        </div>

    </div>
</div>

<?php
if (isset($_POST["submit1"])) {
    mysqli_query($link, "update stock_master set product_selling_price='$_POST[product_selling_price]'   where id=$id") or die(mysqli_error($link));
    ?>
    <script type="text/javascript">
        document.getElementById('error').style.display = "none";
        document.getElementById('success').style.display = "block";
        setTimeout(function(){
            window.location="stock_master.php";
        },1000);
    </script>
<?php
}
?>

<?php
include "footer.php"
?>