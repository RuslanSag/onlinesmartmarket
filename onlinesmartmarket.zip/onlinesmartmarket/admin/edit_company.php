<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>


<?php
include "connection.php";

$id = $_GET["id"];
$company_name = "";
$company_region = "";
$company_address = "";
$company_stir = "";
$company_litso = "";
$company_nomer = "";

$res = mysqli_query($link, "select * from company_name where id=$id");
while ($row = mysqli_fetch_array($res)) {
    $company_name = $row["company_name"];
    $company_region = $row["company_region"];
    $company_address = $row["company_address"];
    $company_stir = $row["company_stir"];
    $company_litso = $row["company_litso"];
    $company_nomer = $row["company_nomer"];
}
?>
<?php
include "header.php";
?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="alerts">
            <div class="alert alert-danger alert-dismissible fade show" role="alert" id="error" style="display:none;">
                Bu Ta`minotchi mavjud! Iltmos boshqa Ta`minotchi qo`shing
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>

            <div class="alert alert-success alert-dismissible fade show" role="alert" id="success" style="display:none;">
                Ta`minotchi muvaffaqiyatli Yangilandi
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
        <div class="col-lg-5">
            <div class="card">
                <div class="card-header">Ta`minotchini Yangilash</div>
                <div class="card-body p-3">
                    <form name="form1" action="" method="post">
                        <div class="mb-3">
                            <label class="form-label">Ta`minotchi Nomi</label>
                            <input type="text" class="form-control" name="company_name" value="<?php echo $company_name; ?>">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Hudud</label>
                            <div class="mb-3">
                                <select name="company_region" id="" class="form-control">
                                    <option value=""><?php echo $company_region; ?></option>
                                    <option value="toshkent">Toshkent</option>
                                    <option value="buxoro">Buxoro</option>
                                    <option value="navoi">Navoi</option>
                                    <option value="samarqand">Samarqand</option>
                                    <option value="qarshi">Qashqadaryo</option>
                                    <option value="surxandaryo">Surxandaryo</option>
                                    <option value="fargona">Farg`ona</option>
                                    <option value="andjon">Andjon</option>
                                    <option value="xorazm">Namangan</option>
                                    <option value="jizzax">Jizzax</option>
                                    <option value="qoraqalpoq">Qoraqalpoq Respublikasi</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Manzil</label>
                                <input type="text" class="form-control" name="company_address" value="<?php echo $company_address; ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">STIR</label>
                                <input type="text" class="form-control" name="company_stir" value="<?php echo $company_stir; ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Контакт лицо</label>
                                <input type="text" class="form-control" name="company_litso" value="<?php echo $company_litso; ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Tel Nomer</label>
                                <input type="text" class="form-control" name="company_nomer" value="<?php echo $company_nomer; ?>">
                            </div>
                        </div>
                        <div class="alert alert-danger" role="alert" id="error" style="display:none;">
                            Bu User mavjud! Iltmos boshqa User qo`shing
                        </div>

                        <div class="alert alert-success" role="alert" id="success" style="display:none;">
                            User muvaffaqiyatli Yangilandi!!!
                        </div>
                        <button type="submit" name="submit1" class="btn btn-primary">Yangilash</button>
                    </form>
                </div>
            </div>
        </div>

    </div>


    <?php
    if (isset($_POST["submit1"])) {
        mysqli_query($link, "update company_name set company_name='$_POST[company_name]' where id=$id") or die(mysqli_error($link));
    ?>
        <script type="text/javascript">
            document.getElementById('success').style.display = "block";
            setTimeout(function() {
                window.location = "add_company.php";
            }, 3000);
        </script>
    <?php
    }

    ?>

    <?php
    include "footer.php"
    ?>