<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>


<?php

include "connection.php";

$bill_no = 0;
$res = mysqli_query($link, "select * from billing_header order by id desc limit 1");
while ($row = mysqli_fetch_array($res)) {
    $bill_no = $row["id"];
}

$client_id = 0;
$res = mysqli_query($link, "select * from client_base order by id desc limit 1");
while ($row = mysqli_fetch_array($res)) {
    $client_id = $row["client_id"];
}

?>

<script type="text/javascript">
    $(function() {
        $("#product_name").autocomplete({
            source: "fetchData3.php",
        });
    });
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<style>
    .pluss_btn {
        width: 36px;
        height: 36px;
        border: 1px solid #999;
        display: flex;
        justify-content: center;
        align-items: center;
        margin-left: 15px;
        border-radius: 5px;
    }

    .pluss_btn:hover {
        cursor: pointer;
    }
</style>
<?php
include "header.php";
?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
    <div class="col-lg-12">
            <div class="card">
                <div class="card-header">Place an order</div>
                <div class="card-body p-3">
                    <form name="form1" action="./sms/twillo.php"  method="post">
                        <div class="sales_product_name">
                            <div class="mb-3">
                                <label class="form-label">Client</label>
                                <div class="d-flex align-items-center">
                                    <input class="form-control" name="client_name" id="client_name" onchange="select_cilent(this.value)">

                                    <!-- <a class="pluss_btn" href="./client_filter.php">
                                        <i class="fa-solid fa-plus"></i>
                                    </a> -->
                                    <button type="button" class="btn btn-primary" style="margin-left: 15px;" data-toggle="modal" data-target="#exampleModal">
                                        <i class="fa-solid fa-plus"></i>
                                    </button>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Client Info:</label>
                                    <div id="client_div">
                                    </div>
                                </div>
                            </div>





                            <div class="mb-3">
                                <label class="form-label">Date</label>
                                <input type="date" class="form-control" name="bill_date" value="<?php $currentDate = date('Y-m-d');
                                                                                                echo $currentDate; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Bill No</label>
                                <div class="input-group align-items-center">
                                    <span class="input-group-text" style="border-radius: 0px !important;">MB</span><input type="text" class="form-control" name="bill_no" readonly value="<?php echo  generate_bill_no($bill_no) ?>">
                                </div>
                            </div>
                        </div>



                        <div class="alert alert-danger" role="alert" id="error" style="display:none;">
                            Bu Unit mavjud! Iltmos boshqa User qo`shing
                        </div>

                        <div class="alert alert-success" role="alert" id="success" style="display:none;">
                            Unit muvaffaqiyatli qo`shildi
                        </div>

                        <div class="text-center mt-3 mb-3">
                            <h4>Select a product</h4>
                        </div>


                        <div class="sales_product ">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="mb-3 w-100 input" style="display: none;">
                                        <label class="form-label">Ta`minotchi:</label>
                                        <select class="form-control" name="company_name" id="company_name" onchange="select_company(this.value)">
                                            <option value="">Select</option>
                                            <?php
                                            $res = mysqli_query($link, "select * from company_name");
                                            while ($row = mysqli_fetch_array($res)) {
                                                echo "<option>";
                                                echo $row["company_name"];
                                                echo "</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <div class="mb-3 w-100 input">
                                        <label class="form-label">Product:</label>
                                        <input class="form-control" name="product_name" id="product_name" onchange="select_product(this.value)">
                                        <div id="product_name_div">

                                        </div>
                                    </div>

                                    <div class="mb-3 w-100 input">
                                        <label class="form-label">Size:</label>
                                        <div id="unit_div">
                                            <select class="form-control">
                                                <option>Select</option>
                                            </select>
                                        </div>
                                    </div>



                                </div>
                                <div class="col-lg-6">
                                    <div class="mb-3 w-100 input">
                                        <label class="form-label">The rest:</label>
                                        <div id="packing_size_div">
                                            <select class="form-control">
                                                <option>Select</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="mb-3 w-100 input">
                                        <label class="form-label">Price:</label>
                                        <div id="packing_size_div2">
                                            <select class="form-control">
                                                <option>Select</option>
                                            </select>
                                        </div>
                                        <!-- <div id="price">
                                           
                                        </div> -->
                                        <input type="text" name="price" id="price" value="0" class="form-control">
                                    </div>



                                    <div class="mb-3 w-100 input">
                                        <label class="form-label">Enter the required Quantity:</label>
                                        <input type="text" name="qty" id="qty" placeholder="" value="" onkeyup="generate_total(this.value)" class="form-control" autocomplete="off">
                                    </div>

                                    <div class="mb-3 w-100 input">
                                        <label class="form-label">Total</label>
                                        <input type="text" name="total" id="total" value="0" class="form-control" readonly>
                                    </div>
                                </div>
                            </div>





                            <div class="alert alert-success" role="alert" id="success" style="display:none;">
                                Ma`lumot muvaffaqiyatli qo`shildi
                            </div>
                            <button type="button" class="shopping_cart" name="" id="" onclick="add_session();">Add to cart<i class="fa-solid fa-cart-shopping"></i></button>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <b>Ordered products</b>
                            </div>
                            <div class="card-body">
                                <div id="bill_products"></div>
                                <h4>
                                    <div id="totalbill">0 <b>so`m</b> </div>
                                </h4>
                            </div>
                        </div>

                        <button action="./sms/twillo.php" type="submit" value="Order"  class="btn btn-primary" name="submit1">Order</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->
</div>
<!-- Content wrapper -->


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Yangi Mijoz Qo`shish</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: red;">&times;</span>
                </button>
            </div>
            <div class="modal-body p-1">
                <div class="card">
                    <form name="form1" action="" method="post">
                        <div class="row">
                            <div class="col-lg-6 col-ms-12">
                                <div class="mb-3">
                                    <label class="form-label">Mijoz ID</label>
                                    <div class="input-group align-items-center">
                                        <input type="text" class="form-control" name="client_id" readonly value="<?php echo  generate_client_id($client_id) ?>">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Mijozning I.F.O</label>
                                    <input type="text" class="form-control" name="client_name" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Menejer</label>
                                    <input type="text" class="form-control" name="client_menejer" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Hududni Tanlang</label>
                                    <select name="client_region" id="" class="form-control">
                                        <option value="toshkent">Toshkent</option>
                                        <option value="buxoro">Buxoro</option>
                                        <option value="navoi">Navoi</option>
                                        <option value="samarqand">Samarqand</option>
                                        <option value="qarshi">Qashqadaryo</option>
                                        <option value="surxandaryo">Surxandaryo</option>
                                        <option value="fargona">Farg`ona</option>
                                        <option value="andjon">Andjon</option>
                                        <option value="xorazm">Namangan</option>
                                        <option value="jizzax">Jizzax</option>
                                        <option value="qoraqalpoq">Qoraqalpoq Respublikasi</option>
                                    </select>
                                </div>


                                <div class="mb-3">
                                    <label class="form-label">Mijozning Manzili</label>
                                    <input type="text" class="form-control" name="client_address" required>
                                </div>
                            </div>
                            <div class="col-lg-6 col-ms-12">
                                <div class="mb-3">
                                    <label class="form-label">Mijozning Firmasi</label>
                                    <input type="text" class="form-control" name="client_company" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Mijozning Firma STIR</label>
                                    <input type="text" class="form-control" name="client_stir" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Контакт лицо</label>
                                    <input type="text" class="form-control" name="client_litso" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Mijozning Telefon Raqami</label>
                                    <input type="text" class="form-control" name="client_number" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Mijozning Kategoriyasi</label>
                                    <select name="client_category" class="form-control">
                                        <option>Kategoriyani Tanlang</option>
                                        <option value="A">A</option>
                                        <option value="B">B</option>
                                        <option value="C">C</option>
                                    </select>
                                </div>
                            </div>
                        </div>




                        <div class="alert alert-danger" role="alert" id="error" style="display:none;">
                            Bu Unit mavjud! Iltmos boshqa User qo`shing
                        </div>

                        <div class="alert alert-success" role="alert" id="success" style="display:none;">
                            Unit muvaffaqiyatli qo`shildi
                        </div>
                        <button type="submit" name="submit2" class="btn btn-primary">Qo`shish</button>
                    </form>
                </div>
            </div>
            <!-- <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div> -->
        </div>
    </div>
</div>

<?php
    function generate_client_id($id)
    {
        
        if ($id == "") {
            $id1 = 0;
        } else {
            $id1 = $id;
        }
        $id1 = $id1 + 1;
    
        $len = strlen($id1);
    
        if ($len == "1") {
            $id1 =  "00" .  $id1;
        }
        if ($len == "2") {
            $id1 =  "000" .  $id1;
        }
    
        if ($len == "3") {
            $id1 =  "0000" .  $id1;
            // $currentDate = date('Ymd'); echo $currentDate;
    
        }
        if ($len == "4") {
            $id1 = "00000" .  $id1;
            // $currentDate = date('Ymd'); echo $currentDate;
        }
        if ($len == "5") {
            $id1 =  "000000" .  $id1;
        }
        if ($len == "6") {
            $id1 =  "0000000" .  $id1;
            // $currentDate = date('Ymd'); echo $currentDate;
        }
        if ($len == "7") {
            $id1 = "00000000" .  $id1;
        }
        return $id1;
    }
?>



<script type="text/javascript">
    function select_cilent(client_name) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("client_div").innerHTML = xmlhttp.responseText;
                // alert("ssss");
            }
        };
        xmlhttp.open("GET", "forajax_user/load_client_info_using_name.php?client_name=" + client_name, true);
        xmlhttp.send();
    }

    function select_company(company_name) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("product_name_div").innerHTML = xmlhttp.responseText;
            }
        };
        xmlhttp.open("GET", "forajax/load_product_using_company.php?company_name=" + company_name, true);
        xmlhttp.send();
    }



    function select_product(product_name, company_name) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("unit_div").innerHTML = xmlhttp.responseText;
            }
        };
        xmlhttp.open("GET", "forajax/load_unit_using_products.php?product_name=" + product_name + "&company_name=" + company_name, true);
        xmlhttp.send();
    }

    function select_unit(unit, product_name, company_name) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("packing_size_div").innerHTML = xmlhttp.responseText;

                $('#packing_size').on('change', function() {
                    load_price(document.getElementById("packing_size").value);
                    load_price2(document.getElementById("packing_size").value);
                });
            }
        };
        xmlhttp.open("GET", "forajax/load_packingsize_using_unit.php?unit=" + unit + "&product_name=" + product_name + "&company_name=" + company_name, true);
        xmlhttp.send();
    }

    function select_price(unit, product_name, company_name) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("packing_size_div2").innerHTML = xmlhttp.responseText;

                $('#packing_size').on('change', function() {
                    load_price(document.getElementById("packing_size").value);
                    load_price2(document.getElementById("packing_size").value);
                });
            }
        };
        xmlhttp.open("GET", "forajax/load_packingsize_using_unit2.php?unit=" + unit + "&product_name=" + product_name + "&company_name=" + company_name, true);
        xmlhttp.send();
    }

    function load_price(packing_size) {
        var company_name = document.getElementById("company_name").value;
        var product_name = document.getElementById("product_name").value;
        var unit = document.getElementById("unit").value;

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("price").value = xmlhttp.responseText;
                // alert(xmlhttp.responseText)
            }
        };
        xmlhttp.open("GET", "forajax/load_price.php?company_name=" + company_name + "&product_name=" + product_name + "&unit=" + unit + "&packing_size=" + packing_size, true);
        // xmlhttp.open("GET", "forajax/load_product_qty.php?company_name=" + company_name + "&product_name=" + product_name + "&unit=" + unit + "&packing_size=" + packing_size, true);
        xmlhttp.send();
    }

    function load_price2(packing_size) {
        var company_name = document.getElementById("company_name").value;
        var product_name = document.getElementById("product_name").value;
        var unit = document.getElementById("unit").value;

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("qty").value = xmlhttp.responseText;
                // alert(xmlhttp.responseText)
            }
        };
        // xmlhttp.open("GET", "forajax/load_price.php?company_name=" + company_name + "&product_name=" + product_name + "&unit=" + unit + "&packing_size=" + packing_size, true);
        xmlhttp.open("GET", "forajax/load_product_qty.php?company_name=" + company_name + "&product_name=" + product_name + "&unit=" + unit + "&packing_size=" + packing_size, true);
        xmlhttp.send();
    }




    function generate_total(qty) {
        document.getElementById("total").value = eval(document.getElementById("price").value) * eval(document.getElementById("qty").value);
    }


    function add_session() {
        var product_company = document.getElementById("company_name").value;
        var product_name = document.getElementById("product_name").value;
        var unit = document.getElementById("unit").value;
        var packing_size = document.getElementById("packing_size").value;
        var price = document.getElementById("price").value;
        var qty = document.getElementById("qty").value;
        var total = document.getElementById("total").value;

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {

                if (xmlhttp.responseText == "") {
                    load_billing_products();
                    alert("product added successfully");
                } else {
                    load_billing_products();
                }

            }
        };
        xmlhttp.open("GET", "forajax/save_in_session.php?company_name=" + product_company + "&product_name=" + product_name + "&unit=" + unit + "&packing_size=" + packing_size + "&price=" + price + "&qty=" + qty + "&total=" + total, true);
        xmlhttp.send();
    }

    function load_billing_products() {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("bill_products").innerHTML = xmlhttp.responseText;
                load_total_bill();
            }
        };
        xmlhttp.open("GET", "forajax/load_billing_products.php", true);
        xmlhttp.send();
    }

    function load_total_bill() {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("totalbill").innerHTML = xmlhttp.responseText;

            }
        };
        xmlhttp.open("GET", "forajax/load_billing_amount.php", true);
        xmlhttp.send();
    }

    load_billing_products();


    function edit_qty(qty1, company_name1, product_name1, unit1, packing_size1, price1) {
        var product_company = company_name1;
        var product_name = product_name1;
        var unit = unit1;
        var packing_size = packing_size1;
        var price = price1;
        var qty = qty1;
        var total = eval(price) * eval(qty);

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {

                if (xmlhttp.responseText == "") {
                    load_billing_products();
                    alert("product added successfully");
                } else {
                    load_billing_products();
                    alert(xmlhttp.responseText);
                }

            }
        };
        xmlhttp.open("GET", "forajax/update_in_session.php?company_name=" + product_company + "&product_name=" + product_name + "&unit=" + unit + "&packing_size=" + packing_size + "&price=" + price + "&qty=" + qty + "&total=" + total, true);
        xmlhttp.send();
    }

    function delete_qty(sessionid) {

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {

                if (xmlhttp.responseText == "") {
                    load_billing_products();
                    alert("product added successfully");
                } else {
                    load_billing_products();
                    alert(xmlhttp.responseText);
                }

            }
        };
        xmlhttp.open("GET", "forajax/delete_in_session.php?sessionid=" + sessionid, true);
        xmlhttp.send();
    }



    const date = new Date();

    let day = date.getDate();
    let month = date.getMonth() + 1;
    let year = date.getFullYear();

    // This arrangement can be altered based on how we want the date's format to appear.
    let currentDate = `${day}-${month}-${year}`;
    console.log(currentDate); // "17-6-2022"
</script>

<?php
function generate_bill_no($id)
{
    $currentDate = date('dmy');
    if ($id == "") {
        $id1 = 0;
    } else {
        $id1 = $id;
    }
    $id1 = $id1 + 1;

    $len = strlen($id1);

    if ($len == "1") {
        $id1 =  "$currentDate" .  $id1;
        // $currentDate = date('Ymd'); echo $currentDate;
    }
    if ($len == "2") {
        $id1 =  "$currentDate" .  $id1;
    }

    if ($len == "3") {
        $id1 =  "$currentDate" .  $id1;
        // $currentDate = date('Ymd'); echo $currentDate;

    }
    if ($len == "4") {
        $id1 = "$currentDate" .  $id1;
        // $currentDate = date('Ymd'); echo $currentDate;
    }
    if ($len == "5") {
        $id1 =  "$currentDate" .  $id1;
    }
    if ($len == "6") {
        $id1 =  "$currentDate" .  $id1;
        // $currentDate = date('Ymd'); echo $currentDate;
    }
    if ($len == "7") {
        $id1 = "$currentDate" .  $id1;
    }
    return $id1;
}


?>

<?php
if (isset($_POST["submit2"])) {
    $count = 0;
    $res = mysqli_query($link, "select * from client_base where client_name='$_POST[client_name]'");
    $count = mysqli_num_rows($res);

    if ($count > 0) {
?>
        <script type="text/javascript">
            document.getElementById('success').style.display = "none";
            document.getElementById('error').style.display = "block";
            setTimeout(function() {
                window.location.href = window.location.href;
            }, 50);
        </script>
    <?php
    } else {
        mysqli_query($link, "insert into client_base values(NULL, '$_POST[client_id]', '$_POST[client_name]', '$_POST[client_menejer]', '$_POST[client_region]', '$_POST[client_address]', '$_POST[client_company]', '$_POST[client_stir]', '$_POST[client_litso]','$_POST[client_number]', '$_POST[client_category]', '1')");

    ?>
        <script type="text/javascript">
            document.getElementById('error').style.display = "none";
            document.getElementById('success').style.display = "block";
            setTimeout(function() {
                window.location.href = window.location.href;
            }, 50);
        </script>
<?php
    }
}
?>

<?php
include "footer.php"
?>