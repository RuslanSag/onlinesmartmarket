<?php
session_start();
    if(!isset($_SESSION["admin"]))
    {
        ?>
            <script type="text/javascript">
                window.location="index.php";
            </script>
        <?php
    }
?>


<?php
include "header.php";
include "connection.php"
?>

<div id="main-content">
    <div id="header">
        <div class="header-left float-left">
            <i id="toggle-left-menu" class="ion-android-menu"></i>
        </div>
        <div class="header-right float-right">
        <a href="./logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i></a>
        </div>
    </div>

    <div id="page-container">
        <div class="col-lg-5">
            <div class="card border-5">
                <div class="card-header">Add New Products</div>
                <div class="card-body p-3">
                    <form name="form1" action="" method="post">
                        <div class="mb-3">
                            <label class="form-label">Select Company:</label>
                            <select class="form-control" name="company_name">
                                <?php
                                    $res=mysqli_query($link, "select * from company_name");
                                    while($row=mysqli_fetch_array($res)){
                                        echo "<option>";
                                        echo $row["company_name"];
                                        echo "</option>";
                                    }
                                ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Enter Product Name:</label>
                            <input type="text" class="form-control" name="product_name" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Enter Product Size:</label>
                            <input type="text" class="form-control" name="packing_size" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Select Unit:</label>
                            <select class="form-control" name="unit">
                                <?php
                                    $res=mysqli_query($link, "select * from units");
                                    while($row=mysqli_fetch_array($res)){
                                        echo "<option>";
                                        echo $row["unit"];
                                        echo "</option>";
                                    }
                                ?>
                            </select>
                        </div>
                        
                        <div class="alert alert-danger" role="alert" id="error" style="display:none;">
                            Bu Mahsulot mavjud! Iltmos boshqa User qo`shing
                        </div>

                        <div class="alert alert-success" role="alert" id="success" style="display:none;">
                        Mahsulot muvaffaqiyatli qo`shildi
                        </div>
                        <button type="submit" name="submit1" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <b>Products Info</b>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#Id</th>
                                <th scope="col">Company  Name</th>
                                <th scope="col">Product Name</th>
                                <th scope="col">Product Size</th>
                                <th scope="col">Edit</th>
                                <th scope="col">Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $res = mysqli_query($link, "select * from products");
                            while ($row = mysqli_fetch_array($res)) {
                            ?>
                                <tr>
                                    <th scope="row"><?php echo $row["id"] ?></th>
                                    <td><?php echo $row["company_name"] ?></td>
                                    <td><?php echo $row["product_name"] ?></td>
                                    <td> <b><?php echo $row["packing_size"] ?></b>  <?php echo $row["unit"] ?> </td>
                                    <td><a href="./edit_products.php?id=<?php echo $row["id"];?> ">Edit</a></td>
                                    <td><a href="./delete_products.php?id=<?php echo $row["id"];?>">Delete</a></td>
                                </tr>
                            <?php
                            }
                            ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
if (isset($_POST["submit1"])) {
    $count = 0;
    $res = mysqli_query($link, "select * from products where  company_name='$_POST[company_name]'&& product_name='$_POST[product_name]'  && unit='$_POST[unit]' && packing_size='$_POST[packing_size]'  ");
    $count = mysqli_num_rows($res);
    if ($count > 0) {
?>
        <script type="text/javascript">
            document.getElementById('success').style.display = "none";
            document.getElementById('error').style.display = "block";
            setTimeout(function(){
                window.location.href=window.location.href;
            },50);
        </script>
    <?php
    } else {
        mysqli_query($link, "insert into products values(NULL,  '$_POST[company_name]', '$_POST[product_name]', '$_POST[unit]', '$_POST[packing_size]' )") or die(mysqli_error($link));

    ?>
        <script type="text/javascript">
            document.getElementById('error').style.display = "none";
            document.getElementById('success').style.display = "block";
            setTimeout(function(){
                window.location.href=window.location.href;
            },50);
        </script>
<?php
    }
}
?>

<?php
include "footer.php"
?>