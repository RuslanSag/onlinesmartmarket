<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>


<?php
include "header.php";
include "connection.php";

?>

<div id="main-content">
    <div id="header">
        <div class="header-left float-left">
            <i id="toggle-left-menu" class="ion-android-menu"></i>
        </div>
        <div class="header-right float-right">
        <a href="./logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i></a>
        </div>
    </div>

    <div id="page-container">
        <div class="card">
            <div class="card-header">Return Products List

                <form class="form-inline" action="" name="form1" method="post">
                    <div class="form-group">
                        <label for="email">Select Company Name</label>
                        <select name="company_name" class="form-control" id="">
                            <?php
                                $res=mysqli_query($link, "select * from party_info");
                                while($row=mysqli_fetch_array($res))
                                {
                                    echo "<option>";
                                    echo $row["businessname"];
                                    echo "</option>";
                                }
                            ?>
                        </select>
                    </div>
                    <button type="submit" name="submit1" class="btn btn-success">Fillter</button>
                    <button type="button" name="submit2" class="btn btn-warning" onclick="window.location.href=window.location.href">Clear Search</button>
                </form>
            </div>

            <div class="card-body">
                <?php
                if (isset($_POST['submit1'])) {
                ?>
                    <table class="table">
                        <tr>
                            <th>Company Name</th>
                            <th>Product Name</th>
                            <th>Unit</th>
                            <th>Packing Size</th>
                            <th>Quantity </th>
                            <th>Price</th>
                            <th>Party Name</th>
                            <th>Purchase Type</th>
                            <th>Expiry Date</th>
                            <th>Purchase Date </th>
                            <th>Username</th>
                        </tr>
                        <?php
                        $res = mysqli_query($link, "select * from purchase_master where party_name>='$_POST[company_name]'");
                        while ($row = mysqli_fetch_array($res)) {
                        ?>
                            <tr>
                                <td><?php echo $row["company_name"] ?></td>
                                <td><?php echo $row["product_name"] ?></td>
                                <td><?php echo $row["unit"] ?></td>
                                <td><?php echo $row["packing_size"] ?></td>
                                <td><?php echo $row["quantity"] ?></td>
                                <td><?php echo $row["price"] ?> <b></td>
                                <td><?php echo $row["party_name"] ?></td>
                                <td><?php echo $row["purchase_type"] ?></td>
                                <td><?php echo $row["expiry_date"] ?> </td>
                                <td><?php echo $row["purchase_date"] ?></td>
                                <td><?php echo $row["username"] ?></td>
                            </tr>
                        <?php
                        }
                        ?>

                    </table>
                <?php
                } 
                
                ?>

            </div>
            <div class="card-footer">

            </div>
        </div>
    </div>
</div>

<?php
include "footer.php"
?>