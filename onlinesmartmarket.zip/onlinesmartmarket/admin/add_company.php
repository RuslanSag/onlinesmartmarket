<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>

<?php
include "connection.php";
?>

<?php
include "header.php";
?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        
        <div class="alerts">
            <div class="alert alert-danger alert-dismissible fade show" role="alert" id="error" style="display:none;">
                Bu Ta`minotchi mavjud! Iltmos boshqa Ta`minotchi qo`shing
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        
            <div class="alert alert-success alert-dismissible fade show" role="alert" id="success" style="display:none;">
                Ta`minotchi muvaffaqiyatli qo`shildi
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
        <div class="col-lg-5">
            <div class="card">
                <div class="card-header">Add Supplier</div>
                <div class="card-body p-3">
                    <form name="form1" action="" method="post">
                        <div class="mb-3">
                            <label class="form-label">Supplier Name</label>
                            <input type="text" class="form-control" name="company_name" required>
                        </div>
        
                        <div class="mb-3">
                            <label class="form-label">Select an area</label>
                            <select name="company_region" id="" class="form-control">
                                <option value="toshkent">Toshkent</option>
                                <option value="buxoro">Buxoro</option>
                                <option value="navoi">Navoi</option>
                                <option value="samarqand">Samarqand</option>
                                <option value="qarshi">Qashqadaryo</option>
                                <option value="surxandaryo">Surxandaryo</option>
                                <option value="fargona">Farg`ona</option>
                                <option value="andjon">Andjon</option>
                                <option value="xorazm">Namangan</option>
                                <option value="jizzax">Jizzax</option>
                                <option value="qoraqalpoq">Qoraqalpoq Respublikasi</option>
                            </select>
                        </div>
        
                        <div class="mb-3">
                            <label class="form-label">Address</label>
                            <input type="text" class="form-control" name="company_address" required>
                        </div>
        
                        <div class="mb-3">
                            <label class="form-label">Firma STIR</label>
                            <input type="text" class="form-control" name="company_stir" required>
                        </div>
        
                        <div class="mb-3">
                            <label class="form-label">Контакт лицо</label>
                            <input type="text" class="form-control" name="company_litso" required>
                        </div>
        
                        <div class="mb-3">
                            <label class="form-label">Tel Number</label>
                            <input type="text" class="form-control" name="company_nomer" required>
                        </div>
        
                        <button type="submit" name="submit1" class="btn btn-primary">Qo`shish</button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <b>Supplier Information</b>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#Id</th>
                                <th scope="col">Supplier Name</th>
                                <th scope="col">Region</th>
                                <th scope="col">Address</th>
                                <th scope="col">STIR</th>
                                <th scope="col">Контакт лицо</th>
                                <th scope="col">Tel Number</th>
                                <th scope="col">Update</th>
                                <th scope="col">Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $res = mysqli_query($link, "select * from company_name");
                            while ($row = mysqli_fetch_array($res)) {
                            ?>
                                <tr>
                                    <th scope="row"><?php echo $row["id"] ?></th>
                                    <td><?php echo $row["company_name"] ?></td>
                                    <td><?php echo $row["company_region"] ?></td>
                                    <td><?php echo $row["company_address"] ?></td>
                                    <td><?php echo $row["company_stir"] ?></td>
                                    <td><?php echo $row["company_litso"] ?></td>
                                    <td><?php echo $row["company_nomer"] ?></td>
                                    <td class="edit"><a href="./edit_company.php?id=<?php echo $row["id"]; ?> "> <span>Update</span> <i class="fa-solid fa-pencil"></i></a></td>
                                    <td class="delete"><a href="./delete_company.php?id=<?php echo $row["id"]; ?>"> <span>Delete</span> <i class="fa-solid fa-trash"></i></a></td>
                                </tr>
                            <?php
                            }
                            ?>
        
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
    </div>
    <!-- / Content -->

<?php
if (isset($_POST["submit1"])) {
    $count = 0;
    $res = mysqli_query($link, "select * from company_name where company_name='$_POST[company_name]'");
    $count = mysqli_num_rows($res);
    if ($count > 0) {
?>
        <script type="text/javascript">
            document.getElementById('success').style.display = "none";
            document.getElementById('error').style.display = "block";
            setTimeout(function() {
                window.location.href = window.location.href;
            }, 3000);
        </script>
    <?php
    } else {
        mysqli_query($link, "insert into company_name values(NULL, '$_POST[company_name]', '$_POST[company_region]','$_POST[company_address]','$_POST[company_stir]','$_POST[company_litso]','$_POST[company_nomer]')") or die(mysqli_error($link));

    ?>
        <script type="text/javascript">
            document.getElementById('error').style.display = "none";
            document.getElementById('success').style.display = "block";

            setTimeout(function() {
                window.location.href = window.location.href;
            }, 3000);
        </script>
<?php
    }
}
?>

<?php
include "footer.php"
?>