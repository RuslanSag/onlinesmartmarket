<?php
   include_once "connection.php";
   
   function filterData(&$str){
    $str = preg_replace("/\t/", "\\t", $str);
    $str = preg_replace("/\r?\n/", "\\n", $str);
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
   }

   $fileName = "members-data_" . date('Y-m-d') . ".xlsx";

   $fields = array('client_name', 'client_region', 'client_address', 'client_number', 'client_category');

   $excelData = implode("\t", array_values($fields)). "\n";

   $query = $link -> query("SELECT * FROM client_base ORDER BY id ASC");
   if($query->num_rows>0){
    while($row = $query-> fetch_assoc()){

        $lineData = array($row['client_name'], $row['client_region'], $row['client_address'], $row['client_number'], $row['client_category']);
        $excelData .= implode("\t", array_values($lineData)) . "\n";
    }
   }
   else{
    $excelData .= 'No records found ...'. "\n";
   }

        header("Content-Type: application/vnd.ms-excel");
        header('Content-Disposition: attachment; filename=\"$mbexcel\"');

        echo $excelData;

        exit();

?>