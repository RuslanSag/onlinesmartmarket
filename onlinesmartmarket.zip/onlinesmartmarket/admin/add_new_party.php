<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>

<?php
include "connection.php"
?>

<?php
include "header.php";
?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="col-lg-5">
            <div class="card">
                <div class="card-header">Add New Party</div>
                <div class="card-body p-3">
                    <form name="form1" action="" method="post">
                        <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" class="form-control" name="firstname" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" class="form-control" name="lastname" required>
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Business name</label>
                            <input type="text" class="form-control" name="businessname" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Contact</label>
                            <input type="text" class="form-control" name="contact" required>
                        </div>
                        <div class="mb-3 d-flex flex-column">
                            <label for="exampleInputEmail1" class="form-label">Address</label>
                            <textarea name="address" class="form-label"></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">City</label>
                            <input type="text" class="form-control" name="city" required>
                        </div>



                        <div class="alert alert-success" role="alert" id="success" style="display:none;">
                            Party muvaffaqiyatli qo`shildi
                        </div>
                        <button type="submit" name="submit1" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <b>Personal Info</b>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#Id</th>
                                <th scope="col">First Name</th>
                                <th scope="col">Last Name</th>
                                <th scope="col">Business Name</th>
                                <th scope="col">Contact</th>
                                <th scope="col">Address</th>
                                <th scope="col">City</th>
                                <th scope="col">Edit</th>
                                <th scope="col">Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $res = mysqli_query($link, "select * from party_info");
                            while ($row = mysqli_fetch_array($res)) {
                            ?>
                                <tr>
                                    <th scope="row"><?php echo $row["id"] ?></th>
                                    <td><?php echo $row["firstname"] ?></td>
                                    <td><?php echo $row["lastname"] ?></td>
                                    <td><?php echo $row["businessname"] ?></td>
                                    <td><?php echo $row["contact"] ?></td>
                                    <td><?php echo $row["address"] ?></td>
                                    <td><?php echo $row["city"] ?></td>
                                    <td><a href="./edit_party.php?id=<?php echo $row["id"]; ?> ">Edit</a></td>
                                    <td><a href="./delete_party.php?id=<?php echo $row["id"]; ?> ">Delete</a></td>
                                </tr>
                            <?php
                            }
                            ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->


<?php
if (isset($_POST["submit1"])) {

    mysqli_query($link, "insert into party_info values(NULL, '$_POST[firstname]','$_POST[lastname]','$_POST[businessname]','$_POST[contact]','$_POST[address]','$_POST[city]')");

?>
    <script type="text/javascript">
        document.getElementById('success').style.display = "block";
        setTimeout(function() {
            window.location.href = window.location.href;
        }, 3000);
    </script>
<?php
}
?>

<?php
include "footer.php"
?>