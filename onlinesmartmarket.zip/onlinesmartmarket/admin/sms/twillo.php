<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>

<?php

require __DIR__ . '/vendor/autoload.php';
include "../connection.php";

if (isset($_POST["submit1"])) {
    $lastbillno = 0;
    $max = 0;
    mysqli_query($link, "insert into billing_header values(NULL,'$_POST[client_id]','$_POST[client_name]', '$_POST[client_region]', '$_POST[client_address]', '$_POST[client_number]', '$_POST[client_category]', '0', '$_POST[bill_date]', '$_POST[bill_no]', '$_SESSION[admin]', '0', '0', '')") or die(mysqli_error($link));

    $res = mysqli_query($link, "select * from  billing_header order by id desc limit 1");

    while ($row = mysqli_fetch_array($res)) {
        $lastbillno = $row["id"];
        $client_id = $row["client_id"];
    }

    $max = sizeof($_SESSION['cart']);

    for ($i = 0; $i < $max; $i++) {
        $product_name_session = "";
        $unit_session = "";
        $packing_size_session = "";
        $price_session = "";

        if (isset($_SESSION['cart'][$i])) {

            foreach ($_SESSION['cart'][$i] as $key => $val) {
                if ($key == "product_name") {
                    $product_name_session = $val;
                } else if ($key == "unit") {
                    $unit_session = $val;
                } else if ($key == "packing_size") {
                    $packing_size_session = $val;
                } else if ($key == "qty") {
                    $qty_session = $val;
                } else if ($key == "price") {
                    $price_session = $val;
                }
                
            }
            if ($product_name_session != "") {

                mysqli_query($link, "insert into billing_details values(NULL, '$lastbillno', '$client_id', '' ,'$product_name_session', '$unit_session', '$packing_size_session', '$price_session','$qty_session' )");
                // mysqli_query($link, "update stock_master set product_qty=product_qty-$qty_session, packing_size=packing_size-$qty_session where product_name='$product_name_session' && product_unit='$unit_session'");
            }
        }
    }
    unset($_SESSION['cart']);
    

?>
    <script type="text/javascript">
        alert("bill a`lo");
        window.location.href = '../sales_master.php';
    </script>
<?php
}

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'notify.eskiz.uz/api/message/sms/send',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => array('mobile_phone' => '+998997055505','message' =>'Agent'. $_SESSION['admin'] . chr(10) . 'Mahsulot:'.  $product_name_session . chr(10) . 'Hajmi'. $packing_size_session . " " . $unit_session . chr(10) .
   'Menendjer iltmos ushbu buyurtmani quyidagi havola orqali TASDIQLANG yoki BEKOR QILING 
   https://master-brother.com/admin/view_bills.php', 
  'from' => '4546','callback_url' => 'http://0000.uz/test.php'),
  CURLOPT_HTTPHEADER => array(
    'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MDQyNzQzMjYsImlhdCI6MTcwMTY4MjMyNiwicm9sZSI6InVzZXIiLCJzdWIiOiI1MzA4In0.BYcEEkLSMC396GSzh4KPYr72rT00OkINYBAVdHXN0Fo'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;
