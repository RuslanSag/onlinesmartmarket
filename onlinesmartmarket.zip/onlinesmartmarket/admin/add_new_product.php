<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>


<?php
include "connection.php"
?>

<?php
include "header.php";
?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="alerts">
            <div class="alert alert-danger alert-dismissible fade show" role="alert" id="error" style="display:none;">
                Bu Mahsulot mavjud! Iltmos boshqa Mahsulot qo`shing
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>

            <div class="alert alert-success alert-dismissible fade show" role="alert" id="success" style="display:none;">
                Mahsulot muvaffaqiyatli qo`shildi
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
        <div class="col-lg-5">
            <div class="card">
                <div class="card-header">Add Product</div>
                <div class="card-body p-3">
                    <form name="form1" action="" method="post">
                        <div class="mb-3">
                            <label class="form-label">Product</label>
                            <input type="text" class="form-control" name="product_name" required>
                        </div>
                        <button type="submit" name="submit1" class="btn btn-primary">Add</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <b>Product Info</b>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#Id</th>
                                <th scope="col">Product Name</th>
                                <th scope="col">Update</th>
                                <th scope="col">Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $res = mysqli_query($link, "select * from add_product");
                            while ($row = mysqli_fetch_array($res)) {
                            ?>
                                <tr>
                                    <th scope="row"><?php echo $row["id"] ?></th>
                                    <td><?php echo $row["product_name"] ?></td>
                                    <td class="edit"><a href="./edit_products.php?id=<?php echo $row["id"]; ?> "><span>Update</span> <i class="fa-solid fa-pencil"></i></a></td>
                                    <td class="delete"><a href="./delete_products.php?id=<?php echo $row["id"]; ?> "><span>Delete</span> <i class="fa-solid fa-trash"></i></a></td>
                                </tr>
                            <?php
                            }
                            ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->


    <div class="content-backdrop fade"></div>
</div>



<?php
if (isset($_POST["submit1"])) {
    $count = 0;
    $res = mysqli_query($link, "select * from add_product where product_name='$_POST[product_name]'");
    $count = mysqli_num_rows($res);

    if ($count > 0) {
?>
        <script type="text/javascript">
            document.getElementById('success').style.display = "none";
            document.getElementById('error').style.display = "block";
            setTimeout(function() {
                window.location.href = window.location.href;
            }, 3000);
        </script>
    <?php
    } else {
        mysqli_query($link, "insert into add_product values(NULL, '$_POST[product_name]', '1')");

    ?>
        <script type="text/javascript">
            document.getElementById('error').style.display = "none";
            document.getElementById('success').style.display = "block";
            setTimeout(function() {
                window.location.href = window.location.href;
            }, 3000);
        </script>
<?php
    }
}
?>

<?php
include "footer.php"
?>