<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>


<?php
include "connection.php"
?>

<?php
include "header.php";
?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <i class="fa-solid fa-store"></i>
                    <b>Stock</b>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Sr No</th>
                                <th scope="col">Supplier</th>
                                <th scope="col">Product Name</th>
                                <th scope="col">Product Value</th>
                                <th scope="col">Product Size Unit</th>
                                <th scope="col">Product Price </th>
                                <th scope="col">Update</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $count = 0;
                            $res = mysqli_query($link, "select * from stock_master");
                            while ($row = mysqli_fetch_array($res)) {
                                $count = $count + 1;
                            ?>
                                <tr>
                                    <th scope="row"><?php echo $count; ?></th>
                                    <td><?php echo $row["product_company"] ?></td>
                                    <td><?php echo $row["product_name"] ?></td>
                                    <td><?php echo $row["product_qty"] ?></td>
                                    <td><?php echo $row["product_unit"] ?></td>
                                    <td>
                                        <select name="" id="" class="form-control">
                                            <option value="">
                                                Kategoriya A - <?php echo $row["product_selling_pricea"] ?> <b>so`m</b>
                                            </option>
                                            <option value="">
                                                Kategoriya B - <?php echo $row["product_selling_priceb"] ?> <b>so`m</b>
                                            </option>
                                            <option value="">
                                                Kategoriya C - <?php echo $row["product_selling_pricec"] ?> <b>so`m</b>
                                            </option>
                                            <option value="">
                                                Kategoriya D - <?php echo $row["product_selling_priced"] ?> <b>so`m</b>
                                            </option>
                                        </select>

                                    </td>
                                    <td class="edit"><a href="./edit_new_stock.php?id=<?php echo $row["id"]; ?> "><span>Update</span> <i class="fa-solid fa-pencil"></i></a></td>
                                </tr>
                            <?php
                            }
                            ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->
</div>
<!-- Content wrapper -->

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="d-flex flex-column">
                    <h5 class="modal-title text-danger" id="exampleModalLabel">ESLATMA !!!</h5>
                    <span>Mijoz Kategoriyasini tanlayotganda e`tibor bering. Ushbu bo`lim buyirtma qismiga ta`sir qiladi</span>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <ul>
                    <li>Kategoriya A - Sotuvchi</li>
                    <li>Kategoriya B - Quruvchi</li>
                    <li>Kategoriya C - Erkin Mijoz</li>
                    <li>Kategoriya D - No`malum</li>
                </ul>
            </div>
            <div class="modal-footer">
                MasterBrother MJCH
            </div>
        </div>
    </div>
</div>

<?php
include "footer.php";
?>