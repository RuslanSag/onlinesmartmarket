<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>


<?php
include "connection.php";

$id = $_GET["id"];
$firstname = "";
$lastname = "";
$businessname = "";
$contact = "";
$address = "";
$city = "";
$res = mysqli_query($link, "select * from party_info where id=$id");
while ($row = mysqli_fetch_array($res)) {
    $firstname = $row["firstname"];
    $lastname = $row["lastname"];
    $businessname = $row["businessname"];
    $contact = $row["contact"];
    $address = $row["address"];
    $city = $row["city"];
}
?>

<?php
include "header.php";
?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="col-lg-5">
            <div class="card">
                <div class="card-header">Edit Party Info</div>
                <div class="card-body p-3">
                    <form name="form1" action="" method="post">
                        <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" class="form-control" name="firstname" value="<?php echo $firstname ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" class="form-control" name="lastname" value="<?php echo $lastname ?>">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Business name</label>
                            <input type="text" class="form-control" name="businessname" value="<?php echo $businessname ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Contact</label>
                            <input type="text" class="form-control" name="contact" value="<?php echo $contact ?>">
                        </div>
                        <div class="mb-3 d-flex flex-column">
                            <label for="exampleInputEmail1" class="form-label">Address</label>
                            <textarea name="address" class="form-control">
                                <?php echo $address ?>
                            </textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">City</label>
                            <input type="text" class="form-control" name="city" value="<?php echo $city ?>">
                        </div>



                        <div class="alert alert-success" role="alert" id="success" style="display:none;">
                            Party muvaffaqiyatli yangilandi.
                        </div>
                        <button type="submit" name="submit1" class="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->
</div>
<!-- Content wrapper -->



<?php
if (isset($_POST["submit1"])) {
    mysqli_query($link, "update party_info set firstname='$_POST[firstname]',lastname='$_POST[lastname]',businessname='$_POST[businessname]',contact='$_POST[contact]',address='$_POST[address]',city='$_POST[city]' where id=$id") or die(mysqli_error($link));
?>
    <script type="text/javascript">
        document.getElementById('success').style.display = "block";
        setTimeout(function() {
            window.location = "add_new_party.php";
        }, 3000);
    </script>
<?php
}

?>

<?php
include "footer.php"
?>