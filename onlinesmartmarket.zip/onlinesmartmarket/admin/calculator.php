<?php
session_start();
include "connection.php";

$id = $_GET["id"];
$client_name = "";
$client_region = "";
$client_address = "";
$client_number = "";
$client_category = "";
$main_pay = "";
$kredit = "";
$debit = "";
$date = "";
$bill_no = "";
$res = mysqli_query($link, "select * from payment_base where id=$id");
while ($row = mysqli_fetch_array($res)) {
  $client_name = $row["client_name"];
  $client_region = $row["client_region"];
  $client_address = $row["client_address"];
  $client_number = $row["client_number"];
  $client_category = $row["client_category"];
  $main_pay = $row["main_pay"];
  $kredit = $row["kredit"];
  $debit = $row["debit"];
  $date = $row["date"];
  $bill_no = $row["bill_no"];
}
?>

<?php

if (isset($_POST["submit"])) {

  mysqli_query($link, "insert into cash values(NULL, '$_POST[bill_no]','$_POST[debit]','$_POST[kredit]','$_POST[date]')");

?>
  <script type="text/javascript">
    document.getElementById('success').style.display = "block";
    setTimeout(function() {
      window.location.href = window.location.href;
    }, 3000);
  </script>
<?php
}
?>

<style>
  table,
  th,
  td {
    border: 1px solid;
    padding: 7px;
  }

  .footer td p {
    color: red;
  }

  * {
    margin: 0;
    padding: 0;
    font-family: "Montserrat";
  }

  h1,
  h2,
  h3 {
    margin: 20px 0;
    color: #00695C;
  }

  p {
    font-size: 1.2em;
    margin: 10px 0;
  }

  button {
    padding: 10px 20px;
    font-size: 1em;
  }

  .container {
    max-width: 800px;
    margin: auto;
    padding: 20px
  }
</style>

<body>
  <form action="" method="POST">

    <table>
      <thead id="myTable">
        <tr>
          <td>Mijoz:</td>
          <td><?php echo $client_name; ?></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td>Address:</td>
          <td><?php echo $client_region; ?> , <?php echo $client_address; ?></td>
          <td></td>
        </tr>
        <tr>
          <td>Tel:</td>
          <td><?php echo $client_number; ?></td>
          <td></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td>DATA</td>
          <td>Debit</td>
          <td>Kredit</td>
          <td>DATA 2</td>
        </tr>
        <tr>
          <td>1</td>
          <td><input type='text' name="bill_no" value="<?php echo $bill_no; ?>" readonly></td>
          <td><?php echo $date; ?></td>
          <td><?php echo $debit; ?></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td><input type='text' name="debit"></td>
          <td><input type='text' name="kredit"></td>
          <td><input type='date' name="date"></td>
          <td><button onclick="addTableRow()">Add Row</button></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td>Jami</td>
          <td>6 000 000</td>
          <td></td>
          <td>DATA 2</td>
        </tr>

      </thead>
      <tbody>

        <tr class="footer">
          <td></td>
          <td>Mijozning qarzi (SALDO)</td>
          <td>
            <p>6 000 000</p>
          </td>
          <td></td>
          <td><button type="submit" name="submit">To`lov</button></td>
        </tr>
      </tbody>
    </table>
  </form>


  <table class="table">
    <tr>
      <th>ID</th>
      <th>Bill No</th>
      <th>Debit</th>
      <th>Kredit</th>
      <th>Date</th>
    </tr>

    <?php
    $total = 0;
    $res = mysqli_query($link, "select * from cash");
    while ($row = mysqli_fetch_array($res)) {
    ?>
      <tr>
        <td><?php echo $row["id"] ?></td>
        <td><a href="view_cash.php?bill_no=<?php echo $row["bill_no"]; ?>"><?php echo $row["bill_no"] ?></a></td>
        <td><?php echo $row["debit"] ?></td>
        <td><?php echo $row["kredit"] ?></td>
        <td><?php echo $row["date"] ?></td>
        <td><a href="return.php?id=<?php echo $row["id"]; ?>">Return</a></td>
      </tr>

    <?php

      // $total =$total + ($row["price"]*$row["qty"]);
    }
    ?>
  </table>
  <style>

  </style>
  <h1>Table Example</h1>


  <br>


  <script>
    function addTableRow() {
      // var table = document.getElementById("myTable");

      // // Create a new row and cells
      // var newRow = table.insertRow(table.length);
      // var cell1 = newRow.insertCell(0);
      // var cell2 = newRow.insertCell(1);
      // var cell3 = newRow.insertCell(2);
      // var cell4 = newRow.insertCell(3);
      // var cell5 = newRow.insertCell(4);
      // var cell6 = newRow.insertCell(5);

      // // Set cell values
      // cell1.innerHTML = "<input type='text'>";
      // cell2.innerHTML = "<input type='text'>";
      // cell3.innerHTML = "<input type='text'>";
      // cell4.innerHTML = "<input type='text'>";
      // cell5.innerHTML = "<input type='text'>";
      // cell6.innerHTML = "<input type='text'>";

      // alert("salom");


    }
  </script>
</body>

</html>