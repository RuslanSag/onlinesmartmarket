<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>


<?php
include "connection.php";

$id = $_GET["id"];
$client_name = "";
$date = "";
$bill_no = "";
$status = "";
$res = mysqli_query($link, "select * from billing_header where id=$id");
while ($row = mysqli_fetch_array($res)) {
    $client_name = $row["client_name"];
    $date = $row["date"];
    $bill_no = $row["bill_no"];
    $status = $row["status"];
}




?>


<style>
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,100;9..40,200;9..40,300;9..40,400;9..40,500;9..40,600;9..40,700;9..40,800;9..40,900;9..40,1000&family=Roboto+Mono:wght@100;200;300;400;500;600;700&display=swap');



    .main {
        padding: 19px 24px;
        background-color: #ffff;
        max-width: 270px;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        position: relative;
    }

    .main_date span {
        color: #000;
        text-align: center;
        font-family: Roboto Mono;
        font-size: 9px;
        font-style: normal;
        font-weight: 400;
        line-height: normal;
        letter-spacing: -0.45px;
    }

    .main_id {
        border: dashed 1px #000;
        border-radius: 5px;
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative;
        margin-top: 15px;
        padding: 15px 5px;
    }

    .main_id small {
        position: absolute;
        top: -7px;
        background-color: #ffff;
        color: #000;
        text-align: center;
        font-family: Roboto Mono;
        font-size: 9px;
        font-style: normal;
        font-weight: 500;
        line-height: normal;
        letter-spacing: 1.125px;
    }

    .main_id p {
        margin: 0;
        color: #000;
        text-align: center;
        font-family: Roboto Mono;
        font-size: 12.6px;
        font-style: normal;
        font-weight: 700;
        line-height: 10.8px;
        /* 85.714% */
        letter-spacing: 0.9px;
    }

    .main_type {
        display: flex;
        width: 100%;
        justify-content: space-between;
        border-bottom: dashed 1px #979797;
        padding: 11px;
    }

    .main_type p,
    .main_address .name p {
        margin: 0;
        color: #000;
        text-align: right;
        font-family: Roboto Mono;
        font-size: 9px;
        font-style: normal;
        font-weight: 400;
        line-height: normal;
        letter-spacing: 0.45px;
    }

    .main_type span,
    .main_address .name span {
        color: #6D7278;
        font-family: Roboto Mono;
        font-size: 9px;
        font-style: normal;
        font-weight: 400;
        line-height: normal;
        letter-spacing: 0.45px;
    }

    .main_address {
        border-bottom: dashed 1px #979797;
        padding: 11px;
        width: 100%;
    }

    .name {
        display: flex;
        width: 100%;
        justify-content: space-between;
        margin-top: 5px;
    }

    .main_bottom {
        position: absolute;
        bottom: -20px;
    }

    .main_bottom img {
        width: 270px;
    }
</style>
<?php
include "header.php";
?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="card">
            <div class="card-header">Detailed Bills</div>
            <div class="card-body">
                <form action="" method="post">
                    <table>
                        <tr>
                            <td>Bill No:</td>
                            <td><input type="text" name="bill_id" id="" class="form-control" value="<?php echo $bill_no; ?>" readonly> </td>
                        </tr>
                        <tr>
                            <td>Full Name:</td>
                            <td><input type="text" name="client_name" id="" class="form-control" value="<?php echo $client_name; ?>" readonly> </td>
                        </tr>
                        <tr>
                            <td>Bill Date:</td>
                            <td><input type="text" name="date" id="" class="form-control" value="<?php echo $date; ?>" readonly> </td>
                        </tr>
                        <tr>
                            <td><label class="form-label">Date</label></td>
                            <td><input type="date" class="form-control" name="bill_date" value="<?php $currentDate = date('Y-m-d');
                                                                                                echo $currentDate; ?>" required></td>
                        </tr>

                    </table>
                    <br>
                    <table class="table">
                        <tr>
                            <th>Product Name</th>
                            <th>Product Unit</th>
                            <th>Packing Size</th>
                            <th>Price</th>
                            <th>Qty</th>
                            <th></th>
                            <th>Total</th>
                            <!-- <th>Return</th> -->
                        </tr>

                        <?php
                        $total = 0;
                        $res = mysqli_query($link, "select * from billing_details where bill_id=$id");
                        while ($row = mysqli_fetch_array($res)) {
                        ?>
                            <tr>
                                <td><input type="text" name="product_qty[<?php echo $row["product_name"] ?>]" id="" class="form-control" value="<?php echo $row["product_name"] ?>" readonly> </td>
                                <td><?php echo $row["product_unit"] ?></td>
                                <td><?php echo $row["packing_size"] ?></td>
                                <td><?php echo $row["price"] ?></td>
                                <td><input type="text" name="product_qty[<?php echo $row["product_name"] ?>]" id="" class="form-control" value="<?php echo $row["qty"] ?>" readonly> </td>
                                <td><input type="text" name="status" id="" class="form-control" value="3" readonly style="display: none;"></td>
                                <td><?php echo ($row["price"] * $row["qty"]) ?></td>
                                <!-- <td><a href="return.php?id=<?php echo $row["id"]; ?>">Return</a></td> -->
                            </tr>

                        <?php

                            $total = $total + ($row["price"] * $row["qty"]);
                        }
                        ?>
                    </table>
            </div>
            <div class="card-footer">
                Grand Total: <?php echo $total; ?> <b>so`m</b>
                <div class="d-flex">
                    <button type="submit" name="acept" class="btn btn-success">Yetkazildi <i class="fa-solid fa-check"></i></button>
                    <button type="submit" name="cancel" class="btn btn-danger" style="margin-left: 10px;"> Yetkazilmadi <i class="fa-solid fa-times"></i></button>
                </div>
            </div>

            <div class="alerts">
                <div class="alert alert-danger alert-dismissible fade show" role="alert" id="error" style="display:none;">
                    Mahsulot Buyutmachiga muvaffaqiyatli Yetkazilmadi!!!
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>

                <div class="alert alert-success alert-dismissible fade show" role="alert" id="success" style="display:none;">
                    Mahsulot Buyutmachiga muvaffaqiyatli Yetkazildi!!!
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>

            </div>
        </div>
        <div class="main">
            <div class="main_img">
                <img src="./img/black.png" alt="">
            </div>
            <div class="main_date">
                <span><?php echo $date; ?> • 9:27:53 AM</span>
            </div>
            <div class="main_id">
                <small>Buyurtma ID</small>
                <p>MB<?php echo $bill_no; ?></p>
            </div>
            <div class="main_type">
                <span>To`lov Turi</span>
                <p>Naqt</p>
            </div>

            <div class="main_address">
                <div class="name">
                    <span>Mijoz Nomi</span>
                    <p><?php echo $client_name; ?></p>
                </div>
                <div class="name">
                    <span>Mijoz Kategoriyasi</span>
                    <p>A</p>
                </div>
                <div class="name">
                    <span>Manzil</span>
                    <p>36, K.Olimjon, <br> Peshku. Buxoro.v</p>
                </div>
            </div>

            <div class="main_address" style="padding-bottom: 25px;">
                <div class="name">
                    <span>Xaridlar</span>
                </div>
                <?php
                $total = 0;
                $res = mysqli_query($link, "select * from billing_details where bill_id=$id");
                while ($row = mysqli_fetch_array($res)) {
                ?>
                    <div class="name">
                        <span><?php echo $row["product_name"] ?></span>
                        <p><?php echo $row["qty"] ?><?php echo $row["product_unit"] ?> x <?php echo $row["price"] ?>uzs = <?php echo ($row["price"] * $row["qty"]) ?>uzs</p>
                    </div>


                <?php

                    $total = $total + ($row["price"] * $row["qty"]);
                }
                ?>
                <div class="name" style="margin-top: 20px;">
                    <span style="font-weight: 900; color: #000;">Jami</span>
                    <p style="font-weight: 900;"><?php echo $total; ?> UZS</p>
                </div>
            </div>

            <div class="main_address" style="border-bottom: #ffff;">
                <div class="name">
                    <span>Agent</span>
                    <p>G`afurbek</p>
                </div>
            </div>
            <div class="main_bottom">
                <img src="./img/bottom.png" alt="">
            </div>
        </div>
    </div>
    <!-- / Content -->
</div>


<?php


$res = mysqli_query($link, "select * from stock_master");
while ($row = mysqli_fetch_array($res)) {
    $product_name = $row["product_name"];
}

if (isset($_POST["acept"])) {

    mysqli_query($link, "update billing_header set deliver='6', deliver_date='$currentDate' where bill_no='$bill_no'");
?>


    <script type="text/javascript">
        document.getElementById('success').style.display = "block";
        document.getElementById('error').style.display = "none";
        setTimeout(function() {
            window.location.href = "status_product.php";
        }, 3000);
    </script>
<?php
}


if (isset($_POST["cancel"])) {

    mysqli_query($link, "update billing_header set deliver='7' where bill_no='$bill_no'");
?>


    <script type="text/javascript">
        document.getElementById('success').style.display = "none";
        document.getElementById('error').style.display = "block";
        setTimeout(function() {
            window.location.href = "status_product.php";
        }, 3000);
    </script>
<?php
}

?>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="d-flex flex-column">
                    <h5 class="modal-title text-danger" id="exampleModalLabel">ESLATMA !!!</h5>
                    <span><b>Buyurtma Yetkazildi/Yetkazilmadi holatini belgilash uchun Yetkazildi yoki Yetkazilmadi tugmalarini Iltmos bir marta bosing</b> </span>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-footer">
                MasterBrother MJCH
            </div>
        </div>
    </div>
</div>

<?php
include "footer.php"
?>