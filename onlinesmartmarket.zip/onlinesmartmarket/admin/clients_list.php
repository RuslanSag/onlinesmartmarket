<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}

?>

<?php
include "header.php";
include "connection.php"
?>

<div id="main-content">
    <div id="header">
        <div class="header-left float-left">
            <i id="toggle-left-menu" class="ion-android-menu"></i>
        </div>
        <div class="header-right float-right">
            <i class="ion-ios-people"></i>
        </div>
    </div>

    <div id="page-container">
        <div class="col-lg-5">
            <div class="card p-4">
                <form name="form1" action="" method="post">
                    <div class="mb-3">
                        <label class="form-label">Mijozning I.F.O</label>
                        <input type="text" class="form-control" name="client_name" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Hududni Tanlang</label>
                        <select name="client_region" id="" class="form-control">
                            <option value="toshkent">Toshkent</option>
                            <option value="buxoro">Buxoro</option>
                            <option value="navoi">Navoi</option>
                            <option value="samarqand">Samarqand</option>
                            <option value="qarshi">Qashqadaryo</option>
                            <option value="surxandaryo">Surxandaryo</option>
                            <option value="fargona">Farg`ona</option>
                            <option value="andjon">Andjon</option>
                            <option value="xorazm">Namangan</option>
                            <option value="jizzax">Jizzax</option>
                            <option value="qoraqalpoq">Qoraqalpoq Respublikasi</option>
                        </select>
                    </div>


                    <div class="mb-3">
                        <label class="form-label">Mijozning Manzili</label>
                        <input type="text" class="form-control" name="client_address" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Mijozning Telefon Raqami</label>
                        <input type="text" class="form-control" name="client_number" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Mijozning Kategoriyasi</label>
                        <select name="client_category" class="form-control">
                            <option>Kategoriyani Tanlang</option>
                            <option value="A">A</option>
                            <option value="B">B</option>
                            <option value="C">C</option>
                        </select>
                    </div>

                    <div class="alert alert-danger" role="alert" id="error" style="display:none;">
                        Bu Unit mavjud! Iltmos boshqa User qo`shing
                    </div>

                    <div class="alert alert-success" role="alert" id="success" style="display:none;">
                        Unit muvaffaqiyatli qo`shildi
                    </div>
                    <button type="submit" name="submit1" class="btn btn-primary">Qo`shish</button>
                </form>
            </div>
        </div>

        <div class="col-lg-7">
            <div class="card p-4">
                d
            </div>
        </div>

        <div id="filter">
            <select name="client_region" id="client_region" class="form-control">
                <option value="toshkent">Toshkent</option>
                <option value="buxoro">Buxoro</option>
                <option value="navoi">Navoi</option>
                <option value="samarqand">Samarqand</option>
                <option value="qarshi">Qashqadaryo</option>
                <option value="surxandaryo">Surxandaryo</option>
                <option value="fargona">Farg`ona</option>
                <option value="andjon">Andjon</option>
                <option value="xorazm">Namangan</option>
                <option value="jizzax">Jizzax</option>
                <option value="qoraqalpoq">Qoraqalpoq Respublikasi</option>
            </select>
        </div>
        <div class="container">
            <table class="table mt-4">
                <thead>
                    <tr>
                        <th scope="col">Mijoz Nomi</th>
                        <th scope="col">Hudud</th>
                        <th scope="col">Manzil</th>
                        <th scope="col">Telefon Raqami</th>
                        <th scope="col">Mijoz Kategoriyasi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $res = mysqli_query($link, "select * from client_base");
                    while ($row = mysqli_fetch_array($res)) {
                    ?>
                        <tr>
                            <td><?php echo $row["client_name"] ?></td>
                            <td><?php echo $row["client_region"] ?></td>
                            <td><?php echo $row["client_address"] ?></td>
                            <td><?php echo $row["client_number"] ?></td>
                            <td><?php echo $row["client_category"] ?></td>
                        </tr>
                    <?php
                    }
                    ?>

                </tbody>
            </table>
        </div>


        <script type="text/javascript">
            $(document).ready(function() {
                $("#client_region").on('change', function() {
                    var value = $(this).val();
                    // alert(value);
                    $.ajax({
                        url: "fetch.php",
                        type: "POST",
                        data: 'request=' + value,
                        beforeSend: function() {
                            $(".container").html("<span>Working...</span>");
                        },
                        success: function(data) {
                            $(".container").html(data);
                        }
                    })
                });
            })
        </script>


        <?php
        if (isset($_POST["submit1"])) {
            $count = 0;
            $res = mysqli_query($link, "select * from client_base where client_name='$_POST[client_name]'");
            $count = mysqli_num_rows($res);

            if ($count > 0) {
        ?>
                <script type="text/javascript">
                    document.getElementById('success').style.display = "none";
                    document.getElementById('error').style.display = "block";
                    setTimeout(function() {
                        window.location.href = window.location.href;
                    }, 50);
                </script>
            <?php
            } else {
                mysqli_query($link, "insert into units values(NULL, '$_POST[client_name]', '$_POST[client_region]', '$_POST[client_address]','$_POST[client_number]', '$_POST[client_category]')");

            ?>
                <script type="text/javascript">
                    document.getElementById('error').style.display = "none";
                    document.getElementById('success').style.display = "block";
                    setTimeout(function() {
                        window.location.href = window.location.href;
                    }, 50);
                </script>
        <?php
            }
        }
        ?>
        


        <?php
        include "footer.php";
        ?>


        <?php
        $res = mysqli_query($link, "select * from client_base");
        while ($row = mysqli_fetch_array($res)) {
        ?>
            <tr>
                <td><?php echo $row["client_name"] ?></td>
                <td><?php echo $row["client_region"] ?></td>
                <td><?php echo $row["client_address"] ?></td>
                <td><?php echo $row["client_number"] ?></td>
                <td><?php echo $row["client_category"] ?></td>
            </tr>
        <?php
        }
        ?>