<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>


<?php

include "connection.php";

if (isset($_GET['id']) && isset($_GET['status'])) {
    $id = $_GET['id'];
    $status = $_GET['status'];
    mysqli_query($link, "update billing_header set status='$status' where id='$id'");
    header("location:view_bills.php");
}

?>

<?php
include "header.php";
?>

<style>
    .pagination {
        display: flex;
        list-style: none;
        margin: 20px 0;
        padding: 0;
    }

    .pagination li {
        margin-right: 10px;
        cursor: pointer;
        color: var(--bs-pagination-hover-color);
        background-color: var(--bs-pagination-hover-bg);
        border-color: var(--bs-pagination-hover-border-color);
        padding: 10px 15px;
        border-radius: 5px;
    }

    .pagination li.active {
        font-weight: bold;
        border-color: #696cff;
        background-color: #696cff;
        color: #fff;
        box-shadow: 0 0.125rem 0.25rem rgba(105, 108, 255, 0.4);
    }
</style>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex">
                        <i class="fa-regular fa-newspaper"></i>
                        <h6>Buyurtmalar</h6>
                    </div>
                    <form class="form-inline" action="" name="form1" method="post">
                        <div class="form-group">
                            <label for="email">Boshlang`ich Sanani Tanlang</label>
                            <input type="text" name="dt" id="dt" autocomplete="off" class="form-control" required style="width:200px;border-style:solid; border-width:1px; border-color:#666666" placeholder="click here to open calender">
                        </div>
                        <div class="form-group">
                            <label for="email">Oxrigi Sanani Tanlang</label>
                            <input type="text" name="dt2" id="dt2" autocomplete="off" placeholder="click here to open calender" class="form-control" style="width:200px;border-style:solid; border-width:1px; border-color:#666666">
                        </div>
                        <button type="submit" name="submit1" class="btn btn-success">Filter</button>
                        <button type="button" name="submit2" class="btn btn-warning" onclick="window.location.href=window.location.href">Clear Search</button>
                    </form>

                </div>
                <div class="card-body p-3">

                    <?php
                    if (isset($_POST["submit1"])) {
                    ?>
                        <table class="table" id="myTable">
                            <tr>
                                <th>Bill No</th>
                                <th>Order From ...</th>
                                <th>F.I.O</th>
                                <th>Buyurtma Turi</th>
                                <th>Order Date</th>
                                <th>Order Price</th>
                                <th>View Details</th>
                                <th>Buyurtma Holati</th>
                            </tr>
                            <?php
                            $res = mysqli_query($link, "select * from billing_header where (date>='$_POST[dt]' && date<='$_POST[dt2]') order by id desc");
                            while ($row = mysqli_fetch_array($res)) {
                            ?>
                                <tr>
                                    <td scope="row"><?php echo $row["bill_no"] ?></td>
                                    <td><?php echo $row["username"] ?></td>
                                    <td><?php echo $row["client_name"] ?></td>
                                    <td><?php echo $row["bill_type"] ?></td>
                                    <td><?php echo $row["date"] ?></td>
                                    <td><?php echo get_total($row["id"], $link); ?> <b>so`m</b> </td>
                                    <td><a href="status_product_view.php?id=<?php echo $row["id"]; ?>"><i class="fa-solid fa-eye"></i></a></td>
                                    <td>
                                        <?php
                                        if ($row['status'] == 1) {
                                            echo '<span class="worning"> <small>Jarayonda</small><i class="fa-solid fa-circle-exclamation"></i></span>';
                                        }
                                        if ($row['status'] == 2) {
                                            echo '<span class="check"> <small>Tasdiqlandi</small><i class="fa-solid fa-check"></i></i></span>';
                                        }
                                        if ($row['status'] == 3) {
                                            echo '<span class="cancel"> <small>Tasdiqlanmadi</small><i class="fa-solid fa-check"></i></i></span>';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <select class="form-control" onchange="status_update(this.options[this.selectedIndex].value,'<?php echo $row['id'] ?>')">
                                            <option value="">Update Status</option>
                                            <option value="1">Panding</option>
                                            <option value="2">Accept</option>
                                            <option value="3">Rejected</option>
                                        </select>
                                    </td>

                                </tr>
                            <?php
                            }
                            ?>

                        </table>
                    <?php
                    } else {
                    ?>
                        <table class="table" id="myTable">
                            <tr>
                                <th>Bill No</th>
                                <th>Order From ...</th>
                                <th>F.I.O</th>
                                <th>Order Date</th>
                                <th>Order Price</th>
                                <th>View Details</th>
                                <th>Order Status</th>
                                <th>Status Management</th>
                            </tr>
                            <?php
                            $res = mysqli_query($link, "select * from billing_header");
                            while ($row = mysqli_fetch_array($res)) {
                            ?>
                                <tr>
                                    <td scope="row"><?php echo "MB" ?><?php echo $row["bill_no"] ?></td>
                                    <td><?php echo $row["username"] ?></td>
                                    <td><?php echo $row["client_name"] ?></td>
                                    <td><?php echo $row["date"] ?></td>
                                    <td><?php echo get_total($row["id"], $link); ?> <b>$</b> </td>
                                    <td><a href="status_product_view.php?id=<?php echo $row["id"]; ?>"><i class="fa-solid fa-eye"></i></a></td>
                                    <td><?php if ($row['deliver'] == 5) {
                                            echo '<span class="worning"> <small>In progress</small><i class="fa-solid fa-circle-exclamation"></i></span>';
                                        }
                                        if ($row['deliver'] == 6) {
                                            echo '<span class="check"> <small>Delivered</small><i class="fa-solid fa-check"></i></i></span>';
                                        }
                                        if ($row['deliver'] == 7) {
                                            echo '<span class="cancel"> <small>Not confirmed</small><i class="fa-solid fa-check"></i></i></span>';
                                        }
                                        ?></td>
                                    <td>
                                        <?php
                                        if ($row['status'] == 1) {
                                            echo '<span class="worning"> <small>In progress</small><i class="fa-solid fa-circle-exclamation"></i></span>';
                                        }
                                        if ($row['status'] == 2) {
                                            echo '<span class="check"> <small>Confirmed</small><i class="fa-solid fa-check"></i></i></span>';
                                        }
                                        if ($row['status'] == 3) {
                                            echo '<span class="cancel"> <small>Not confirmed</small><i class="fa-solid fa-check"></i></i></span>';
                                        }
                                        ?>
                                    </td>



                                </tr>
                            <?php
                            }
                            ?>

                        </table>
                        <nav aria-label="Page navigation">
                            <ul class="pagination" id="pagination"></ul>
                        </nav>
                    <?php
                    }
                    ?>


                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->


   
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const table = document.getElementById('myTable');
        const rows = table.tBodies[0].rows;
        const totalRows = rows.length;
        const rowsPerPage = 10;
        const totalPages = Math.ceil(totalRows / rowsPerPage);
        let currentPage = 1;

        function showPage(page) {
            const start = (page - 1) * rowsPerPage;
            const end = start + rowsPerPage;

            for (let i = 0; i < totalRows; i++) {
                rows[i].style.display = i >= start && i < end ? '' : 'none';
            }
        }

        function generatePagination() {
            const pagination = document.getElementById('pagination');
            pagination.innerHTML = '';

            for (let i = 1; i <= totalPages; i++) {
                const li = document.createElement('li');
                li.textContent = i;
                li.addEventListener('click', function() {
                    currentPage = i;
                    showPage(currentPage);
                    updatePaginationUI();
                });
                pagination.appendChild(li);
            }
        }

        function updatePaginationUI() {
            const paginationItems = document.getElementById('pagination').getElementsByTagName('li');
            for (let i = 0; i < totalPages; i++) {
                if (i + 1 === currentPage) {
                    paginationItems[i].classList.add('active');
                } else {
                    paginationItems[i].classList.remove('active');
                }
            }
        }

        showPage(currentPage);
        generatePagination();
        updatePaginationUI();
    });
</script>




<script type="text/javascript">
    function status_update(value, id) {
        let url = "view_bills.php";
        window.location.href = url + "?id=" + id + "&status=" + value;
    }
</script>

<?php



function get_total($bill_id, $link)
{
    $total = 0;
    $res2 = mysqli_query($link, "select * from billing_details where bill_id=$bill_id");
    while ($row2 = mysqli_fetch_array($res2)) {
        $total = $total + ($row2["price"] * $row2["qty"]);
    }

    return $total;
}
?>

<?php
include "footer.php"
?>