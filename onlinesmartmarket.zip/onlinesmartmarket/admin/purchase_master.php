<?php
session_start();
    if(!isset($_SESSION["admin"]))
    {
        ?>
            <script type="text/javascript">
                window.location="index.php";
            </script>
        <?php
    }
?>


<?php
include "header.php";
include "connection.php"
?>

<div id="main-content">
    <div id="header">
        <div class="header-left float-left">
            <i id="toggle-left-menu" class="ion-android-menu"></i>
        </div>
        <div class="header-right float-right">
        <a href="./logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i></a>
        </div>
    </div>

    <div id="page-container">
        <div class="col-lg-5">
            <div class="card border-5">
                <div class="card-header"><i class="fa-solid fa-store"></i>Skladga Mahsulot Qo`shish</div>
                <div class="card-body p-3">
                    <form name="form1" action="" method="post">
                        <div class="mb-3">
                            <label class="form-label">Kpmpaniya Nomini Tanlang:</label>
                            <select class="form-control" name="company_name" id="company_name" onchange="select_company(this.value)">
                                <option>Kpmpaniya Nomini Tanlash</option>
                                <?php
                                $res = mysqli_query($link, "select * from company_name");
                                while ($row = mysqli_fetch_array($res)) {
                                    echo "<option>";
                                    echo $row["company_name"];
                                    echo "</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Mahsulot Nomini Tanlang:</label>
                            <div id="product_name_div">
                                <select class="form-control" name="">
                                    <option>Mahsulot Nomini Tanlash</option>
                                </select>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Bo`limni Tanlang:</label>
                            <div id="unit_div">
                                <select class="form-control">
                                    <option>Bo`limni Tanlash</option>
                                </select>
                            </div>
                        </div>

                        <div class="mb-3" >
                            <label class="form-label">Enter Packing Size:</label>
                            <div id="packing_size_div">
                                <select class="form-control">
                                    <option>Select</option>
                                </select>
                            </div>
                        </div>



                        <div class="mb-3">
                            <label class="form-label">Mahsulot Hajm:</label>
                            <input type="text" name="qty" id="" value="0" class="form-control">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Enter Price:</label>
                            <input type="text" name="price" id="" value="0" class="form-control">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Select Party:</label>
                            <select class="form-control" name="party_name">
                                <?php
                                $res = mysqli_query($link, "select * from party_info");
                                while ($row = mysqli_fetch_array($res)) {
                                    echo "<option>";
                                    echo $row["businessname"];
                                    echo "</option>";
                                }
                                ?>
                            </select>
                        </div>


                        <div class="mb-3">
                            <label class="form-label">Purchase Type:</label>
                            <select class="form-control" name="purchase_type">
                                <option>Cash</option>
                                <option>Debit</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Enter Expiry Date:</label>
                            <input type="date" name="dt" id="dt" class="form-control">
                        </div>

                        <div class="alert alert-danger" role="alert" id="error" style="display:none;">
                            Bu Mahsulot mavjud! Iltmos boshqa User qo`shing
                        </div>

                        <div class="alert alert-success" role="alert" id="success" style="display:none;">
                            Mahsulot muvaffaqiyatli qo`shildi
                        </div>
                        <button type="submit" name="submit1" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>

    </div>
</div>

<script type="text/javascript">
    function select_company(company_name) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("product_name_div").innerHTML = xmlhttp.responseText;
            }
        };
        xmlhttp.open("GET", "forajax/load_product_using_company.php?company_name=" + company_name, true);
        xmlhttp.send();
    }

    function select_product(product_name, company_name) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("unit_div").innerHTML = xmlhttp.responseText;
            }
        };
        xmlhttp.open("GET", "forajax/load_unit_using_products.php?product_name=" + product_name + "&company_name=" + company_name, true);
        xmlhttp.send();
    }

    function select_unit(unit, product_name, company_name) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("packing_size_div").innerHTML = xmlhttp.responseText;
            }
        };
        xmlhttp.open("GET", "forajax/load_packingsize_using_unit.php?unit=" + unit + "&product_name=" + product_name + "&company_name=" + company_name, true);
        xmlhttp.send();
        alert(unit);
    }
</script>





<?php
if (isset($_POST["submit1"])) {
    $today_date=date("Y-m-d");
    mysqli_query($link, "insert into purchase_master values(NULL, '$_POST[company_name]', '$_POST[product_name]', '$_POST[unit]', '$_POST[packing_size]', '$_POST[qty]', '$_POST[price]', '$_POST[party_name]', '$_POST[purchase_type]', '$_POST[dt]', '$today_date', '$_SESSION[admin]' )") or die(mysqli_error($link));

    $count = 0;
    $res = mysqli_query($link, "select * from stock_master where product_company='$_POST[company_name]' && product_name='$_POST[product_name]' && product_unit='$_POST[unit]'");
    $count = mysqli_num_rows($res);

    if ($count == 0) {
        mysqli_query($link, "insert into stock_master values(NULL, '$_POST[company_name]', '$_POST[product_name]', '$_POST[unit]', '$_POST[packing_size]', '$_POST[qty]', '0')") or die(mysqli_error($link));
    } else {
        mysqli_query($link, "update stock_master set product_qty = product_qty + $_POST[qty] where product_company='$_POST[company_name]' && product_name='$_POST[product_name]' && product_unit='$_POST[unit]' && packing_size='$_POST[packing_size]'");
    }
    ?>

<script type="text/javascript">
    document.getElementById("success").style.display = "block";
    setTimeout(function() {
        window.location.href = window.location.href;
    }, 3000);
</script>

    <?php
}
?>

<?php
include "footer.php"
?>