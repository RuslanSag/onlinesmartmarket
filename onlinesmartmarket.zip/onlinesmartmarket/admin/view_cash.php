<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>


<?php
include "header.php";
include "connection.php";

$client_id = $_GET["client_id"];
$date = "";
$client_name = "";
$client_region = "";
$client_address = "";
$client_number = "";
$main_pay = "";
$res = mysqli_query($link, "select * from payment_base where client_id = $client_id");
while ($row = mysqli_fetch_array($res)) {
    $date = $row["date"];
    $bill_no = $row["bill_no"];
    $client_name = $row["client_name"];
    $client_id = $row["client_id"];
    $client_region = $row["client_region"];
    $client_address = $row["client_address"];
    $client_number = $row["client_number"];
    $main_pay = $row["main_pay"];
}


?>






<style>
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,100;9..40,200;9..40,300;9..40,400;9..40,500;9..40,600;9..40,700;9..40,800;9..40,900;9..40,1000&family=Roboto+Mono:wght@100;200;300;400;500;600;700&display=swap');

    table,
    th,
    td {
        border: 1px solid;
        padding: 7px;
        font-family: Roboto Mono;
    }

    input {
        border: none;
    }

    .footer td p {
        color: red;
    }

    * {
        margin: 0;
        padding: 0;

    }

    h1,
    h2,
    h3 {
        margin: 20px 0;
        color: #00695C;
    }

    p {
        font-size: 1.2em;
        margin: 10px 0;
        font-family: Roboto Mono;

    }

    button {
        padding: 10px 20px;
        font-size: 1em;
    }

    .container {
        max-width: 800px;
        margin: auto;
        padding: 20px
    }
</style>

<div id="main-content">
    <div id="header">
        <div class="header-left float-left">
            <i id="toggle-left-menu" class="ion-android-menu"></i>
        </div>
        <div class="header-right float-right">
            <a href="./logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i></a>
        </div>
    </div>


    <div id="page-container">
        <div class="col-lg-12">
            <div class="card border-5">
                <div class="card-header">
                    <div class="alert alert-danger" role="alert" id="error" style="display:none;">
                        To`lovda Texnik Xatolik, Iltmos qaytadan urinib ko`ring!!!
                    </div>

                    <div class="alert alert-success" role="alert" id="success" style="display:none;">
                        To`lov muvaffaqiyatli yakunlandi!!!
                    </div>
                    <form action="" method="POST">

                        <table>
                            <thead id="myTable">
                                <tr>
                                    <td>Mijoz:</td>
                                    <td><?php echo $client_name; ?> <input type='text' name="client_id" value="<?php echo $client_id; ?>" readonly></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>Address:</td>
                                    <td><?php echo $client_region; ?> , <?php echo $client_address; ?></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>Tel:</td>
                                    <td><?php echo $client_number; ?></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td>DATA</td>
                                    <td>Debit</td>
                                    <td>Kredit</td>
                                    <td>DATA 2</td>
                                </tr>
                                <tr>
                                    <td>1</td>
                                    <td><?php echo "MB"; ?><input type='text' name="bill_no" value="<?php echo $bill_no; ?>" readonly></td>
                                    <td><?php echo $date; ?></td>
                                    <td><input type="text" class="payment_input" value=' <?php echo $main_pay; ?> ' name="main_pay" id="num1" readonly /><?php echo "so`m" ?></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type='text' name="debit" id="subt" readonly></td>
                                    <td><input type='text' name="kredit" id="num2" required></td>
                                    <td><input type='date' name="date" value="<?php $currentDate = date('Y-m-d');
                                                                                echo $currentDate; ?>"></td>
                                    <td><button onclick="addTableRow()" name="submit">To`lov</button></td>
                                </tr>


                            </thead>
                            <tbody>


                            </tbody>
                        </table>
                    </form>

                </div>
                <div class="card-body p-3">

                    <?php
                    $res = mysqli_query($link, "SELECT SUM(kredit) AS value_sum FROM cash");
                    $row = mysqli_fetch_assoc($res);
                    $sum = $row['value_sum'];
                    ?>
                    <div id=" mt-5" style="margin-top: 25px !important;">
                        <div class="card">
                            <div class="card-header">To`lovlar Tarixi</div>
                            <div class="card-body">
                                <table class="w-100">
                                    <thead id="myTable">
                                        <tr>
                                            <td>Mijoz:</td>
                                            <td><?php echo $client_name; ?></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>Address:</td>
                                            <td><?php echo $client_region; ?> , <?php echo $client_address; ?></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>Tel:</td>
                                            <td><?php echo $client_number; ?></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td>DATA</td>
                                            <td>Debit</td>
                                            <td>Kredit</td>
                                            <td>DATA 2</td>
                                        </tr>
                                        <tr>
                                            <td>1</td>
                                            <td><?php echo "MB"; ?><input type='text' name="bill_no" value="<?php echo $bill_no; ?>" readonly></td>
                                            <td><?php echo $date; ?></td>
                                            <td><?php echo $main_pay; ?> <?php echo "so`m" ?></td>
                                            <td></td>
                                            <td></td>
                                        </tr>

                                        <tr>
                                            <?php
                                            $res = mysqli_query($link, "select * from cash where bill_no=$bill_no");
                                            while ($row = mysqli_fetch_array($res)) {
                                            ?>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td><?php echo $row["kredit"] ?> <?php echo "so`m" ?></td>
                                            <td><?php echo $row["date"] ?></td>
                                        </tr>

                                    <?php

                                            }
                                    ?>
                                    </tr>
                                    <?php


                                    // Sample query - Fetch data from the database
                                    $query = "SELECT bill_no, kredit FROM cash";
                                    $result = $link->query($query);

                                    // Check if the query was successful
                                    if ($result) {
                                        // Associative array to store the sum of values for each ID
                                        $totals = array();

                                        // Iterate through the result set
                                        while ($row = $result->fetch_assoc()) {
                                            $bill_no = $row['bill_no'];
                                            $value = intval($row['kredit']); // Convert the string to an integer

                                            // Accumulate the values in the 'test' column for each ID
                                            if (isset($totals[$bill_no])) {
                                                $totals[$bill_no] += $value;
                                            } else {
                                                $totals[$bill_no] = $value;
                                            }
                                        }

                                        // Print the totals
                                        foreach ($totals as $bill_no => $total) {
                                            // echo "Total sum for ID $bill_no: $total<br>";
                                        }

                                        // Free the result set
                                        $result->free();
                                    } else {
                                        echo "Error executing query: " . $link->error;
                                    }


                                    ?>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td>Jami</td>
                                        <td><?php echo $main_pay; ?> <?php echo "so`m" ?></td>
                                        <td><?php echo $total ?><?php echo "so`m" ?></td>
                                        <td>DATA 2</td>
                                    </tr>

                                    </thead>
                                    <tbody>

                                        <tr class="footer">
                                            <td></td>
                                            <td>Mijozning qarzi (SALDO)</td>
                                            <td>
                                                <p><?php echo $main_pay; ?> <?php echo "so`m" ?></p>
                                            </td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                    </tbody>
                                </table>


                            </div>
                            <div class="card-footer">
                                <?php
                                // SQL query to retrieve all rows with the same client_id
                                $sql = "SELECT * FROM payment_base WHERE client_id = $client_id";
                                // $main_pay  = "";
                                // Execute the query
                                $result = $link->query($sql);

                                // Check if the query was successful
                                if ($result) {
                                    // Fetch all rows as an associative array
                                    $rows = $result->fetch_all(MYSQLI_ASSOC);

                                    // Output the bill_no values
                                    foreach ($rows as $row) {
                                ?>
                                        <table>
                                            <thead id="myTable">
                                                 <tr>
                                                    <td>Mijoz:</td>
                                                    <td><?php echo $row['client_name'] ?> <?php echo $row['client_id'] ?></td>
                                                    <td></td>
                                                    <td></td>
                                                </tr>
                                                <tr>
                                                    <td>Address:</td>
                                                    <td><?php echo $row['client_region'] ?> , <?php echo $row['client_address'] ?></td>
                                                    <td></td>
                                                </tr>
                                                <tr>
                                                    <td>Tel:</td>
                                                    <td><?php echo $row['client_number'] ?></td>
                                                    <td></td>
                                                </tr>
                                                 <tr>
                                                    <td></td>
                                                    <td></td>
                                                    <td>DATA</td>
                                                    <td>Debit</td>
                                                    <td>Kredit</td>
                                                    <td>DATA 2</td>
                                                </tr>
                                                <tr>
                                                    <td><?php echo $row['id'] ?></td>
                                                    <td><?php echo "MB"; ?><?php echo $row['bill_no'] ?></td>
                                                    <td><?php echo $row['date'] ?></td>
                                                    <td><?php echo $row['main_pay'] ?><?php echo "so`m" ?></td>
                                                    <td></td>
                                                    <td></td>
                                                </tr>
                                                <tr>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td><input type='text' name="debit" id="subt" readonly></td>
                                                    <td><input type='text' name="kredit" id="num2" required></td>
                                                    <td><input type='date' name="date" value="<?php $currentDate = date('Y-m-d');
                                                                                                echo $currentDate; ?>"></td>
                                                    <td><button onclick="addTableRow()" name="submit">To`lov</button></td>
                                                </tr> 


                                            </thead>
                                            <tbody>


                                            </tbody>
                                        </table>
                                <?php
                                        // echo "Bill No: " . $row['bill_no'] . "\n";
                                        // echo "<br>";
                                        // echo "Main Pay: " . $row['main_pay'] . "\n";
                                        // echo "client_name: " . $row['client_name'] . "\n";
                                    }

                                    // Free the result set
                                    $result->free();
                                }

                                ?>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>

    </div>
</div>



<script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>

<script type="text/javascript">
    $(function() {
        $("#num1, #num2").on("keydown keyup", sum);

        function sum() {
            $("#sum").val(Number($("#num1").val()) + Number($("#num2").val()));
            $("#subt").val(Number($("#num1").val()) - Number($("#num2").val()));
        }
    });

    const date = new Date();

    let day = date.getDate();
    let month = date.getMonth() + 1;
    let year = date.getFullYear();

    // This arrangement can be altered based on how we want the date's format to appear.
    let currentDate = `${day}-${month}-${year}`;
    console.log(currentDate); // "17-6-2022"
</script>

<?php

if (isset($_POST["submit"])) {
    mysqli_query($link, "insert into cash values(NULL, '$_POST[bill_no]', '$_POST[client_id]', '$_POST[debit]','$_POST[kredit]','$_POST[date]')");

    $count = 0;
    $res = mysqli_query($link, "select * from payment_base where bill_no='$_POST[bill_no]'");
    $count = mysqli_num_rows($res);
    if ($count == 0) {
        mysqli_query($link, "insert into payment_base values(NULL, '$_POST[bill_no]', '$_POST[client_id]','$_POST[debit]','$_POST[kredit]','$_POST[date]', '0')");
    } else {
        mysqli_query($link, "update payment_base set main_pay = main_pay - $_POST[kredit] where bill_no='$_POST[bill_no]' ");
?>
        <script type="text/javascript">
            document.getElementById('success').style.display = "block";
            setTimeout(function() {
                window.location.href = window.location.href;
            }, 1000);
        </script>
<?php
    }
}
?>

<?php
include "footer.php"
?>