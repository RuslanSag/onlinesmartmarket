<?php
include "../../user/user/connection.php";
$unit=$_GET["unit"];
$product_name=$_GET["product_name"];
$res=mysqli_query($link, "select * from stock_master where  product_name='$product_name' && product_unit='$unit'");
?>

<select name="packing_size" class="form-control" id="packing_size" onchange="select_price(this.value, '<?php echo $product_name; ?>')">
<option>Select</option>
<?php

while($row=mysqli_fetch_array($res))
{
    echo "<option>";
    echo $row["packing_size"];
    echo "</option>";
} 
echo "</select>";
?>
