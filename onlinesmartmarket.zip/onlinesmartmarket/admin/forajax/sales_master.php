<?php
include "header.php";
include "../../user/user/connection.php";

$bill_no = 0;
$res = mysqli_query($link,"select * from billing_header order by id desc limit 1");
while($row=mysqli_fetch_array($res))
{
    $bill_no = $row ["id"];
}


?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<div id="main-content">
    <div id="header">
        <div class="header-left float-left">
            <i id="toggle-left-menu" class="ion-android-menu"></i>
        </div>
        <div class="header-right float-right">
            <i class="ion-ios-people"></i>
        </div>
    </div>

    <div id="page-container">
        <div class="col-lg-12">
            <div class="card border-5">
                <div class="card-header">Sales a Product</div>
                <div class="card-body p-3">
                    <form name="form1" action="" method="post">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="mb-3">
                                <label class="form-label">Full Name</label>
                                <input type="text" class="form-control" name="full_name" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Bill Type</label>
                                <select class="form-control" name="bill_type_header">
                                    <option>Cash</option>
                                    <option>Debit</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Date</label>
                                <input type="date" class="form-control" name="bill_date" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Bill No</label>
                                <input type="text" class="form-control" name="bill_no" readonly value="<?php echo  generate_bill_no($bill_no)?>">
                            </div>
                        </div>
                        


                        <div class="alert alert-danger" role="alert" id="error" style="display:none;">
                            Bu Unit mavjud! Iltmos boshqa User qo`shing
                        </div>

                        <div class="alert alert-success" role="alert" id="success" style="display:none;">
                            Unit muvaffaqiyatli qo`shildi
                        </div>

                        <div class="text-center mt-3 mb-3">
                            <h4>Sales a Product</h4>
                        </div>


                        <div class="d-flex justify-content-between align-items-center">
                                <div class="mb-3">
                                    <label class="form-label">Product Company:</label>
                                    <select class="form-control" name="company_name" id="company_name" onchange="select_company(this.value)">
                                        <option>Select</option>
                                        <?php
                                        $res = mysqli_query($link, "select * from company_name");
                                        while ($row = mysqli_fetch_array($res)) {
                                            echo "<option>";
                                            echo $row["company_name"];
                                            echo "</option>";
                                        }
                                        ?>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Product Name:</label>
                                    <div id="product_name_div">
                                        <select class="form-control">
                                            <option>Select</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Unit:</label>
                                    <div id="unit_div">
                                        <select class="form-control">
                                            <option>Select</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Product Size:</label>
                                    <div id="packing_size_div">
                                        <select class="form-control">
                                            <option>Select</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Enter Price:</label>
                                    <input type="text" name="price" id="price" value="0" class="form-control" readonly>
                                </div>



                                <div class="mb-3">
                                    <label class="form-label">Enter Qty:</label>
                                    <input type="text" name="qty" id="qty" value="0" onkeyup="generate_total(this.value)"  class="form-control" autocomplete="off">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Total</label>
                                    <input type="text" name="total" id="total" value="0" class="form-control" readonly>
                                </div>


                                <div class="alert alert-success" role="alert" id="success" style="display:none;">
                                    Ma`lumot muvaffaqiyatli qo`shildi
                                </div>
                                <input type="button"  name="" id="" onclick="add_session();" value="Add">
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <b>Taken Products</b>
                            </div>
                            <div class="card-body">
                                <div id="bill_products"></div>
                                <h4>
                                    <div id="totalbill" >0 <b>so`m</b> </div>
                                </h4>
                            </div>
                        </div>
                        
                        <input type="submit" value="submit" class="btn btn-primary" name="submit1">
                        
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-12">

        </div>
    </div>
</div>


<script type="text/javascript">

    function select_company(company_name)
     {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("product_name_div").innerHTML = xmlhttp.responseText;
            }
        };
        xmlhttp.open("GET", "forajax/load_product_using_company.php?company_name=" + company_name, true);
        xmlhttp.send();
    }

    function select_product(product_name, company_name) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("unit_div").innerHTML = xmlhttp.responseText;
            }
        };
        xmlhttp.open("GET", "forajax/load_unit_using_products.php?product_name=" + product_name + "&company_name=" + company_name, true);
        xmlhttp.send();
    }

    function select_unit(unit, product_name, company_name) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("packing_size_div").innerHTML = xmlhttp.responseText;

                $('#packing_size').on('change', function() {
                    load_price(document.getElementById("packing_size").value);
                });
            }
        };
        xmlhttp.open("GET", "forajax/load_packingsize_using_unit.php?unit=" + unit + "&product_name=" + product_name + "&company_name=" + company_name, true);
        xmlhttp.send();
    }

    function load_price(packing_size) {
        var company_name = document.getElementById("company_name").value;
        var product_name = document.getElementById("product_name").value;
        var unit = document.getElementById("unit").value;

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("price").value = xmlhttp.responseText;
                // alert(xmlhttp.responseText)
            }
        };
        xmlhttp.open("GET", "forajax/load_price.php?company_name=" + company_name + "&product_name=" + product_name + "&unit=" + unit + "&packing_size=" + packing_size, true);
        xmlhttp.send();
    }


    function generate_total(qty)
    {
        document.getElementById("total").value=eval(document.getElementById("price").value) * eval(document.getElementById("qty").value);
    }


    function add_session()
    {
        var product_company = document.getElementById("company_name").value;
        var product_name = document.getElementById("product_name").value;
        var unit = document.getElementById("unit").value;
        var packing_size = document.getElementById("packing_size").value;
        var price = document.getElementById("price").value;
        var qty = document.getElementById("qty").value;
        var total = document.getElementById("total").value;

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                
                if(xmlhttp.responseText=="")
                {
                    load_billing_products();
                    alert("product added successfully");
                }
                else
                {
                    load_billing_products();
                    alert(xmlhttp.responseText);
                }

            }   
        };
        xmlhttp.open("GET", "forajax/save_in_session.php?company_name=" + product_company + "&product_name=" + product_name + "&unit=" + unit + "&packing_size=" + packing_size + "&price=" +price + "&qty=" + qty + "&total=" + total, true);
        xmlhttp.send();
    }

    function load_billing_products()
    {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("bill_products").innerHTML = xmlhttp.responseText;
                load_total_bill();
            }
        };
        xmlhttp.open("GET", "forajax/load_billing_products.php", true);
        xmlhttp.send();
    }

    function load_total_bill(){
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("totalbill").innerHTML = xmlhttp.responseText;
                
            }
        };
        xmlhttp.open("GET", "forajax/load_billing_amount.php", true);
        xmlhttp.send();
    }

    load_billing_products();


    function edit_qty(qty1, company_name1, product_name1, unit1, packing_size1, price1){
        var product_company = company_name1;
        var product_name = product_name1;
        var unit = unit1;
        var packing_size = packing_size1;
        var price = price1;
        var qty = qty1;
        var total =eval(price) * eval(qty);

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                
                if(xmlhttp.responseText=="")
                {
                    load_billing_products();
                    alert("product added successfully");
                }
                else
                {
                    load_billing_products();
                    alert(xmlhttp.responseText);
                }

            }   
        };
        xmlhttp.open("GET", "forajax/update_in_session.php?company_name=" + product_company + "&product_name=" + product_name + "&unit=" + unit + "&packing_size=" + packing_size + "&price=" +price + "&qty=" + qty + "&total=" + total, true);
        xmlhttp.send();
    }

function delete_qty(sessionid){

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                
                if(xmlhttp.responseText=="")
                {
                    load_billing_products();
                    alert("product added successfully");
                }
                else
                {
                    load_billing_products();
                    alert(xmlhttp.responseText);
                }

            }   
        };
        xmlhttp.open("GET", "forajax/delete_in_session.php?sessionid="+sessionid, true);
        xmlhttp.send();
}
</script>

<?php 
    function generate_bill_no($id){
        if($id=="")
        {
            $id1=0;
        }
        else
        {
            $id1 = $id;
        }
        $id1=$id1+1;

        $len = strlen($id1);

        if($len=="1")
        {
            $id1="0000".$id1;
        }
        if($len=="2")
        {
            $id1="000".$id1;
        }
        if($len=="3")
        {
            $id1="00".$id1;
        }
        if($len=="4")
        {
            $id1="0".$id1;
        }
        if($len=="5")
        {
            $id1="".$id1;
        }
        return $id1;
    }

    if(isset($_POST["submit1"]))
    {
        $lastbillno=0;
        mysqli_query($link, "insert into billing_header values(NULL,'$_POST[full_name]','$_POST[bill_type_header]', '$_POST[bill_date]', '$_POST[bill_no]')") or die(mysqli_error($link));

        $res = mysqli_query($link, "select * from  billing_header order by id desc limit 1");

        while($row = mysqli_fetch_array($res))
        {
            $lastbillno=$row["id"];
        }
        
        $max = sizeof($_SESSION['cart']);



        for($i=0; $i<$max; $i++)
        {
            $company_name_session="";
            $product_name_session="";
            $unit_session="";
            $packing_size_session="";
            $price_session="";

                
            if(isset($_SESSION['cart'][$i]))
            {
                
                foreach($_SESSION['cart'][$i] as $key => $val)
                {
                    if($key=="company_name")
                    {
                        $company_name_session = $val;
                    }
                    else if($key=="product_name")
                    {
                        $product_name_session = $val;
                    }
                    else if($key=="unit")
                    {
                        $unit_session = $val;
                    }
                    else if($key=="packing_size")
                    {
                        $packing_size_session = $val;
                    }
                    else if($key=="qty")
                    {
                        $qty_session=$val;
                    }

                    else if($key=="price")
                    {
                        $price_session=$val;
                    }
                }
                if($company_name_session!="")
                {
                    mysqli_query($link, "insert into billing_details values(NULL, '$lastbillno', '$company_name_session' ,'$product_name_session', '$unit_session', '$packing_size_session', '$price_session','$qty_session' )");
                }

            }
        }

        unset($_SESSION['cart']);
    }
?>

<?php
include "footer.php"
?>