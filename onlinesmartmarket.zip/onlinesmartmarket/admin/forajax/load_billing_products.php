<?php
session_start();

?>

<table class="table">
    <tr>
        <th scope="col">Product Name</th>
        <th scope="col">Product Size</th>
        <th scope="col">Product Remainder</th>
        <th scope="col">Product Price</th>
        <th scope="col">Product Value (sold)</th>
        <th scope="col">Total</th>
        <th scope="col">Cancel</th>
    </tr>


<?php

$qty_found=0;
$qty_session=0;
$max = 0;

if(isset($_SESSION['cart']))
{
    $max = sizeof($_SESSION['cart']);

}

for($i=0; $i<$max; $i++)
{
    $product_name_session="";
    $unit_session="";
    $packing_size_session="";
    $price_session="";

        
    if(isset($_SESSION['cart'][$i]))
    {
        
        foreach($_SESSION['cart'][$i] as $key => $val)
        {
            if($key=="product_name")
            {
                $product_name_session = $val;
            }
            else if($key=="unit")
            {
                $unit_session = $val;
            }
            else if($key=="packing_size")
            {
                $packing_size_session = $val;
            }
            else if($key=="qty")
            {
                $qty_session=$val;
            }

            else if($key=="price")
            {
                $price_session=$val;
            }
        }
        if($product_name_session!="")
        {

        ?>
            <tr>
                <td><?php echo $product_name_session; ?></td>
                <td><?php echo $unit_session; ?></td>
                <td><?php echo $packing_size_session; ?></td>
                <td><?php echo $price_session; ?> <b>so`m</b> </td>
                <td>
                    <div class="d-flex align-items-center">
                        <input type="text" class="form-control" id="tt<?php echo $i ?>" value="<?php echo $qty_session; ?>">
                        &nbsp; <i class="fa fa-refresh" aria-hidden="true" onclick="edit_qty(document.getElementById('tt<?php echo $i ?>').value, '<?php echo $company_name_session; ?>', '<?php echo $product_name_session; ?>', '<?php echo $unit_session; ?>', '<?php echo $packing_size_session; ?>', '<?php echo $price_session; ?>')"></i> 
                    </div>
                </td>    
                <td><?php echo ($qty_session*$price_session); ?> <b>so`m</b> </td>
                <td style="cursor:pointer;" onclick="delete_qty('<?php echo $i ?>')">Delete</td>
            </tr>
        <?php

        }

    }

}


?>

</table>