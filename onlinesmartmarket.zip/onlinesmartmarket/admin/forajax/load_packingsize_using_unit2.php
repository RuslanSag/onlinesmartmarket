<?php
include "../../user/user/connection.php";
$product_name = $_GET["product_name"];

$res=mysqli_query($link, "select * from stock_master where product_name='$product_name'");
?>

<select class="form-control">
<option>Select</option>
<?php

while($row=mysqli_fetch_array($res))
{
    echo "<option>";
    echo "Kategoriya A  -", $row["product_selling_pricea"] , "so`m";
    echo "</option>";

    echo "<option>";
    echo"Kategoriya B  -", $row["product_selling_priceb"] , "so`m";
    echo "</option>";

    echo "<option>";
    echo "Kategoriya C  -", $row["product_selling_pricec"], "so`m";
    echo "</option>";

    echo "<option>";
    echo "Kategoriya D  -", $row["product_selling_priced"], "so`m";
    echo "</option>";
} 
echo "</select>";
?>


