<?php
include "../connection.php";
$product_name=$_GET["product_name"];

$res=mysqli_query($link, "select * from stock_master where  product_name='$product_name'");

?>
<select name="unit" class="form-control" id="unit" onchange="select_unit(this.value, '<?php echo $product_name; ?>')">
<option>Select</option>
<?php

while($row=mysqli_fetch_array($res))
{
    echo "<option>";
    echo $row["product_unit"];
    echo "</option>";
} 
echo "</select>";
?>
