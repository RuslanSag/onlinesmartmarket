<?php
include "../../user/user/connection.php";
$product_name = $_GET["product_name"];
$unit = $_GET["unit"];
$packing_size = $_GET["packing_size"];

$res=mysqli_query($link, "select * from stock_master where product_name='$product_name'  && product_unit='$unit'  && packing_size='$packing_size'");
?>

<?php

while($row=mysqli_fetch_array($res))
{
    echo $row["product_selling_pricea"];

    // echo "<option>";
    // echo $row["product_selling_priceb"];
    // echo "</option>";

    // echo "<option>";
    // echo $row["product_selling_pricec"];
    // echo "</option>";

    // echo "<option>";
    // echo $row["product_selling_priced"];
    // echo "</option>";
} 
?>


