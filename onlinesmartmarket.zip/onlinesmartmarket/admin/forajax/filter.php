<?php
include "../../user/user/connection.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>MasterBrother - Admin dashboard pro version</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.css'>
    <link rel='stylesheet' href='https://raw.githubusercontent.com/forsigner/magic-check/master/css/magic-check.css'>
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto:300,400'>
    <link rel='stylesheet' href='http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css'>
    <link rel="stylesheet" href="./style.css">
    <link rel="stylesheet" href="./main.css">

</head>

<body>

    <div id="filter">
        <select name="client_region" id="client_region" class="form-control">
            <option value="toshkent">Toshkent</option>
            <option value="buxoro">Buxoro</option>
            <option value="navoi">Navoi</option>
            <option value="samarqand">Samarqand</option>
            <option value="qarshi">Qashqadaryo</option>
            <option value="surxandaryo">Surxandaryo</option>
            <option value="fargona">Farg`ona</option>
            <option value="andjon">Andjon</option>
            <option value="xorazm">Namangan</option>
            <option value="jizzax">Jizzax</option>
            <option value="qoraqalpoq">Qoraqalpoq Respublikasi</option>
        </select>
    </div>
    <div class="container">
        <table class="table mt-4">
            <thead>
                <tr>
                    <th scope="col">Mijoz Nomi</th>
                    <th scope="col">Hudud</th>
                    <th scope="col">Manzil</th>
                    <th scope="col">Telefon Raqami</th>
                    <th scope="col">Mijoz Kategoriyasi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $res = mysqli_query($link, "select * from client_base");
                while ($row = mysqli_fetch_array($res)) {
                ?>
                    <tr>
                        <td><?php echo $row["client_name"] ?></td>
                        <td><?php echo $row["client_region"] ?></td>
                        <td><?php echo $row["client_address"] ?></td>
                        <td><?php echo $row["client_number"] ?></td>
                        <td><?php echo $row["client_category"] ?></td>
                    </tr>
                <?php
                }
                ?>
    
            </tbody>
        </table>
    </div>

    <!-- partial -->
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/js/bootstrap.min.js'></script>
    <script src="./script.js"></script>

    <script type="text/javascript">
        $(document).ready(function(){
            $("#client_region").on('change',function(){
                var value = $(this).val();
                // alert(value);
                $.ajax({
                    url:"fetch.php",
                    type: "POST",
                    data: 'request=' + value,
                    beforeSend:function(){
                        $(".container").html("<span>Working...</span>");
                    },
                    success:function(data){
                        $(".container").html(data);
                    }
                })
            });
        })
    </script>


</body>

</html>