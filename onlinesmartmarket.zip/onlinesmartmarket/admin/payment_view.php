<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>

<?php

include "header.php";
include "connection.php";


?>

<div id="main-content">
    <div id="header">
        <div class="header-left float-left">
            <i id="toggle-left-menu" class="ion-android-menu"></i>
        </div>
        <div class="header-right float-right">
            <a href="./logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i></a>
        </div>
    </div>

    <div id="page-container">
        <div class="col-lg-12">
            <div class="card border-5">
                <div class="card-header">
                    <div class="d-flex">
                        <i class="fa-solid fa-truck"></i>
                        <h6>To`lovlar Tarixi</h6>
                    </div>
                </div>
                <div class="card-body p-3">

                    <table class="table">
                        <tr>
                            <th>Buyurtma No</th>
                            <th>Mijoz F.I.O</th>
                            <th>Tel</th>
                            <th>Mijoz Manzili</th>
                            <th>Jami</th>
                            <th>Qarz</th>
                            <th>To`landi</th>
                        </tr>
                        <?php
                        $total = 0;
                        $res = mysqli_query($link, "select * from payment_base");
                        while ($row = mysqli_fetch_array($res)) {
                        ?>
                            <tr>
                                <td><?php echo $row["bill_no"] ?></td>
                                <td><?php echo $row["client_name"] ?></td>
                                <td><?php echo $row["client_number"] ?></td>
                                <td><?php echo $row["client_region"] ?><?php echo " " ?><?php echo $row["client_address"] ?></td>
                                <td><?php echo $row["main_pay"] ?><b>so`m</b></td>
                                <td><?php echo $row["debit"] ?><b>so`m</b></td>
                                <td><?php echo $row["kredit"] ?> <b>so`m</b></td>

                            </tr>

                        <?php

                        }
                        ?>

                    </table>



                </div>
            </div>
        </div>

    </div>
</div>


<?php
function get_total($bill_id, $link)
{
    $total = 0;
    $res2 = mysqli_query($link, "select * from billing_details where bill_id=$bill_id");
    while ($row2 = mysqli_fetch_array($res2)) {
        $total = $total + ($row2["price"] * $row2["qty"]);
    }

    return $total;
}


?>

<?php
include "footer.php"
?>