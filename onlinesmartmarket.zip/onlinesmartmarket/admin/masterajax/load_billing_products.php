<?php
session_start();

?>

<table class="table">
    <tr>
        <th scope="col">Supplier</th>
        <th scope="col">Product Name</th>
        <th scope="col">Product Size</th>
    </tr>


<?php

$qty_found=0;
$qty_session=0;
$max = 0;

if(isset($_SESSION['cart']))
{
    $max = sizeof($_SESSION['cart']);

}

for($i=0; $i<$max; $i++)
{
    $company_name_session="";
    $product_name_session="";
    $unit_session="";
    $packing_size_session="";

        
    if(isset($_SESSION['cart'][$i]))
    {
        
        foreach($_SESSION['cart'][$i] as $key => $val)
        {
            if($key=="company_name")
            {
                $company_name_session = $val;
            }
            else if($key=="product_name")
            {
                $product_name_session = $val;
            }
            else if($key=="unit")
            {
                $unit_session = $val;
            }
            else if($key=="packing_size")
            {
                $packing_size_session = $val;
            }
        }
        if($company_name_session!="")
        {

        ?>
            <tr>

                    <td scope="row"><?php echo $company_name_session; ?></td>
                    <td><?php echo $product_name_session; ?></td>
                    <td><?php echo $packing_size_session; ?> <?php echo $unit_session; ?>  </td>
                </tr>
        <?php

        }

    }

}


?>

</table>


