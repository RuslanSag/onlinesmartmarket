<?php
include "connection.php";

if(isset($_POST['request'])){
    $request = $_POST['request'];

    $query = "SELECT * FROM client_base WHERE client_region = '$request'";

    $result = mysqli_query($link, $query);

    $count = mysqli_num_rows($result);
}
?>


<table class="table">
    <?php
     if($count){

    ?>
    <thead>
        <tr>
        <th scope="col">Mijoz Nomi</th>
        <th scope="col">Hudud</th>
        <th scope="col">Manzil</th>
        <th scope="col">Telefon Raqami</th>
        <th scope="col">Mijoz Kategoriyasi</th>
        </tr>
        <?php
     } else{
        echo "Sorry no record Found!!";
     }
     ?>
    </thead>

    <tbody>
        <?php
            while($row = mysqli_fetch_assoc($result)){

        ?>

        <tr>
            <td><?php echo $row["client_name"] ?></td>
            <td><?php echo $row["client_region"] ?></td>
            <td><?php echo $row["client_address"] ?></td>
            <td><?php echo $row["client_number"] ?></td>
            <td><?php echo $row["client_category"] ?></td>
        </tr>
        <?php
            }

            ?>
    </tbody>
</table>

<?php

?>