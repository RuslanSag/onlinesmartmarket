<?php
session_start();
if (!isset($_SESSION["admin"])) {
?>
    <script type="text/javascript">
        window.location = "index.php";
    </script>
<?php
}
?>


<?php
include "connection.php";

$id = $_GET["id"];
$product_company = "";
$product_name = "";
$product_unit = "";
$packing_size = "";
$packing_qty = "";
$product_selling_pricea = "";
$product_selling_priceb = "";
$product_selling_pricec = "";
$product_selling_priced = "";

$res = mysqli_query($link, "select * from stock_master where id=$id");
while ($row = mysqli_fetch_array($res)) {
    $product_company = $row["product_company"];
    $product_name = $row["product_name"];
    $product_unit = $row["product_unit"];
    $packing_size = $row["packing_size"];
    // $packing_qty = $row["packing_qty"];
    $product_selling_pricea = $row["product_selling_pricea"];
    $product_selling_priceb = $row["product_selling_priceb"];
    $product_selling_pricec = $row["product_selling_pricec"];
    $product_selling_priced = $row["product_selling_priced"];
}
?>

<?php
include "header.php";
?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">Edit Stocks Price</div>
                <div class="card-body p-3">
                    <form name="form1" action="" method="post">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label class="form-label">Product Company:</label>
                                    <input type="text" class="form-control" name="product_company" value="<?php echo $product_company; ?>" readonly>

                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Product Name:</label>
                                    <input type="text" class="form-control" name="product_name" value="<?php echo $product_name; ?>" readonly>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Product Unit:</label>
                                    <input type="text" class="form-control" name="product_unit" value="<?php echo $product_unit; ?>" readonly>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Packing Size:</label>
                                    <input type="text" class="form-control" name="packing_size" value="<?php echo $packing_size; ?>" readonly>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Packing Size:</label>
                                    <input type="text" class="form-control" name="product_qty" value="<?php echo $packing_size; ?>" readonly>
                                </div>


                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label class="form-label">Product Selling Price A:</label>
                                    <input type="text" class="form-control" name="product_selling_pricea" value="<?php echo $product_selling_pricea; ?>">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Product Selling Price B:</label>
                                    <input type="text" class="form-control" name="product_selling_priceb" value="<?php echo $product_selling_priceb; ?>">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Product Selling Price C:</label>
                                    <input type="text" class="form-control" name="product_selling_pricec" value="<?php echo $product_selling_pricec; ?>">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Product Selling Price D:</label>
                                    <input type="text" class="form-control" name="product_selling_priced" value="<?php echo $product_selling_priced; ?>">
                                </div>
                            </div>
                        </div>


                        <div class="alert alert-danger" role="alert" id="error" style="display:none;">
                            Bu Mahsulot mavjud! Iltmos boshqa User qo`shing
                        </div>

                        <div class="alert alert-success" role="alert" id="success" style="display:none;">
                            Mahsulot muvaffaqiyatli Yangilandi
                        </div>
                        <button type="submit" name="submit1" class="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->
</div>
<!-- Content wrapper -->




<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="d-flex flex-column">
                    <h5 class="modal-title text-danger" id="exampleModalLabel">ESLATMA !!!</h5>
                    <span>Mijoz Kategoriyasini tanlayotganda e`tibor bering. Ushbu bo`lim buyirtma qismiga ta`sir qiladi</span>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <ul>
                    <li>Kategoriya A - Sotuvchi</li>
                    <li>Kategoriya A - Quruvchi</li>
                    <li>Kategoriya A - Erkin Mijoz</li>
                    <li>Kategoriya A - No`malum</li>
                </ul>
            </div>
            <div class="modal-footer">
                MasterBrother MJCH
            </div>
        </div>
    </div>
</div>

<?php
if (isset($_POST["submit1"])) {
    mysqli_query($link, "update stock_master set product_qty='$_POST[product_qty]', product_selling_pricea='$_POST[product_selling_pricea]', product_selling_priceb='$_POST[product_selling_priceb]', product_selling_pricec='$_POST[product_selling_pricec]', product_selling_priced='$_POST[product_selling_priced]' where id=$id") or die(mysqli_error($link));
?>
    <script type="text/javascript">
        document.getElementById('error').style.display = "none";
        document.getElementById('success').style.display = "block";
        setTimeout(function() {
            window.location = "new_stock.php";
        }, 1000);
    </script>
<?php
}
?>

<?php
include "footer.php"
?>